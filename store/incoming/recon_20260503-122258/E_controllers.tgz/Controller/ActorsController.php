<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Entity\Actors\Actor;
use App\Service\SettingsHelper;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use App\Constants\CacheConstants;
use App\Controller\BaseController;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryProvider;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class ActorsController extends AbstractController
{
    /** @var Actor */
    private $user;
    private $tokenStorage;
    private $entityManager;
    private $permissionsDictionaryProvider;
    private $cache;
    private $utilityService;
    private $fsrVoter;
    private $settingsHelper;

    public function __construct(
        EntityManagerInterface $entityManager,
        TokenStorageInterface $tokenStorage,
        PermissionsDictionaryProvider $permissionsDictionaryProvider,
        SettingsHelper $settingsHelper,
        TagAwareCacheInterface $cache,
        UtilityService $utilityService,
        FsrVoter $fsrVoter,
        protected SerializerInterface $serializer
    ) {
        $this->tokenStorage = $tokenStorage;
        $this->permissionsDictionaryProvider = $permissionsDictionaryProvider;
        $this->settingsHelper = $settingsHelper;
        $this->entityManager = $entityManager;
        $this->cache = $cache;
        $this->utilityService = $utilityService;
        $this->fsrVoter = $fsrVoter;
        $this->serializer = $serializer;
    }

    public function getSuccessResponse($object, $resource = null, $status = Response::HTTP_OK)
    {
        $normalized_data = $this->serializer->normalize(
            $object,
            BaseController::NORMALIZER_METHOD,
            ['ignore_authorization' => true, 'ignore_field_authorization' => true]
        );
        if (is_array($normalized_data)) {
            $permissions = $this->permissionsDictionaryProvider->getDataForActor($object);
            $normalized_data['@permissions'] = $permissions;

            list($userSettings, $systemSettings) = $this->settingsHelper->getDataForActor($object);
            $normalized_data['@settings'] = $this->settingsHelper->getMergedSettings($userSettings, $systemSettings);
        }

        return new JsonResponse(
            $normalized_data
        );
    }

    public function getAction(Request $request)
    {
        $object = $this->getCurrentUser();
        return $this->getSuccessResponse($object, Actor::class);
    }

    public function putAction(Request $request)
    {
        $object = $this->getCurrentUser();
        $classPath = get_class($object);
        $requestBody = json_decode($request->getContent());
        $groups = $this->utilityService->identifyChangeFields($requestBody, $classPath);
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => $groups]
        );
        $previousTeams = [];
        $previousRoles = [];
        foreach ($object->getTeams() as $team) {
            $previousTeams[] = 'api/3/teams/' . $team->getUuid();
        }
        foreach ($object->getRoles() as $role) {
            $previousRoles[] = 'api/3/roles/' . $role->getUuid();
        }

        $resourceClass = $this->entityManager->getMetadataFactory()->getMetadataFor(get_class($object))->getName();
        $actorObject = $this->serializer->deserialize(
            $request->getContent(),
            $resourceClass,
            'jsonld',
            ['object_to_populate' => $object]
        );
        $newTeams = [];
        $newRoles = [];
        foreach ($actorObject->getTeams() as $team) {
            $newTeams[] = 'api/3/teams/' . $team->getUuid();
        }
        foreach ($actorObject->getRoles() as $role) {
            $newRoles[] = 'api/3/roles/' . $role->getUuid();
        }
        if (($newTeams != $previousTeams) || ($newRoles != $previousRoles)) {
            $this->fsrVoter->denyUnlessAccessGranted('update.security');
        }
        if ($newTeams != $previousTeams) {
            $this->cache->invalidateTags([CacheConstants::ACCESSIBLE_CHILD_TEAMS, CacheConstants::ACCESSIBLE_PARENT_TEAMS]);
            $cmd = sprintf('sudo -u nginx php /opt/cyops-api/bin/console app:util %s %s', CacheConstants::ACCESSIBLE_PARENT_TEAMS, CacheConstants::ACCESSIBLE_CHILD_TEAMS);
            $this->utilityService->broadcastToHA($cmd);
        }
        if ($newRoles != $previousRoles) {
            $this->cache->invalidateTags([CacheConstants::USER_PERMISSIONS]);
            $cmd = sprintf('sudo -u nginx php /opt/cyops-api/bin/console app:util %s', CacheConstants::USER_PERMISSIONS);
            $this->utilityService->broadcastToHA($cmd);
        }
        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('previous_data', $object);
        $request->attributes->set('_api_item_operation_name', 'put');
        $request->attributes->set('_api_resource_class', $resourceClass);
        $request->attributes->set('data', $actorObject);
        $request->attributes->set('_format', 'jsonld');
        $request->overrideGlobals();
        return $actorObject;
    }

    /**
     * @return Actor|mixed
     */
    protected function getCurrentUser()
    {
        if (!$this->user) {
            $token = $this->tokenStorage->getToken();
            $this->user = $token->getUser();
        }
        return $this->user;
    }
}
