<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Ramsey\Uuid\Uuid;
use App\Entity\Core\File;
use App\Entity\Core\Image;
use App\Entity\Core\PgFile;
use Psr\Log\LoggerInterface;
use App\Entity\Actors\Avatar;
use App\Entity\Custom\Person;
use InvalidArgumentException;
use App\Service\MetadataHelper;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use App\Entity\Core\AbstractFile;
use App\Controller\BaseController;
use App\Constants\ErrorConstants;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use ApiPlatform\Core\DataProvider\ItemDataProviderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class FilesController extends BaseController
{

    public const WIDTH = 65;
    public const HEIGHT = 65;

    public function __construct(
        protected FsrVoter $fsrVoter,
        ContainerInterface $containers,
        private EntityManagerInterface $entityManager,
        protected ItemDataProviderInterface $itemDataProvider,
        private UtilityService $utilityService,
        MetadataHelper $metadataHelper,
        ResourceClassResolverInterface $resourceClassResolver,
        TagAwareCacheInterface $cache,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->serializer = $serializer;
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function getFile(Request $request, $uuid)
    {
        if ($request->attributes->get('_api_item_operation_name') == 'get_fsr_avatar') {
            $resource =  Avatar::class;
        } else {
            $resource = $request->attributes->get('_api_resource_class') ?? File::class;
        }

        $accept = $request->headers->get('Accept', 'application/json');
        if ($uuid == 'current') {
            $uuid = $this->getUser()->getUuid();
        }
        $request->attributes->set('id', $uuid);
        /** @var AbstractFile $file */
        $file = $this->itemDataProvider->getItem($resource, ["uuid" => $uuid]);
        if (is_null($file)) {
            return new Response(null, Response::HTTP_NO_CONTENT);
        }
        if (str_contains($accept, 'application/json')) {
            if ($resource != Avatar::class && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'files')) {
                throw new AccessDeniedException();
            }
            $normalizedData = $this->serializer->normalize($file, self::NORMALIZER_METHOD, ['resource_class' => $resource]);
            if ($request->attributes->get('_api_item_operation_name') == 'get_fsr_image' || $request->attributes->get('_api_item_operation_name') == 'get_fsr_avatar') {
                $entityRepository = $this->entityManager->getRepository(PgFile::class);
                $fid = $file->getFile();
                try {
                    $fileRecord = $entityRepository->findOneBy(['uuid' => $fid]);
                } catch (InvalidArgumentException | \Exception $e) {
                    $this->logger->error($e->getMessage());
                    throw new NotFoundHttpException(sprintf('File with %s not found', $fid));
                }
                $normalizedData['file'] = [];
                $normalizedData['file']['data'] = stream_get_contents($fileRecord->getFile());
            }
            return new JsonResponse(
                $normalizedData,
                Response::HTTP_OK
            );
        } else {
            if ($file->getSize() > 0) {
                $entityRepository = $this->entityManager->getRepository(PgFile::class);
                $fid = $file->getFile();
                try {
                    $fileRecord = $entityRepository->findOneBy(['uuid' => $fid]);
                } catch (InvalidArgumentException | \Exception $e) {
                    $this->logger->error($e->getMessage());
                    throw new NotFoundHttpException(sprintf('File with %s not found', $fid));
                }
                $response = new Response();
                $response->headers->set('Content-Type', $file->getMimeType());
                $response->headers->set('Content-Disposition', 'attachment; filename="' . $file->getFilename() . '"');
                $response->headers->set('filename', $file->getFilename());
                $response->headers->set('Content-Length', $file->getSize());
                $response->setContent(base64_decode(stream_get_contents($fileRecord->getFile())));
                return $response;
            } else {
                return new Response(null, Response::HTTP_NO_CONTENT);
            }
        }
    }

    public function createFile(Request $request)
    {
        
        $result = $this->determineResourceClass($request);
        $resource = $result['resource'];
        $fileUuid = $result['fileUuid'];

        // Handle existing avatar update
        if ($request->attributes->get('_api_item_operation_name') == 'post_fsr_current_avatar') {
            $file = $this->itemDataProvider->getItem($resource, ["uuid" => $fileUuid]);
            if ($file) {
                return $this->updateExistingAvatar($request, $file, $resource);
            }
        }

        $this->validateFilePermissions($resource);
        $upload = $this->validateAndGetUpload($request, $resource);

        $file = $this->createOrUpdateFileEntity($resource, $fileUuid, $upload, $request);
        $pgFile = $this->createPgFileEntity($upload);
        $this->handleImageThumbnail($file, $upload, $pgFile);

        $file->setFile($pgFile->getUuid());
        $file->setUuid($fileUuid);
        $file->setId($fileUuid);
        $this->entityManager->persist($file);
        $this->entityManager->flush();

        return $this->createFileResponse($request, $file, $pgFile, $resource);
    }



    private function determineResourceClass(Request $request): array
    {
        $fileUuid = $request->get('uuid') ?? Uuid::uuid4()->toString();
        if ($request->attributes->get('_api_item_operation_name') == 'post_fsr_image') {
            return ['resource' => Image::class, 'fileUuid' => $fileUuid];
        } elseif ($request->attributes->get('_api_item_operation_name') == 'post_fsr_current_avatar') {
            $fileUuid = $this->getUser()->getUuid();
            return ['resource' => Avatar::class, 'fileUuid' => $fileUuid];
        }
        return ['resource' => File::class, 'fileUuid' => $fileUuid];
    }

    private function validateFilePermissions(string $resource): void
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . 'files') && $resource != Avatar::class) {
            throw new AccessDeniedException();
        }
    }

    private function validateMimeType(string $mimeType, array $allowedMimeTypes, array $restrictedMimeTypes):void {
        if (!empty($allowedMimeTypes) && !in_array($mimeType, $allowedMimeTypes)) {
            throw new BadRequestHttpException(sprintf(ErrorConstants::FSR_CH_0000032, $mimeType));
        }
        else if (!empty($restrictedMimeTypes) && in_array($mimeType, $restrictedMimeTypes)){
            throw new BadRequestHttpException(sprintf(ErrorConstants::FSR_CH_0000032, $mimeType));
        }
    }

    private function validateMimeTypeRestrictions(UploadedFile $upload, string $resource): void
    {
        $restrictedMimeTypes = [];
        $allowedMimeTypes = [];

        if ($resource == Image::class) $allowedMimeTypes = $this->containers->getParameter('allowed_image_mime_type');
        else $restrictedMimeTypes = $this->utilityService->getRestrictedMimeTypeList();

        $clientMimeType  = $upload->getClientMimeType();
        $this->validateMimeType($clientMimeType, $allowedMimeTypes, $restrictedMimeTypes);

        $mimeType  = $upload->getMimeType();
        $this->validateMimeType($mimeType, $allowedMimeTypes, $restrictedMimeTypes);

        $detectedMimeType = $this->utilityService->detectMimeType($upload->getPathname());
        if($detectedMimeType) $this->validateMimeType($detectedMimeType, $allowedMimeTypes, $restrictedMimeTypes);

        // If the claimed MIME type differs from the detected one, we log the error but continue the upload.
        // In a SOAR platform, the uploaded file may still need to be passed to third-party tools for analysis.
        if (!$detectedMimeType || empty($mimeType) || $detectedMimeType !== $mimeType) {
            $this->logger->warning(sprintf(ErrorConstants::FSR_CH_0000033, $mimeType, $detectedMimeType));
        }
    }


    private function validateAndGetUpload(Request $request, string $resource): UploadedFile
    {
        /** @var UploadedFile $upload */
        $upload = $request->files->get('file');
        if (!$upload->isValid()) {
            throw new BadRequestHttpException(sprintf(ErrorConstants::INVALID_FILE_NAME, $upload->getErrorMessage()));
        }

        $this->validateMimeTypeRestrictions($upload, $resource);
        return $upload;
    }


    private function createOrUpdateFileEntity(string $resource, string $fileUuid, UploadedFile $upload, Request $request): AbstractFile
    {
        $file = $this->itemDataProvider->getItem($resource, ["uuid" => $fileUuid]);
        if (!$file) {
            /** @var AbstractFile $file */
            $file = new $resource();
        }

        $file->setFilename($upload->getClientOriginalName());
        $file->setMimeType($upload->getClientMimeType());
        $file->setSize($upload->getSize());
        $timestamp = new \DateTime('NOW', new \DateTimeZone('UTC'));
        $file->setUploadDate($timestamp);
        $file->setMetadata(json_decode($request->request->get('metadata', "{}"), true));

        return $file;
    }

    private function createPgFileEntity(UploadedFile $upload): PgFile
    {
        $pgFile = new PgFile();
        $stream = fopen($upload->getPathname(), 'rb');
        $pgFile->setFile(base64_encode(stream_get_contents($stream)));
        $this->entityManager->persist($pgFile);
        $this->entityManager->flush();
        return $pgFile;
    }

    private function handleImageThumbnail(AbstractFile $file, UploadedFile $upload, PgFile $pgFile): void
    {
        if (substr_count($file->getMimeType(), 'image/')) {
            [$wid, $ht] = getimagesize($upload->getPathname());
            $thumbnail = "data:image/jpeg;base64," . base64_encode($this->getImageThumbnail($pgFile->getFile(), $wid, $ht));
            $file->setThumbnail($thumbnail);
        }
    }

    private function updateExistingAvatar(Request $request, AbstractFile $file, string $resource): JsonResponse
    {
        $resource =  Image::class;
        $upload = $this->validateAndGetUpload($request, $resource);

        $fileStream = fopen($upload->getPathname(), 'rb');
        $stream = stream_get_contents($fileStream);
        $file->setFilename($upload->getClientOriginalName());
        $file->setMimeType($upload->getClientMimeType());
        $file->setSize($upload->getSize());

        $pgFileEntityManager = $this->containers->get('doctrine')->getManagerForClass(PgFile::class);
        $pgFile = $pgFileEntityManager->find(PgFile::class, $file->getFile());
        $pgFile->setFile(base64_encode($stream));

        $this->handleImageThumbnailForExisting($file, $upload, $pgFile);

        $pgFileEntityManager->persist($pgFile);
        $this->entityManager->persist($file);
        $this->entityManager->flush();

        $normalizedData = $this->serializer->normalize(
            $file,
            self::NORMALIZER_METHOD,
            ['resource_class' => $resource]
        );
        $normalizedData['file'] = [];
        $normalizedData['file']['data'] = $pgFile->getFile();

        return new JsonResponse(
            $normalizedData,
            Response::HTTP_CREATED
        );
    }

    private function handleImageThumbnailForExisting(AbstractFile $file, UploadedFile $upload, PgFile $pgFile): void
    {
        if (substr_count($upload->getClientMimeType(), 'image/')) {
            [$wid, $ht] = getimagesize($upload->getPathname());
            $thumbnail = "data:image/jpeg;base64," . base64_encode($this->getImageThumbnail($pgFile->getFile(), $wid, $ht));
            $file->setThumbnail($thumbnail);
        }
    }

    private function createFileResponse(Request $request, AbstractFile $file, PgFile $pgFile, string $resource): JsonResponse
    {
        $normalizedData = $this->serializer->normalize(
            $file,
            self::NORMALIZER_METHOD,
            ['resource_class' => $resource]
        );

        if ($request->attributes->get('_api_item_operation_name') == 'post_fsr_image' || $request->attributes->get('_api_item_operation_name') == 'post_fsr_current_avatar') {
            $normalizedData['file'] = [];
            $normalizedData['file']['data'] = $pgFile->getFile();
        }

        return new JsonResponse(
            $normalizedData,
            Response::HTTP_CREATED
        );
    }

    public function deleteFile(Request $request, $uuid)
    {
        $checkFilePermission = true;
        if ($request->attributes->get('_api_item_operation_name') == 'delete_fsr_image') {
            $resource =  Image::class;
        } elseif ($request->attributes->get('_api_item_operation_name') == 'delete_fsr_avatar') {
            $actorObj = $this->entityManager->getRepository(Person::class)->findOneBy(['avatar' => '/api/3/avatars/' . $uuid]);
            $uuid = $this->getUser()->getUuid();
            if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . 'security') && ($actorObj && $actorObj->getUuid() != $uuid)) {
                throw new AccessDeniedException();
            }
            if ($actorObj) {
                $actorObj->setAvatar(null);
            }
            $checkFilePermission = false;
            $resource =  Avatar::class;
        } else {
            $resource =  File::class;
        }
        if ($checkFilePermission && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . 'files')) {
            throw new AccessDeniedException();
        }
        $file = $this->itemDataProvider->getItem($resource, ["uuid" => $uuid]);
        if (!$file) {
            throw new NotFoundHttpException("Record with Provided UUID does not exists");
        }
        if ($resource != Image::class && $resource != Avatar::class) {
            $this->utilityService->validateOwnerShip($request, $file);
        }
        $this->removeFiles($file);
        return new Response(null, Response::HTTP_NO_CONTENT);
    }

    protected function getImageThumbnail($imageString, $wid, $ht)
    {
        // Prevent division by zero
        if ($ht == 0 || $wid == 0) {
            throw new \InvalidArgumentException('Width and height must be greater than zero');
        }
        $r = $wid / $ht;
        if (self::WIDTH / self::HEIGHT > $r) {
            $new_width = self::HEIGHT * $r;
            $new_height = self::HEIGHT;
        } else {
            $new_height = self::WIDTH / $r;
            $new_width = self::WIDTH;
        }
        $source = imagecreatefromstring(base64_decode($imageString));
        $dst = imagecreatetruecolor($new_width, $new_height);
        imagecopyresampled($dst, $source, 0, 0, 0, 0, $new_width, $new_height, $wid, $ht);
        ob_start();
        imagejpeg($dst, null, 100);
        return ob_get_clean();
    }

    public function saveFiles($fileObj)
    {
        $this->entityManager->persist($fileObj);
        $this->entityManager->flush();
        return $fileObj;
    }

    public function removePgFile($fileObj)
    {
        $pgFileRepo = $this->entityManager->getRepository(PgFile::class);
        if ($fileObj->getFile()) {
            $pgFile = $pgFileRepo->findOneBy(["uuid" => $fileObj->getFile()]);
            $this->entityManager->remove($pgFile);
            $this->entityManager->flush();
        }
    }

    public function removeFiles($fileObj)
    {
        $this->removePgFile($fileObj);
        $this->entityManager->remove($fileObj);
        $this->entityManager->flush();
        return $fileObj;
    }
}
