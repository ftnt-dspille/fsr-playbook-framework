<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Command\SystemUpdate;
use App\Constants\AppConstants;
use App\Security\Voter\FsrVoter;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\NullOutput;
use App\Entity\ModelMetadata\StagingModelMetadata;
use Symfony\Component\HttpFoundation\JsonResponse;
use App\Validator\ModelMetadataCollectionConstraint;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Validator\ConstraintViolationListInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class PublishMetadataController extends AbstractController
{
    const DEFALUT_KEY = 'cyops.crudhub.datanotify';

    protected $containers;

    protected $fsrVoter;

    public function __construct(
        FsrVoter $fsrVoter,
        ContainerInterface $containers,
        protected SerializerInterface $serializer
    ) {
        $this->containers = $containers;
        $this->fsrVoter = $fsrVoter;
        $this->serializer = $serializer;
    }

    /**
     * @return string
     */
    private function extractUserName()
    {
        if (method_exists($this->getUser(), "getfirstname")) {
            if (method_exists($this->getUser(), "getlastname")) {
                $userName = $this->getUser()->getfirstname() . ' ' . $this->getUser()->getlastname();
            } else {
                $userName = $this->getUser()->getfirstname();
            }
        } else {
            $userName = $this->getUser()->getname();
        }
        return $userName;
    }

    /**
     * @return array
     */
    protected function prepareChangeData()
    {
        $userName = $this->extractUserName();
        return [
            AppConstants::COMPONENT => 'crudhub',
            AppConstants::ENTITY_TYPE => 'ModelMetadata',
            AppConstants::HTTP_METHOD => 'Update',
            AppConstants::REMOTE_ADDR => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'],
            AppConstants::TRANSACTION_DATE => (int) ($_SERVER['REQUEST_TIME_FLOAT'] * 1000),
            AppConstants::USER => $userName,
            AppConstants::USER_UUID => $this->getUser()->getUuid(),

        ];
    }

    public function publishAction()
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . 'application')) {
            throw new AccessDeniedException();
        }

        $modelMetadatasWithKeys = $this->getAllMetadata(StagingModelMetadata::class);

        $violations = $this->containers->get('validator')->validate($modelMetadatasWithKeys, new ModelMetadataCollectionConstraint());

        if (count($violations) > 0) {
            return $this->getErrorResponse($violations);
        }

        $rootDir = $this->containers->getParameter('kernel.project_dir');
        $logFile = sprintf('%s/public/503.json', $rootDir);

        $systemUpdate = new SystemUpdate();
        $systemUpdate->setMessage('Publish queued.');
        $systemUpdate->setProgressPercent(0);
        $filesystem = $this->containers->get('filesystem');
        $filesystem->dumpFile($logFile, json_encode($systemUpdate));
        $command = '/usr/bin/php /opt/cyops-api/bin/console app:system:update -la';
        chdir($this->containers->getParameter('kernel.project_dir') . '/../');
        exec(sprintf('bash -c "exec nohup setsid %s > /var/log/cyops/cyops-api/last_system_publish.log 2>&1 &"', $command));

        $body = $this->prepareChangeData();
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->setContentType('application/json');
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->publish(json_encode([$body]), self::DEFALUT_KEY);

        return new JsonResponse([
            '@type' => 'Publish',
            'status' => 'started',
        ]);
    }

    public function revertAction()
    {
        $input = new ArrayInput([]);
        $output = new NullOutput();

        /** @var RevertStagingMetadataCommand $command */
        $command = $this->containers->get('app.metadata.command.revert_metadata');
        $resultCode = $command->run($input, $output);

        $status = 'reverted';

        if ($resultCode !== 0) {
            $status = 'failed';
        }

        return new JsonResponse([
            '@type' => 'Publish',
            'status' => $status,
        ]);
    }

    /**
     * @inheritdoc
     */
    protected function getErrorResponse(ConstraintViolationListInterface $violations)
    {
        $clientErrorCode = Response::HTTP_BAD_REQUEST;
        return new JsonResponse($this->serializer->normalize($violations, 'hydra-error'), $clientErrorCode);
    }

    public function getLastPublishStatusAction()
    {
        $file = '/var/log/cyops/cyops-api/last_system_publish.log';
        $searchfor = array("An exception occurred", "ERROR:", "PHP Fatal error", "syntax error", "There is no column with name", "UnexpectedValueException");
        $errors = [];

        if (file_exists($file)) {
            // Get the file contents, assuming the file to be readable (and exist)
            $contents = file_get_contents($file);
            $fileModificationTime = filectime($file);

            foreach ($searchfor as $searchString) {
                // escape special characters in the query
                $pattern = preg_quote($searchString, '/');
                // finalise the regular expression, matching the whole line
                $pattern = "/^.*$pattern.*$\\n.*$\\n/m";
                // search, and store all matching occurences in $matches
                if (preg_match_all($pattern, $contents, $matches)) {
                    $errors = array_merge($errors, array_unique($matches[0]));
                }
            }
            if (count($errors) == 0) {
                return new JsonResponse([
                    '@type' => 'Publish',
                    'status' => 'Success',
                    'last_publish_time' => $fileModificationTime,
                ]);
            } else {
                $error = implode("", $errors);
                $error = preg_replace('#\\x1b[[][^A-Za-z]*[A-Za-z]#', '', $error);
                return new JsonResponse([
                    '@type' => 'Publish',
                    'status' => 'Fail',
                    'last_publish_time' => $fileModificationTime,
                    'errors' => $error,
                    'display_error_text' => $this->getDisplayText($errors),
                    'display_error' => $this->getMeaningfulDisplayError($errors),
                ], Response::HTTP_BAD_REQUEST);
            }
        } else {
            //if file not present it means no publish happened yet
            return new JsonResponse([
                '@type' => 'Publish',
                'status' => 'Not available.',
                'message' => 'No traces found for last system update.',
            ], Response::HTTP_NOT_FOUND);
        }
    }

    private function getDisplayText($errors)
    {
        $errors = implode(" ", $errors);
        $pos = strpos($errors, 'CREATE UNIQUE INDEX');
        if ($pos) {
            return 'Unique constraint could not be created=>' . $this->getUniqueConstraint($errors) . ': as duplicate records exist. Please ensure all duplicate records are removed before applying this unique constraint.';
        }
    }

    private function getMeaningfulDisplayError($errors)
    {
        $displayError = "";
        $space_separated = implode(" ", $errors);
        $moduleName = $this->getModuleName($space_separated);
        $errorStatement = $this->getErrorStatement($space_separated);
        if ($errorStatement != '' && $moduleName != '') {
            $displayError = $moduleName . " : " . $errorStatement;
        }
        return $displayError;
    }

    private function getUniqueConstraint($error)
    {
        //Removing all words staring with special characters
        $pos = strpos($error, 'CREATE UNIQUE INDEX');
        $pos2 = strpos($error, "':  [39;49m");
        if ($pos === false) {
            return '';
        }
        $pos = $pos + strlen('CREATE UNIQUE INDEX');
        return substr($error, $pos, $pos2 - $pos);
    }

    private function getModuleName($error)
    {
        //Removing all words staring with special characters
        $pos = strpos($error, 'ALTER TABLE');
        if ($pos === false) {
            return '';
        }
        $pos = $pos + strlen('ALTER TABLE');
        return substr($error, $pos, (strpos($error, 'ALTER', $pos) - $pos));
    }

    private function getErrorStatement($error)
    {
        $pos = strpos($error, 'Datatype mismatch');
        if ($pos === false) {
            return '';
        }
        $message = substr($error, $pos);
        $pos = strpos($message, 'ERROR:');
        $message = substr($message, $pos + strlen('ERROR:'));
        return str_replace('column', 'field', $message);
    }

    /**
     * @param string $class
     * @return array
     */
    private function getAllMetadata($class)
    {
        $metadataEntityManager = $this->containers->get('doctrine.orm.entity_manager');

        /** @var EntityRepository $modelMetadataRepository */
        $modelMetadataRepository = $metadataEntityManager->getRepository($class);

        /** @var ModelMetadata[] $modelMetadatas */
        $modelMetadatas = $modelMetadataRepository->findAll();
        $modelMetadatasWithKeys = [];

        foreach ($modelMetadatas as $modelMetadata) {
            $modelMetadatasWithKeys[$modelMetadata->getType()] = $modelMetadata;
        }
        return $modelMetadatasWithKeys;
    }
}
