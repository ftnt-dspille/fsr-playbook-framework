<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller\TAXII;

use Ramsey\Uuid\Uuid;
use Psr\Log\LoggerInterface;
use App\Constants\AppConstants;
use App\Providers\QueryProvider;
use App\Security\Voter\FsrVoter;
use App\Constants\CacheConstants;
use App\Constants\ErrorConstants;
use App\Entity\Query\SystemQuery;
use App\Entity\Custom\ThreatIntel;
use App\Entity\Settings\SystemSettings;
use App\Utility\FilterUtility;
use Doctrine\ORM\EntityManagerInterface;
use GuzzleHttp\Psr7\Request as GuzzleRequest;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use ApiPlatform\Core\DataProvider\CollectionDataProviderInterface;
use ApiPlatform\Core\Serializer\SerializerContextBuilderInterface;
use App\Service\UtilityService;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class TaxiiApiController extends AbstractController
{

    public const THREAT_FEED_MODULE_NAME = 'threat_intel_feeds';
    private $csvDir;
    public const RENAME_KEYS_MAP = [
        'specVersion' => 'spec_version',
        'patternType' => 'pattern_type',
        'patternVersion' => 'pattern_version',
        'validFrom' => 'valid_from',
        'validUntil' => 'valid_until',
        'indicatorTypes' => 'indicator_types',
        'killChainPhases' => 'kill_chain_phases',
        'createDate' => 'created',
        'modifyDate' => 'modified',
        'lastSeen' => 'last_seen',
        'firstSeen' => 'first_seen',
    ];

    private const STIX_21_VALID_INDICATOR_TYPES = [
        'anomalous-activity',
        'anonymization',
        'benign',
        'compromised',
        'malicious-activity',
        'attribution',
        'unknown'
    ];

    private const STIX_21_ALLOWED_PROPERTIES = [
        'id',
        'name',
        'type',
        'labels',
        'created',
        'pattern',
        'modified',
        'confidence',
        'valid_from',
        'description',
        'pattern_type',
        'spec_version',
        'kill_chain_phases'
    ];

    public function __construct(
        protected EntityManagerInterface $entityManager,
        protected SerializerInterface $serializer,
        protected SerializerContextBuilderInterface $serializerContextBuilder,
        protected CollectionDataProviderInterface $collectionDataProvider,
        protected FsrVoter $fsrVoter,
        protected QueryProvider $queryProvider,
        protected ContainerInterface $containers,
        protected LoggerInterface $logger,
        protected UtilityService $utilityService
    ) {
        $this->csvDir = $this->containers->getParameter('kernel.project_dir') . '/workspace/';
    }

    /**
     * @Route("api/taxii/1/taxii", name="app_api_root", methods={"GET"})
     * @Route("api/taxii2/1/taxii", name="app_api_root_taxii2", methods={"GET"})
     */
    public function getTaxiiRootApi()
    {
        $module = self::THREAT_FEED_MODULE_NAME;
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $module)) {
            throw new AccessDeniedException();
        }

        $wfClient = $this->containers->get("app.proxy.client.workflow");
        $headers = array(
            "Content-type" => "application/json",
        );
        $workflowUri = $this->containers->getParameter('workflow.uri');
        $workflowRequests = new GuzzleRequest('get', $workflowUri . '/api/dynamic-variable/?format=json&name=Server_fqhn', $headers);
        $systemHost = 'localhost';
        try {
            $workflowResponse = $wfClient->send($workflowRequests);
            $workflowResponseData = json_decode($workflowResponse->getBody()->getContents(), true);
            if ($workflowResponseData["hydra:totalItems"] > 0) {
                $systemHost = $workflowResponseData["hydra:member"][0]["value"];
            }
        } catch (BadRequestHttpException | \Exception $error) {
            $this->logger->error($error->getMessage());
        }

        $responseObject = [
            "api_roots" => [
                "https://$systemHost/api/taxii2/1/"
            ],
            "contact" => "fsr-integrations@fortinet.com",
            "default" => "https://$systemHost/api/taxii2/1/",
            "description" => "TAXII 2.1 Server",
            "title" => "FortiSOAR Taxii 2.1 Server"
        ];
        $response = new Response();
        $response->headers->set('Content-Type', 'application/taxii+json;version=2.1');
        $response->setContent(json_encode($responseObject));
        return $response;
    }

    /**
     * @Route("api/taxii/1/", name="app_api_root_info", methods={"GET"})
     * @Route("api/taxii2/1/", name="app_api_root_info_taxii2", methods={"GET"})
     */
    public function getTaxiiRootApiInfo()
    {
        $module = self::THREAT_FEED_MODULE_NAME;
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $module)) {
            throw new AccessDeniedException();
        }
        $responseObject = [
            "max_content_length" => 1000000,
            "title" => "TAXII feeds",
            "versions" => [
                "application/taxii+json;version=2.1"
            ]
        ];
        $response = new Response();
        $response->headers->set('Content-Type', 'application/taxii+json;version=2.1');
        $response->setContent(json_encode($responseObject));
        return $response;
    }

    /**
     * @Route("api/taxii/1/collections", name="app_api_feeds_collections", methods={"GET"})
     * @Route("api/taxii2/1/collections", name="app_api_feeds_collections_taxii2", methods={"GET"})
     */
    public function getFeedsCollection(Request $request)
    {
        $isTimSkuEnabled = $this->utilityService->isTimSkuEnabled();
        $module = self::THREAT_FEED_MODULE_NAME;
        $systemSettingRepo = $this->entityManager->getRepository(SystemSettings::class);
        $taxiiSettingObj = $systemSettingRepo->findOneBy(['name' => "TAXII Server Details"]);
        if (!is_null($taxiiSettingObj) && !$taxiiSettingObj->getPublicValues()['status']['enabled']) {
            throw new BadRequestHttpException(ErrorConstants::TAXII_SERVER_DISABLED);
        }
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $module)) {
            throw new AccessDeniedException("Access Denied");
        }

        // Keeping default value as 100 for query result, for backward compatability.
        // Limiting the count of collection being return for non SKU
        // This needs to be confirmed from PM too

        $queryLimit = $isTimSkuEnabled ? $request->get('$limit', 100) : AppConstants::TOTAL_RESTRICTED_COLLECTIONS_COUNT;
        $queryPage = $isTimSkuEnabled ? $request->get('$page', 1) : AppConstants::TOTAL_RESTRICTED_FEEDS_PAGE;

        $systemQueryRepo = $this->entityManager->getRepository(SystemQuery::class);
        $feedCollectionsQueryBuilder = $systemQueryRepo->createQueryBuilder('o')
            ->join('o.models', 'm')
            ->andWhere('m.type = :types')
            ->setParameter('types', $module);

        if (!$isTimSkuEnabled) {
            $feedCollectionsQueryBuilder->setFirstResult($queryLimit * ($queryPage - 1));
            $feedCollectionsQueryBuilder->setMaxResults($queryLimit);
        }

        $feedCollections = $feedCollectionsQueryBuilder->getQuery()->getResult();

        $collectionList = [];
        $collectionList['collections'] = [];
        if (!empty($feedCollections)) {
            foreach ($feedCollections as $filter) {
                $collectionList['collections'][] = [
                    "name" => $filter->getName(),
                    "title" => $filter->getName(),
                    "id" => $filter->getUuid(),
                    "can_read" => true,
                    "can_write" => false,
                    "uuid" => $filter->getUuid(),
                    "media_types" => ["application/stix+json;version=2.1"]
                ];
            }
        }
        $response = new Response();
        $response->headers->set('Content-Type', 'application/taxii+json;version=2.1');
        $response->setContent(json_encode($collectionList));
        return $response;
    }


    private function getRequestContext($request, $attributes, $selectFields = null)
    {
        $request->overrideGlobals();
        $context = $this->serializerContextBuilder->createFromRequest($request, true, $attributes);
        $context["relationships"] =  false;
        $context["ignore_authorization"] =  true;
        $context["ignore_field_authorization"] =  true;
        $context["ignore_relationship_authorization"] =  true;
        $context["displayNameOnly"] =  true;
        $context[AppConstants::RFC_3339_DATE_FORMAT_KEY] =  true;
        if ($selectFields) {
            $context['groups'] = explode(',', $selectFields);
        }
        $context['ignored_attributes'] = AppConstants::STIX_TRAITS_ATTRIBUTES;
        return $context;
    }

    private function identifyQueryLimitAndPage($request)
    {
        $isTimSkuEnabled = $this->utilityService->isTimSkuEnabled();
        $queryLimit = $request->get('$limit', $request->get('limit', 30));
        $queryPage = $request->get('$page', $request->get('next', 1));
        if (!$isTimSkuEnabled) {
            $maxQueryLimit = $this->utilityService->getRequiredLicenseDetails(CacheConstants::TIM_SUPPORTED_QUERY_LIMIT);
            // For non SKU User, we will only be sending max batch of 100 records.
            $maxQueryPage = ceil($maxQueryLimit / $queryPage);
            $queryLimit = $queryLimit > $maxQueryLimit ? $maxQueryLimit : $queryLimit;
            $queryPage = $queryPage > $maxQueryPage ? $maxQueryPage : $queryPage;
        }
        return [$queryLimit, $queryPage];
    }

    // Support Feed Listing
    // Support Filter Feed by Feed ID, Collection Name
    // Support Filter Feed by combination of Feed ID and Collection Name
    // All Response return are in Taxii 2.1 format

    /**
     * @Route("api/taxii/1/collections/{collectionId}/{objects?}/{objectId?}", name="app_api_feeds_export", requirements={"objectId"=".+"}, methods={"GET"})
     * @Route("api/taxii2/1/collections/{collectionId}/{objects?}/{objectId?}", name="app_api_feeds_export_taxii2", requirements={"objectId"=".+"}, methods={"GET"})
     */
    public function getFeeds(Request $request, $collectionId, $objects = 'objects', $objectId = null)
    {
        // Validate TAXII Server Status
        $systemSettingRepo = $this->entityManager->getRepository(SystemSettings::class);
        $taxiiSettingObj = $systemSettingRepo->findOneBy(['name' => "TAXII Server Details"]);
        if (!is_null($taxiiSettingObj) && !$taxiiSettingObj->getPublicValues()['status']['enabled']) {
            throw new BadRequestHttpException(ErrorConstants::TAXII_SERVER_DISABLED);
        }
        //Validate User Permissions
        $module = self::THREAT_FEED_MODULE_NAME;
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $module)) {
            throw new AccessDeniedException("Access Denied");
        }

        $resourceClass = ThreatIntel::class;
        $savedFilter = $this->getSavedFilter($collectionId);

        if (is_null($objects)) {
            return $this->getCollectionDetails($savedFilter);
        }

        $attributes = $this->prepareAttributes($request, $resourceClass);
        $filterObj = $this->prepareFilterObject($savedFilter, $objectId, $request);

        $this->queryProvider->setInitialQuery($filterObj);
        $context = $this->getRequestContext($request, $attributes, $request->get('$__selectFields', "fsr_primary,id"));

        $feedByCollection = $this->collectionDataProvider->getCollection($resourceClass, $attributes['collection_operation_name'], $attributes);
        if (empty($feedByCollection)) {
            throw new NotFoundHttpException();
        }

        $normalizedData = $this->normalizeData($feedByCollection, $context, $attributes['filters']['$page'], $request);

        return $this->createResponse($request, $normalizedData, $savedFilter, $context);
    }

    protected function getSavedFilter($collectionId)
    {
        $systemQueryRepo = $this->entityManager->getRepository(SystemQuery::class);
        $savedFilter = $systemQueryRepo->findOneBy(['uuid' => $collectionId]);
        if (is_null($savedFilter)) {
            throw new BadRequestHttpException(sprintf('Collection ID %s not found', $collectionId));
        }
        return $savedFilter;
    }

    protected function getCollectionDetails($savedFilter)
    {
        $response = new Response();
        $response->headers->set('Content-Type', 'application/taxii+json;version=2.1');
        $collectionDetails = [
            "name" => $savedFilter->getName(),
            "title" => $savedFilter->getName(),
            "id" => $savedFilter->getUuid(),
            "uuid" => $savedFilter->getUuid(),
            "can_read" => true,
            "can_write" => false,
            "media_types" => ["application/stix+json;version=2.1"]
        ];
        return $response->setContent(json_encode($collectionDetails));
    }


    protected function prepareAttributes(Request $request, $resourceClass)
    {
        [$queryLimit, $queryPage] = $this->identifyQueryLimitAndPage($request);
        $partial = $request->get('$partial', false);

        return [
            'filters' => ['$limit' => $queryLimit, '$page' => $queryPage, '$partial' => $partial],
            'resource_class' => $resourceClass,
            'collection_operation_name' => "get"
        ];
    }

    protected function getFilter($field, $operator, $type, $value)
    {
        return [
            AppConstants::QUERY_FILTER_FIELD => $field,
            AppConstants::QUERY_FILTER_OPERATOR => $operator,
            AppConstants::QUERY_FILTER_TYPE => $type,
            AppConstants::QUERY_FILTER_VAL => $value
        ];
    }

    protected function prepareFilterObject($savedFilter, $objectId, $request)
    {
        $added_after = 'added_after';
        $date_field = 'modified';
        $filterObj = $savedFilter->getQuery();
        if (!is_null($objectId)) {
            $filterObj['filters'][] = [
                "field" => "uuid",
                "operator" => "like",
                "type" => "primitive",
                "value" => '%' . $objectId . '%'
            ];
        }
        if ($request->query->has($added_after)) {
            $filterObj['filters'][] = $this->getFilter($date_field, FilterUtility::GREATER_THAN_EQUALS_OPERATOR, 'datetime', $request->query->get($added_after));
        }
        $filterObj['sort'][] = [
            AppConstants::QUERY_FILTER_FIELD => $date_field,
            AppConstants::QUERY_SORTING_DIRECTION => AppConstants::QUERY_SORT_ASC,
            AppConstants::QUERY_SORTING_FIELDNAME => $date_field
        ];
        return $filterObj;
    }

    protected function normalizeData($feedByCollection, $context, $queryPage, $request)
    {
        $normalizedData = $this->serializer->normalize($feedByCollection, 'jsonld', $context);

        $this->logger->debug("STEP 1 - Raw Serializer Output: " . json_encode($normalizedData));

        $normalizedData['totalItems'] = $normalizedData['hydra:totalItems'];
        unset(
            $normalizedData['@context'],
            $normalizedData['@id'],
            $normalizedData['@type'],
            $normalizedData['hydra:totalItems']
        );

        if (
            is_array($normalizedData["hydra:view"] ?? null)
            && isset($normalizedData["hydra:view"]["hydra:next"])
        ) {

            $normalizedData['more'] = true;
            $normalizedData['next'] = (string) ($queryPage + 1); // fixed precedence
        }

        $normalizedData['objects'] = $normalizedData['hydra:member'];

        $this->logger->debug("STEP 2 - After hydra:member mapping: ". json_encode($normalizedData['objects']));

        unset($normalizedData['hydra:member'], $normalizedData["hydra:view"]);

        if (
            $request->attributes->get('_route') == 'app_api_feeds_export_taxii2'
            || $request->query->get('stix') == '2.1'
        ) {

            foreach ($normalizedData['objects'] as $index => &$object) {

                $this->logger->debug("OBJECT {$index} - BEFORE ANY CHANGE: ". json_encode($object));
                // Rename keys
                foreach (self::RENAME_KEYS_MAP as $oldKey => $newKey) {
                    if ($oldKey === 'killChainPhases') {
                        continue;
                    }
                    if (isset($object[$oldKey])) {
                        $object[$newKey] = $object[$oldKey];
                        unset($object[$oldKey]);
                    }
                }

                $this->logger->debug("OBJECT {$index} - AFTER rename: ". json_encode($object));

                if (!isset($object['kill_chain_phases'])) {
                    if (isset($object['sourceData']['kill_chain_phases'])) {
                        $object['kill_chain_phases'] = $object['sourceData']['kill_chain_phases'];
                    } else {
                        $object['kill_chain_phases'] = [];
                    }
                }
                unset($object['killChainPhases']);

                // Ensure labels
                if (!isset($object['labels']) && isset($object['description'])) {
                    $object['labels'] = explode('; ', $object['description']);
                }

                // Ensure valid_from
                if (!isset($object['valid_from']) && isset($object['created'])) {
                    $object['valid_from'] = $object['created'];
                }

                // Format dates
                foreach (['created', 'modified', 'valid_from', 'first_seen', 'last_seen'] as $dateKey) {
                    if (isset($object[$dateKey]) && is_string($object[$dateKey])) {
                        $date = new \DateTime($object[$dateKey]);
                        $object[$dateKey] = $date->format('Y-m-d\TH:i:s.v\Z');
                    }
                }

                $this->logger->debug("OBJECT {$index} - AFTER date formatting: ". json_encode($object));

                if (isset($object['kill_chain_phases'])) {
                    $this->logger->debug("OBJECT {$index} - kill_chain BEFORE filtering: ". json_encode($object['kill_chain_phases']));
                }

                // Strict filtering
                $object = array_intersect_key(
                    $object,
                    array_flip(self::STIX_21_ALLOWED_PROPERTIES)
                );

                $this->logger->debug("OBJECT {$index} - AFTER filtering: ". json_encode($object));

                // Reorder properties
                $orderedObject = [];
                foreach (self::STIX_21_ALLOWED_PROPERTIES as $key) {
                    if (isset($object[$key])) {
                        $orderedObject[$key] = $object[$key];
                    }
                }
                $object = $orderedObject;

                $this->logger->debug("OBJECT {$index} - FINAL STIX OBJECT: ". json_encode($object));
            }

            unset($normalizedData['totalItems']);

            $this->logger->debug("STEP 3 - AFTER ALL OBJECT PROCESSING: ". json_encode($normalizedData));

            $collectionId = $request->attributes->get('collectionId');

            if ($collectionId) {
                $stixBundle = [
                    'type' => 'bundle',
                    'id' => 'bundle--' . $collectionId,
                    'spec_version' => '2.1'
                ];

                $normalizedData = array_merge($stixBundle, $normalizedData);

                $this->logger->debug("STEP 4 - FINAL BUNDLE: ". json_encode($normalizedData));
            }
        }

        return $normalizedData;
    }

    protected function createResponse(Request $request, $normalizedData, $savedFilter, $context)
    {
        $response = new Response();
        $accept = $request->headers->get('Accept', 'application/json');
        $format = $_GET['$format'] ?? null;

        if ($accept == 'text/csv' || $format == 'csv') {
            return $this->createCsvResponse($request, $normalizedData, $savedFilter, $context);
        }

        $response->headers->set('Content-Type', 'application/taxii+json;version=2.1');
        $response->setContent(json_encode($normalizedData));
        return $response;
    }

    protected function createCsvResponse(Request $request, $normalizedData, $savedFilter, $context)
    {
        $includeHeaders = json_decode($request->get('$includeHeaders', true));
        $filePath = $this->csvDir . $savedFilter->getName() . '-' . Uuid::uuid4()->toString() . '.csv';

        if (empty($normalizedData['objects'])) {
            $this->handleEmptyCsvData($filePath, $includeHeaders, $context);
        } else {
            $this->createCSV($normalizedData['objects'], $filePath, $includeHeaders, ThreatIntel::class);
        }
        // Prepare CSV File response
        $response = new Response();
        $fileContent = file_get_contents($filePath);

        $response->headers->set('Content-Type', 'text/csv');
        $response->headers->set('Content-Disposition', 'attachment; filename="' . basename($filePath) . '"');
        $response->headers->set('filename', basename($filePath));
        $response->headers->set('Content-Length', filesize($filePath));
        $response->setContent($fileContent);

        unlink($filePath);
        return $response;
    }

    protected function handleEmptyCsvData($filePath, $includeHeaders, $context)
    {
        $threatIntelRepository = $this->entityManager->getRepository('\App\Entity\Custom\ThreatIntel');
        $sampleRecord = $threatIntelRepository->createQueryBuilder('o')
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();

        if ($sampleRecord) {
            // Normalize the sample record to get its structure
            $sampleContext = $context;
            $sampleNormalized = $this->serializer->normalize([$sampleRecord], 'jsonld', $sampleContext);
            $this->createCSV($sampleNormalized['hydra:member'], $filePath, $includeHeaders);

            // Clear the CSV data except headersz
            if ($includeHeaders) {
                $csvContent = file_get_contents($filePath);
                $lines = explode(PHP_EOL, $csvContent);
                if (count($lines) > 1) {
                    // Keep only the header line
                    file_put_contents($filePath, $lines[0] . PHP_EOL);
                }
            } else {
                throw new NotFoundHttpException('No record found matching the given objects ID');
            }
        } else {
            throw new NotFoundHttpException('No record found matching the given objects ID');
        }
    }

    protected function createCSV($normalizedObject, $filePath, $includeHeaders = true)
    {
        $headers = [];
        $csvData = [];

        if ($includeHeaders) {
            // Extract headers from the first object
            foreach ($normalizedObject[0] as $key => $value) {
                if ($key == "@id" || $key == "@type") {
                    continue;
                }
                $headers[] = $key;
            }
            $csvData[0] = $headers;
        }

        // Process data rows if there are any
        foreach ($normalizedObject as $index => $objects) {
            $data = [];
            foreach ($objects as $key => $value) {
                if (!is_array($value)) {
                    if ($key == "@id" || $key == "@type") {
                        continue;
                    }
                    $data[] = $value;
                } else {
                    $data[] = implode(',', $value);
                }
            }
            $row = $includeHeaders ? (int) $index + 1 : (int) $index;
            $csvData[$row] = $data;
        }

        $fp = fopen($filePath, 'wb');
        foreach ($csvData as $line) {
            fputcsv($fp, $line, ',');
        }
        fclose($fp);

        return $filePath;
    }
}
