<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Psr\Log\LoggerInterface;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use App\Service\BulkRequestService;
use Symfony\Component\HttpFoundation\Request;
use ApiPlatform\Core\Api\IriConverterInterface;
use App\Providers\PermissionsDictionaryBuilder;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class BulkUpdateController extends BaseController
{

    public function __construct(
        private FsrVoter $fsrVoter,
        ResourceClassResolverInterface $resourceClassResolver,
        ContainerInterface $containers,
        private IriConverterInterface $iriConverter,
        SerializerInterface $serializer,
        protected BulkRequestService $bulkRequestService,
        MetadataHelper $metadataHelper,
        TagAwareCacheInterface $cache,
        protected LoggerInterface $logger
    ) {
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function bulkUpdateAction(Request $request, $moduletype)
    {
        $resourceClass = $this->getResourceFromClassName($moduletype);
        $module = $this->metadataHelper->getModuleFromClassName($resourceClass);
        if (!($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . $module))) {
            throw new AccessDeniedException();
        }
        $resourceClass = $this->getResourceFromClassName($moduletype);

        // TODO: validate if payload is an array or single object
        $objectData = json_decode($request->getContent());
        $headers = $request->headers->all();
        $queryParams = $request->query->all();
        return $this->bulkRequestService->prepareUpdateDeleteSubRequest($resourceClass, $objectData, '/api/3/' . $moduletype, $headers, $queryParams, 'PUT');
    }
}
