<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Service\SKUService;
use App\Constants\AppConstants;
use App\Service\UtilityService;
use App\Constants\CacheConstants;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class FeatureController extends AbstractController
{
    public function __construct(
        protected SKUService $skuService,
        protected UtilityService $utilityService
    ) {}

    public function getFeatureControls(Request $request)
    {
        $queryParams = $request->query->all();
        $required_prop = $queryParams[AppConstants::FEATURE_PROPERTY] ?? AppConstants::UI_PROP;

        $productType = $this->utilityService->getRequiredLicenseDetails(CacheConstants::PRODUCT_TYPE);
        $licenseSubType = $this->utilityService->getRequiredLicenseDetails(CacheConstants::SUB_TYPE);
        $productTypeKey = null;


        switch ($productType) {
            case AppConstants::PRODUCT_TYPE['fortitip']:
                $productTypeKey = AppConstants::FORTI_TIP_TYPE_KEYS[$productType . '-' . $licenseSubType];
                $licenseBasedFeatureData = $this->skuService->fetchLicenseBasedFeatureDetails(
                    AppConstants::FORTI_TIP_FEATURE_CONTROL_JSON,
                    $productTypeKey,
                    $required_prop
                );
                $fortiTipType = $this->mapLicenseSubTypeToFortiTipType($licenseSubType);
                $productDetails = sprintf("%s %s", $productType, $fortiTipType);
                break;
            default:
                // Default case is for FortiSOAR
                $productTypeKey = AppConstants::FORTI_SOAR_TYPE_KEYS[$productType . '-' . $licenseSubType];
                $licenseBasedFeatureData = $this->skuService->fetchLicenseBasedFeatureDetails(
                    AppConstants::FORTI_SOAR_FEATURE_CONTROL_JSON,
                    $productTypeKey,
                    $required_prop
                );
                $fortiSoarType = $licenseSubType == AppConstants::LICENSE_SUB_TYPE['trial']
                    ? AppConstants::FORTI_SOAR_TYPES['trial']
                    : AppConstants::FORTI_SOAR_TYPES['enterprise'];
                $productDetails = sprintf("%s %s", $productType, $fortiSoarType);
                break;
        }
        return new JsonResponse(array_merge($licenseBasedFeatureData, ['productType' => $productDetails]));
    }

    private function mapLicenseSubTypeToFortiTipType($licenseSubType)
    {
        switch ($licenseSubType) {
            case $licenseSubType == AppConstants::LICENSE_SUB_TYPE['trial']:
                return AppConstants::FORTI_TIP_TYPES['outbreak'];
            case $licenseSubType == AppConstants::LICENSE_SUB_TYPE['paid']:
                return AppConstants::FORTI_TIP_TYPES['enterprise'];
            case $licenseSubType == AppConstants::LICENSE_SUB_TYPE['tip_essential']:
                return AppConstants::FORTI_TIP_TYPES['tip_essential'];
            case $licenseSubType == AppConstants::LICENSE_SUB_TYPE['tip_full_suite']:
                return AppConstants::FORTI_TIP_TYPES['tip_full_suite'];
        }
    }
}
