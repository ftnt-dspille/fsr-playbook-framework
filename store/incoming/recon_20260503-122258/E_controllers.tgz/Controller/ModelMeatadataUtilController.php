<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Security\Voter\FsrVoter;
use Doctrine\Inflector\InflectorFactory;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Doctrine\Inflector\Inflector as LegacyInflector;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;


class ModelMeatadataUtilController extends AbstractController
{
    protected $inflector;

    public function __construct(protected FsrVoter $fsrVoter)
    {
        $this->inflector = InflectorFactory::create()->build();
    }
    public function getAction(Request $request)
    {
        $metaData = [];
        $requestBody = json_decode($request->getContent(), true);
        if (!$this->fsrVoter->isGranted("read.application")) {
            throw new AccessDeniedException();
        }
        $moduleName = $requestBody['module'];
        $moduleName = preg_replace('/[^a-z0-9\s]+/i', '', $moduleName);
        $escapedModuleName = $this->inflector->classify($moduleName);
        $escapedSingular = $this->inflector->singularize($moduleName);
        $escapedPlural = $this->inflector->pluralize($moduleName);

        $metaData['singular'] = $escapedSingular;
        $metaData['plural'] =  $escapedPlural;
        $metaData['type'] = \strtolower($this->inflector->tableize($this->inflector->classify($escapedPlural)));
        $metaData['tableName'] =  \strtolower($this->inflector->tableize($escapedModuleName));
        return new JsonResponse($metaData);
    }
}
