<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Constants\ErrorConstants;
use App\Service\ViewTemplateService;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\ViewTemplate\UserViewTemplate;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Exception\BadRequestException;

class ViewTemplateController extends AbstractController
{

    protected $viewTemplateService;

    public function __construct(
        ViewTemplateService $viewTemplateService,
        protected SerializerInterface $serializer
    ) {
        $this->viewTemplateService = $viewTemplateService;
        $this->serializer = $serializer;
    }

    /**
     * @param $name
     * @return JsonResponse
     */
    public function getAction($name)
    {
        $serializer = $this->serializer;
        if (!$name) {
            throw new BadRequestException(ErrorConstants::FSR_CH_0000028);
        }

        // If name provided then response will contain that UVT/SVT
        $viewTemplate = $this->findOrThrowNotFound($name);
        $normalizedViewTemplate = $serializer->normalize($viewTemplate, 'json');
        return new JsonResponse($normalizedViewTemplate);
    }

    /**
     * @param $name
     * @return JsonResponse
     */
    public function upsertViewTemplate($name, Request $request)
    {
        $viewTemplateProvider = $this->viewTemplateService;
        $serializer = $this->serializer;

        $content = $request->getContent();
        $vtData = json_decode($content, true) ?? [];

        if (!$vtData) {
            throw new BadRequestException(ErrorConstants::FSR_CH_0000027);
        }

        $vtDataFilters = is_array($vtData) && array_key_exists('filters', $vtData) ? $vtData['filters'] : [];
        $filters["params"] = $vtDataFilters;

        // UVT PUT/POST
        /** @var UserViewTemplate $userViewTemplate */
        $userViewTemplate = $serializer->deserialize(
            $request->getContent(),
            UserViewTemplate::class,
            'jsonld',
            [
                'object_to_populate' => $this->findOrThrowNotFound($name, $filters),
                'ignore_authorization' => true,
                'ignore_field_authorization' => true
            ]
        );
        $viewTemplateProvider->saveViewTemplate($name, $userViewTemplate);
        $normalizedViewTemplate = $serializer->normalize($userViewTemplate, 'json');
        return new JsonResponse($normalizedViewTemplate);
    }

    /**
     * @param $name
     * @return mixed
     */
    private function findOrThrowNotFound($name, $filters = [])
    {
        $viewOptions = null;
        $module = null;
        $filters = array_key_exists("params", $filters) ? $filters["params"] : [];

        if (str_starts_with($name, 'modules')) {
            $explodedOldUuid = explode('-', $name);
            $module = $explodedOldUuid[1];
            $viewOptions = $explodedOldUuid[2];
        } else if (str_starts_with($name, 'pages')){
            $explodedOldUuid = explode('-', $name);
            $module = $explodedOldUuid[1];
            $viewOptions = 'detail';
        } else {
            $module = $name;
        }

        $viewTemplateProvider = $this->viewTemplateService;
        return $viewTemplateProvider->getViewTemplate($module, $viewOptions, $filters);
    }
}
