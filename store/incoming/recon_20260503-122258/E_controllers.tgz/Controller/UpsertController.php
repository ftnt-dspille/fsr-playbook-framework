<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use stdClass;
use Psr\Log\LoggerInterface;
use App\Service\MetadataHelper;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use App\Entity\Workflow\Workflow;
use App\Controller\BaseController;
use App\Service\BulkRequestService;
use Doctrine\Inflector\InflectorFactory;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class UpsertController extends BaseController
{

    protected $entityManager;
    protected $queryProvider;
    protected $serializerContextBuilder;
    protected $fsrVoter;
    protected $eventDispatcher;
    protected $validator;
    protected $bulkRequestService;
    protected $utilityService;

    public function __construct(
        ResourceClassResolverInterface $resourceClassResolver,
        ContainerInterface $containers,
        FsrVoter $fsrVoter,
        EntityManagerInterface $entityManager,
        MetadataHelper $metadataHelper,
        UtilityService $utilityService,
        BulkRequestService $bulkRequestService,
        TagAwareCacheInterface $cache,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->entityManager = $entityManager;
        $this->bulkRequestService = $bulkRequestService;
        $this->inflector = InflectorFactory::create()->build();
        $this->utilityService = $utilityService;
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    const DISALLOWED_MODULES = ['actors', 'files', 'images'];

    public function upsertAction(Request $request, $resourceShortName)
    {
        if (in_array($resourceShortName, self::DISALLOWED_MODULES)) {
            throw new BadRequestHttpException(sprintf(ErrorConstants::UPSERT_NOT_SUPPORTED, $resourceShortName));
        }
        $resource = $this->getResourceFromClassName($resourceShortName);
        $requestBody = json_decode($request->getContent());

        [$filterItems, $module] = $this->utilityService->getUniqueResourceFields($requestBody, $resourceShortName);

        $replaceIfExist = isset($requestBody->{'__replace'}) ? $requestBody->{'__replace'} : true;
        $this->bulkRequestService->updateReferenceToIriAndCheckForRelation($requestBody);

        $dataFilters = $this->utilityService->prepareFilterData($requestBody, $filterItems, $resource);
        $object = [];
        if ($dataFilters) {
            $entityRepo = $this->entityManager->getRepository($resource);
            if (array_key_exists('softdeleteable', $this->entityManager->getFilters()->getEnabledFilters())) {
                $this->entityManager->getFilters()->disable('softdeleteable');
            }
            $object = $this->utilityService->getItemWithWhere($entityRepo, $dataFilters);
        }

        if (!empty($object) && method_exists($object[0], 'getDeletedAt') && $object[0]->getDeletedAt() != null) {
            if (array_key_exists('deletedAt', $requestBody) && $requestBody->deletedAt === Null) {
                $requestBody = ["deletedAt" => Null];
            } else {
                throw new NotFoundHttpException();
            }
        }
        if (!empty($object) && !$replaceIfExist) {
            return $this->getSuccessResponse($object[0], $resource);
        }
        if (!empty($object)) {
            // Existing Object Found, trying to update the existing object
            if (!$this->fsrVoter->isGranted("update." . $module)) {
                throw new AccessDeniedException();
            }
            $object = $object[0];
            $classPath = get_class($object);
            $this->utilityService->validateOwnerShip($request, $object);
            $groups = $this->utilityService->identifyChangeFields($requestBody, $classPath);

            // As per change in computation of workflow and other component
            $normalizedPreviousData = $this->serializer->normalize(
                $object,
                'jsonld',
                ["asJson" => true, "relationships" => true, "groups" => $groups, "ignore_html_escape" => true]
            );
            $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
            $request->attributes->set('fsr_change_fields', $groups);
            $request->attributes->set('_api_item_operation_name', 'put');
            $request->attributes->set('previous_data', clone $object);
            unset($requestBody->{'uuid'});
            if (isset($requestBody->{'__fieldsToUpdate'}) && !empty($requestBody->{'__fieldsToUpdate'})) {
                $modifiedRequestBody = new stdClass();
                if (isset($requestBody->{'__link'})) {
                    $modifiedRequestBody->{'__link'} = new stdClass();
                }
                foreach ($requestBody->{'__fieldsToUpdate'} as $key) {
                    if (property_exists($requestBody, $key) && !is_null($requestBody->$key)) {
                        $modifiedRequestBody->{$key} = $requestBody->$key;
                    }
                    if (isset($requestBody->{'__link'}->{$key}) && !is_null($requestBody->{'__link'}->{$key})) {
                        $modifiedRequestBody->{'__link'}->{$key} = $requestBody->{'__link'}->{$key};
                    }
                }
                $requestBody = $modifiedRequestBody;
            }
            $denormalizedObject = $this->serializer->deserialize(
                json_encode($requestBody),
                $resource,
                'jsonld',
                ['object_to_populate' => $object, 'fetch_data' => false, '_is_update' => true]
            );
        } else {
            // Create the new record
            if (!$this->fsrVoter->isGranted("create." . $module)) {
                throw new AccessDeniedException();
            }
            $denormalizedObject = $this->serializer->deserialize(
                $request->getContent(),
                $resource,
                'jsonld',
                ['fetch_data' => false]
            );
            $request->attributes->set('_api_collection_operation_name', 'post');
            $request->attributes->set('_api_item_operation_name', 'post');
        }
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->overrideGlobals();
        return $denormalizedObject;
    }

    public function bulkUpsertAction(Request $request, $resourceShortName, $objectData = null)
    {
        $resourceClass = $this->getResourceFromClassName($resourceShortName);
        $objectDataClone = new stdClass();
        $headers = $request->headers->all();
        $queryParams = $request->query->all();

        if (is_null($objectData)) {
            $objectData = json_decode($request->getContent());
            if (isset($objectData->{self::SELECTIVE_FIELDS})) {
                $selectedFields = $objectData->{self::SELECTIVE_FIELDS};
                $queryParams[self::SELECTIVE_FIELDS] = implode(',', $selectedFields);
            }
            if (isset($objectData->{'data'})) {
                $objectDataClone = $objectData;
            } elseif (isset($objectData->{'__data'})) {
                $objectDataClone->{'data'} = $objectData->{'__data'};
            } else {
                $objectDataClone->{'data'} = $objectData;
            }

            if (empty($objectDataClone->{'data'})) {
                return new JsonResponse(["message" => "No data provided", "hydra:member" => []]);
            }

            if (isset($objectData->{"__unique"})) {
                foreach ($objectDataClone->{'data'} as $data) {
                    $data->{'__unique'} = $objectData->{'__unique'};
                }
            }

            if (isset($objectData->{"__replace"})) {
                foreach ($objectDataClone->{'data'} as $data) {
                    $data->{'__replace'} = $objectData->{'__replace'};
                }
            }

            if (isset($objectData->{"__fieldsToUpdate"})) {
                foreach ($objectDataClone->{'data'} as $data) {
                    $data->{'__fieldsToUpdate'} = $objectData->{'__fieldsToUpdate'};
                }
            }
        } else {
            $objectDataClone->{'data'} = $objectData;
        }

        return $this->bulkRequestService->prepareRecordSubRequest(
            $resourceClass,
            $objectDataClone,
            '/api/3/upsert/' . $resourceShortName,
            $headers,
            $queryParams
        );
    }

    public function bulkUpsertWorkflowAction(Request $request)
    {
        $requestData = json_decode($request->getContent());
        $unique = isset($requestData->{'__unique'}) ? $requestData->__unique : ["uuid"];
        $requestData = isset($requestData->{'__data'}) ? $requestData->__data : $requestData;
        $objectDatas = json_decode(json_encode($requestData), true);
        $objectDatas = $this->upsertWorkflows($objectDatas);
        $finalData = array_map(function ($subArray) use ($unique) {
            return $subArray + ['__unique' => $unique];
        }, $objectDatas);
        return $this->bulkUpsertAction($request, 'workflows', json_decode(json_encode($finalData)));
    }

    public function bulkUpsertWorkflowCollectionsAction(Request $request)
    {
        $requestData = json_decode($request->getContent());
        $unique = isset($requestData->{'__unique'}) ? $requestData->__unique : ["uuid"];
        $requestData = isset($requestData->{'__data'}) ? $requestData->__data : $requestData;
        $objectDatas = json_decode(json_encode($requestData), true);
        $objectDatas = $this->upsertWorkflowCollections($objectDatas);
        $finalData = array_map(function ($subArray) use ($unique) {
            return $subArray + ['__unique' => $unique];
        }, $objectDatas);
        return $this->bulkUpsertAction($request, 'workflow_collections', json_decode(json_encode($finalData)));
    }

    public function modify_workflow_steps_routes($existingItems, $newItems, $prefix)
    {
        foreach ($newItems as $index => $newItem) {
            foreach ($existingItems as $existingItem) {
                if ($existingItem->getUuid() == $newItem['uuid']) {
                    $newItems[$index]['@id'] = $prefix . $newItem['uuid'];
                    break;
                }
            }
        }
        return $newItems;
    }

    public function upsertWorkflowCollections($workflowCollections)
    {
        foreach ($workflowCollections as $index => $workflowCollection) {
            $workflows = $workflowCollection['workflows'];
            $workflowCollections[$index]['workflows'] = $this->upsertWorkflows($workflows);
        }
        return $workflowCollections;
    }


    public function upsertWorkflows($workflows)
    {
        foreach ($workflows as $index => $workflow) {
            $workflowsResource = $this->getResourceFromClassName('workflows');
            $dataFilters = $this->utilityService->prepareFilterData($workflow, ['uuid'], $workflowsResource);
            $workflowRepository = $this->entityManager->getRepository(Workflow::class);
            $object = $this->utilityService->getItemWithWhere($workflowRepository, $dataFilters);
            if (count($object)) {
                $workflow['@id'] = '/api/3/workflows/' . $workflow['uuid'];
                $workflow['steps'] =  $this->modify_workflow_steps_routes($object[0]->getSteps(), $workflow['steps'], '/api/3/workflow_steps/');
                $workflow['routes'] = $this->modify_workflow_steps_routes($object[0]->getRoutes(), $workflow['routes'], '/api/3/workflow_routes/');
            }
            $workflows[$index] = $workflow;
        }
        return $workflows;
    }
}
