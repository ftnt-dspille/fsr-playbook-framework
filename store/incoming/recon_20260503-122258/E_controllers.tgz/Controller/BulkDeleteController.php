<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use stdClass;
use Psr\Log\LoggerInterface;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use App\Service\BulkRequestService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use ApiPlatform\Core\Api\IriConverterInterface;
use App\Providers\PermissionsDictionaryBuilder;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class BulkDeleteController extends BaseController
{
    /** @var  FsrVoter */
    private $fsrVoter;
    protected $bulkRequestService;

    public function __construct(
        FsrVoter $fsrVoter,
        ResourceClassResolverInterface $resourceClassResolver,
        ContainerInterface $containers,
        private IriConverterInterface $iriConverter,
        SerializerInterface $serializer,
        BulkRequestService $bulkRequestService,
        protected MetadataHelper $metadataHelper,
        TagAwareCacheInterface $cache,
        protected LoggerInterface $logger
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->iriConverter = $iriConverter;
        $this->bulkRequestService = $bulkRequestService;
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function bulkDeleteAction(Request $request, $moduletype)
    {
        $resourceClass = $this->getResourceFromClassName($moduletype);
        $module = $this->metadataHelper->getModuleFromClassName($resourceClass);
        $objectDataClone = new stdClass();
        if (!($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . $module))) {
            throw new AccessDeniedException();
        }

        // TODO: validate if payload is an array or single object
        $objectData = json_decode($request->getContent());
        $ids = $objectData->ids;
        $nonLocalNonRepoSpClean = property_exists($objectData, 'nonLocalNonRepoSpClean') ? $objectData->nonLocalNonRepoSpClean : false;

        if (count($ids) < 1) {
            return new Response("Deleted", Response::HTTP_OK);
        }

        $iriList = [];
        foreach ($ids as $index => $id) {
            $item = new stdClass();
            $item->{'@id'} = '/api/3/' . $moduletype . '/' . $id;
            if ($nonLocalNonRepoSpClean) {
                $item->{'nonLocalNonRepoSpClean'} = $nonLocalNonRepoSpClean;
            }
            $iriList[] = $item;
        }
        $objectDataClone->{'data'} = $iriList;
        $headers = $request->headers->all();
        $queryParams = $request->query->all();
        return $this->bulkRequestService->prepareUpdateDeleteSubRequest($resourceClass, $objectDataClone, '/api/3/' . $moduletype, $headers, $queryParams, 'DELETE');
    }
}
