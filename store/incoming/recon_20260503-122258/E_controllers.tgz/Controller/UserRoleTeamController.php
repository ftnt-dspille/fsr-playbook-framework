<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Psr\Log\LoggerInterface;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use Symfony\Component\HttpFoundation\Request;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class UserRoleTeamController extends BaseController
{
    /** @var FsrVoter */
    private $fsrVoter;

    public function __construct(
        FsrVoter $fsrVoter,
        protected SerializerInterface $serializer,
        ResourceClassResolverInterface $resourceClassResolver,
        ContainerInterface $containers,
        TagAwareCacheInterface $cache,
        MetadataHelper $metadataHelper,
        protected LoggerInterface $logger
    ) {
        $this->fsrVoter = $fsrVoter;
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    /**
     * @param string $moduleName
     * @param string $action
     * @return JsonResponse
     */
    public function getAction(Request $request)
    {
        $this->fsrVoter->denyUnlessAccessGranted(
            PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . PermissionsDictionaryBuilder::MODULE_APPLICATION
        );
        $personClass = $this->getResourceFromClassName('people');
        $normalizedTeamData = $this->serializer->normalize(
            $this->getUser(),
            BaseController::NORMALIZER_METHOD,
            [
                'resource_class' => $personClass,
                'groups' => ['teams', 'roles', 'uuid'],
                'ignore_authorization' => true,
                'ignore_field_authorization' => true,
                'ignore_relationship_authorization' => false,
                'item_operation_name' => 'get',
                'collection_operation_name' => 'get',
            ]
        );

        return new JsonResponse($normalizedTeamData);
    }
}
