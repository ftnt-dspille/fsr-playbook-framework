<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use ApiPlatform\Core\Exception\InvalidArgumentException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Finder\Exception\AccessDeniedException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Contracts\Cache\TagAwareCacheInterface;

class CacheUtilController extends AbstractController
{
    /** @var TagAwareCacheInterface */
    private $cache;

    public function __construct(TagAwareCacheInterface $cache)
    {
        $this->cache = $cache;
    }

    public function handleCacheAction(Request $request)
    {
        // no permission check will allow only localhost
        if ($request->getHost() !== 'localhost') {
            throw new AccessDeniedException();
        }
        $payload = json_decode($request->getContent(), true);
        $operation = $payload['operation'];
        if ($operation == "clear-cache") {
            opcache_reset();
            apcu_clear_cache();
            return new JsonResponse();
        } elseif ($operation == "invalidate-tag") {
            if (array_key_exists('tags', $payload)) {
                $tags = $payload['tags'];
                if (count($tags) > 0) {
                    $this->cache->invalidateTags($tags);
                }
            }
            return new JsonResponse();
        }
        throw new InvalidArgumentException();
    }
}
