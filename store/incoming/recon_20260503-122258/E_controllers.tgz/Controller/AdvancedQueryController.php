<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Service\IriHelper;
use App\Entity\Query\Query;
use Psr\Log\LoggerInterface;
use App\Service\MetadataHelper;
use App\Service\UtilityService;
use App\Providers\QueryProvider;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use App\Providers\DeleteProvider;
use App\Constants\AggregateOperators;
use Doctrine\ORM\Mapping\ClassMetadata;
use Doctrine\Inflector\InflectorFactory;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use App\Providers\AggregateDataProviderInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use ApiPlatform\Serializer\SerializerContextBuilderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use ApiPlatform\Core\DataProvider\CollectionDataProviderInterface;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use ApiPlatform\Core\Metadata\Resource\Factory\ResourceMetadataFactoryInterface;

class AdvancedQueryController extends BaseController
{
    public const DEFAULT_KEYS = ['id', '@id', '@type'];
    public const SELECTIVE_FIELD_KEY = '__selectFields';
    public const IGNORE_FIELD_KEY = '__ignoreFields';

    protected $inflector;

    public function __construct(
        protected ResourceClassResolverInterface $resourceClassResolver,
        private QueryProvider $queryProvider,
        private CollectionDataProviderInterface $collectionDataProvider,
        private IriHelper $iriHelper,
        private UtilityService $utilityService,
        private SerializerContextBuilderInterface $serializerContextBuilder,
        protected ContainerInterface $containers,
        protected FsrVoter $fsrVoter,
        protected ResourceMetadataFactoryInterface $resourceMetadataFactory,
        protected AggregateDataProviderInterface $aggregateDataProvider,
        protected TagAwareCacheInterface $cache,
        protected MetadataHelper $metadataHelper,
        private DeleteProvider $deleteProvider,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->inflector = InflectorFactory::create()->build();
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function applyQuery(Request $request, $resourceShortName)
    {
        $perm = $this->utilityService->getModulePermission($resourceShortName);
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $perm)) {
            throw new AccessDeniedException();
        }
        $resource = $this->getResourceFromClassName($resourceShortName);

        // if (!$this->utilityService->isTimSkuEnabled() && $resource == "App\\Entity\\Custom\\ThreatIntel") {
        //     $this->logger->info(ErrorConstants::TIM_QUERY_ROUTE_RESTRAINT);
        //     throw new BadRequestHttpException(ErrorConstants::TIM_QUERY_ROUTE_RESTRAINT);
        // }
        $content = $request->getContent();
        $query = json_decode($content, true) ?? [];
        $data = $this->evaluateQuery($request, $query, $resource);
        return new JsonResponse($data);
    }

    public function applyNamedQuery()
    {
        // Empty placeholder
    }

    protected function evaluateQuery($request, $query, $resource)
    {

        $this->queryProvider->setInitialQuery($query);
        $queryLimit = $request->get('$limit', 30);
        $queryPage = $request->get('$page', 1);
        $partial = $request->get('$partial', false);
        $attributes = [];
        $attributes['resource_class'] = $resource;
        $attributes['collection_operation_name'] = "get";
        $attributes['filters'] = ['$limit' => $queryLimit, '$page' => $queryPage, '$partial' => $partial];
        $attributes['_fsr_dynamic_context'] = false;

        /** @var AggregateDataProviderInterface $aggregateDataProvider */
        $data = $this->isAggregateQuery($query) ?
            $this->aggregateDataProvider->getAggregate($resource, $request, $query) :
            $this->collectionDataProvider->getCollection($resource, $attributes['collection_operation_name'], $attributes);
        $serializer = $this->container->get('serializer');

        $context = $this->serializerContextBuilder->createFromRequest($request, true, $attributes);
        return $serializer->normalize($data, 'jsonld', $context);
    }

    protected function isAggregateQuery($query)
    {
        $isAggregateQuery = false;
        if (array_key_exists(Query::KEYWORD_AGGREGATES, $query)) {
            foreach ($query[Query::KEYWORD_AGGREGATES] as $aggregate) {
                if (!in_array($aggregate['operator'], [AggregateOperators::SELECT, AggregateOperators::FIELDS])) {
                    $isAggregateQuery = true;
                    break;
                }
            }
        }
        return $isAggregateQuery;
    }

    public function queryAssociationAction(Request $request, $resourceShortName, $id, $field)
    {
        $resourceClass = $this->getResourceFromClassName($resourceShortName);
        $module = $this->metadataHelper->getModuleFromClassName($resourceClass);

        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $module);
        $item = $this->iriHelper->findOrThrowNotFound('/api/3/' . $resourceShortName . '/' . $id);

        $this->utilityService->validateOwnerShip($request, $item);

        // Check Field Level Permissions
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_FIELD_READ . '.' . $module . '.' . $field);

        /** @var ManagerRegistry $managerRegistry */
        $managerRegistry = $this->container->get('doctrine');
        $manager = $managerRegistry->getManagerForClass($resourceClass);
        $classMetadata = $manager->getClassMetadata($resourceClass);
        if ($classMetadata->hasAssociation($field)) {
            /** @var ClassMetadata $classMetadata */
            $association = $classMetadata->associationMappings[$field];
            if (in_array($association['type'], [ClassMetadata::MANY_TO_MANY, ClassMetadata::ONE_TO_MANY, ClassMetadata::TO_MANY])) {
                if ($association['isOwningSide']) {
                    $inversedField = $association['inversedBy'];
                } else {
                    $inversedField = $association['mappedBy'];
                }
                $targetEntity = $association['targetEntity'];
                $associationResource = $targetEntity;
                $associationModule = $this->metadataHelper->getModuleFromClassName($associationResource);
                $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $associationModule);

                $associationFilter = [
                    'field' => $inversedField,
                    'operator' => 'eq',
                    'value' => $item->getUuid()
                ];
                if ($this->containers->hasParameter('ignore_rbac_for_related_record') && $this->containers->getParameter('ignore_rbac_for_related_record')) {
                    $GLOBALS['__associatedFieldRequest__'] = true;
                }
                $request->overrideGlobals();
                $resource = $this->getResourceFromClassName($associationModule);
                $content = $request->getContent();
                $associationQuery = json_decode($content, true) ?? [];
                $query = $associationQuery;
                $associationQueryLogic = $query['logic'];
                $associationQueryFilters = $query['filters'];
                $query['logic'] = 'AND';
                $query['filters'] = [
                    $associationFilter,
                    [
                        'logic' => $associationQueryLogic,
                        'filters' => $associationQueryFilters
                    ]
                ];
                $data = $this->evaluateQuery($request, $query, $resource);
                return new JsonResponse($data);
            }
        }
        throw new BadRequestHttpException(sprintf(ErrorConstants::FIELD_MISSING, $field, $resourceShortName));
    }

    public function deleteQuery(Request $request, $resourceShortName)
    {
        $perm = $this->utilityService->getModulePermission($resourceShortName);
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . $perm)) {
            throw new AccessDeniedException();
        }
        $resource = $this->getResourceFromClassName($resourceShortName);
        $content = $request->getContent();
        $query = json_decode($content, true) ?? [];
        $this->queryProvider->setInitialQuery($query);
        /** @var AggregateDataProviderInterface $aggregateDataProvider */
        $data = $this->deleteProvider->deleteQuery($resource, $query, $resourceShortName);
        return new JsonResponse(
            ["total_records_deleted" => $data],
            Response::HTTP_OK
        );
    }
}
