<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Psr\Log\LoggerInterface;
use App\Entity\Custom\Person;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use Doctrine\ORM\EntityManagerInterface;
use GuzzleHttp\Psr7\Request as GuzzleRequest;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use App\EventSubscriber\MqMessagebroadcastSubscriber;
use Symfony\Component\Serializer\SerializerInterface;
use ApiPlatform\Core\DataProvider\ItemDataProviderInterface;
use App\Constants\AppConstants;
use App\Constants\ErrorConstants;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class PasswordResetController extends AbstractController
{

    protected $fsrVoter;
    protected $containers;
    protected $tokenStorage;
    protected $itemDataProvider;
    protected $em;
    private $utilityService;

    public function __construct(
        FsrVoter $fsrVoter,
        ContainerInterface $containers,
        TokenStorageInterface $tokenStorage,
        ItemDataProviderInterface $itemDataProvider,
        EntityManagerInterface $entityManager,
        UtilityService $utilityService,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->containers = $containers;
        $this->tokenStorage = $tokenStorage;
        $this->itemDataProvider = $itemDataProvider;
        $this->em = $entityManager;
        $this->utilityService = $utilityService;
        $this->serializer = $serializer;
    }

    private function getDasClient()
    {
        return $this->containers->get("app.proxy.client.das");
    }

    private function getIntegrationClient()
    {
        return $this->containers->get("app.proxy.client.integrations");
    }

    private function getProxyClient()
    {
        return $this->containers->get("app.proxy.client.workflow");
    }

    private function getCurrentUser()
    {
        return $this->tokenStorage->getToken()->getUser();
    }

    public function checkAuthorization($method)
    {

        if (($method === 'POST') && !$this->fsrVoter->isGranted('create.security') && !$this->fsrVoter->isGranted('update:security')) {
            throw new AccessDeniedException();
        }
    }



    public function resetPasswordAction(Request $request)
    {

        $this->checkAuthorization($request->getMethod());
        $dasUri = $this->containers->getParameter('das.uri');
        $dasClient = $this->getDasClient();
        $objectData = json_decode($request->getContent(), true);
        $userId = $this->getCurrentUser()->getUserId();
        $headers = array(
            "Content-type" => "application/json",
        );
        
        // Get UUID using loginId
        $loginId = $objectData['loginId'] ?? null;

        if (!$loginId) {
            $errMsg['message'] = ErrorConstants::LOGIN_ID_REQ;
            $errCode = 400;
            return new JsonResponse($errMsg, $errCode);
        }

        $dasRequests = new GuzzleRequest('get', $dasUri . '/users?loginid=' . $loginId, $headers);

        try {
            $dasResponse = $dasClient->send($dasRequests);
            $dasResponseData = json_decode($dasResponse->getBody()->getContents());

            if (count($dasResponseData->usersresp)) {
                $uuid_from_loginId = $dasResponseData->usersresp[0]->uuid;
            } else {
                $errMsg['message'] = ErrorConstants::USERNAME_NOT_FOUND;
                $errCode = 400;
                return new JsonResponse($errMsg, $errCode);
            }
        } catch (\Exception $e) {
            $errMsg = $e->getResponse() ? json_decode($e->getResponse()->getBody()->read(2048), true) : ["message" => $e->getMessage()];
            $errCode = $e->getCode() ? $e->getCode() : Response::HTTP_BAD_GATEWAY;
            return new JsonResponse($errMsg, $errCode);
        }

        // Check if this is a self password reset attempt
        if ($uuid_from_loginId === $userId) {
            $errMessage = ErrorConstants::SELF_PASSWORD_RESET_NOT_ALLOWED;
            $this->logger->error($errMessage);
            $errMsg['message'] = $errMessage;
            $errCode = 400;
            return new JsonResponse($errMsg, $errCode);
        }

        $dasRequests = new GuzzleRequest('post', $dasUri . '/password', $headers, $request->getContent());

        try {
            $dasResponse = $dasClient->send($dasRequests);
            $resCode = $dasResponse->getStatusCode();
        } catch (BadRequestHttpException | \Exception $error) {
            $this->logger->error($error->getMessage());
            $errVar = json_decode($error->getResponse()->getBody()->read(2048), true);
            $errMsg['message'] = $errVar['Error'];
            $errCode = $error->getCode();
            return new JsonResponse($errMsg, $errCode);
        }

        if ($resCode < 300) {
            if ($objectData['sendEmail']) {
                $integrationClient = $this->getIntegrationClient();
                $dataToReplace = [];
                $mailDetails = [];
                $defaultMessage = 'adminresetpassword';
                $resource = Person::class;
                $id = $objectData['currentUUID'];
                $object = $this->itemDataProvider->getItem($resource, ["uuid" => $id]);
                $item = $this->serializer->normalize($object, 'jsonld', []);
                $title = "Password for " . $item['firstname'] . " " . $item['lastname'] . "[" . $objectData['loginId'] . "] Changed";
                $mailDetails['to'] = $item['email'];
                $updateObj = [];
                $updateObj['@type'] = $item['@type'];
                $updateObj['@id'] = $item['@id'];
                $dataToReplace['{{vars.userId}}'] = $objectData['loginId'];
                $body = $this->prepareChangeData($updateObj, (object)null, 'Event', [], $title);
                $body['entityType'] = $item['@type'];
                $body['entityUuid'] = $item['userId'];
                $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->setContentType('application/json');
                $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->publish(json_encode([$body]), MqMessagebroadcastSubscriber::DEFAULT_KEY);
                $this->utilityService->sendMail('2218f5b9-0b17-4f21-91c9-5404696d1908', $dataToReplace, $mailDetails, $integrationClient, $defaultMessage);
            }
            return new JsonResponse("Password Changed sucessfully");
        }
    }

    public function changePasswordAction(Request $request)
    {

        $dasUri = $this->containers->getParameter('das.uri');
        $dasClient = $this->getDasClient();
        $userId = $this->getCurrentUser()->getUserId();
        $userUuid = $this->getCurrentUser()->getUuid();
        $objectData = json_decode($request->getContent(), true);
        $objectData['user_id'] = $userId;
        $headersExceptForHost = $request->headers->all();
        unset($headersExceptForHost['host']);
        unset($headersExceptForHost['cookie']);
        if ($userUuid === $objectData['uuid']) {
            $dasRequests = new GuzzleRequest('put', $dasUri . '/password', $headersExceptForHost, $request->getContent());
            try {
                $dasResponse = $dasClient->send($dasRequests);
                $resCode = $dasResponse->getStatusCode();
            } catch (BadRequestHttpException | \Exception $error) {
                $this->logger->error($error->getMessage());
                $errVar = json_decode($error->getResponse()->getBody()->read(2048), true);
                $errMsg['message'] = $errVar['Error'];
                $errCode = $error->getCode();
                return new JsonResponse($errMsg, $errCode);
            }

            if ($resCode < 300) {
                $sealabClient = $this->getProxyClient();
                $dataToReplace = [];
                $mailDetails = [];
                $mailDetails['to'] = $this->getCurrentUser()->getEmail();
                $defaultMessage = 'changepassword';
                $dataToReplace['{{vars.userId}}'] = $userId;
                $mailResponse = $this->utilityService->sendMail('e71ba2df-e4ed-4823-9c28-b86423e9a7eb', $dataToReplace, $mailDetails, $sealabClient, $defaultMessage);
                if ($mailResponse === true) {
                    $sucessMsg['message'] = "Password Changed successfully";
                    return new JsonResponse($sucessMsg);
                } else {
                    $sucessMsg['message'] = "Password Changed successfully, mail not sent due to smtp connector failure";
                    return new JsonResponse($sucessMsg);
                }
            }
        } else {
            $this->logger->error("user Token mismatch");
            return new JsonResponse("user Token mismatch", 400);
        }
    }

    protected function extractUserName()
    {
        if (method_exists($this->getUser(), "getfirstname")) {
            if (method_exists($this->getUser(), "getlastname")) {
                $userName = $this->getUser()->getfirstname() . ' ' . $this->getUser()->getlastname();
            } else {
                $userName = $this->getUser()->getfirstname();
            }
        } else {
            $userName = $this->getUser()->getname();
        }
        return $userName;
    }

    protected function prepareChangeData(
        $updatedObject,
        $previousObject,
        $method,
        $changeData = [],
        $title = null
    ) {
        $delta_data = [];
        $delta_data['oldData'] = $previousObject;
        $delta_data['newData'] = $updatedObject;
        $delta_data['changeData'] = $changeData;
        $userName = $this->extractUserName();
        $userId = $this->getUser()->getUuid();
        return [
            AppConstants::DELTA_DATA => $delta_data,
            AppConstants::HTTP_METHOD => $method,
            AppConstants::REMOTE_ADDR => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'],
            AppConstants::WEB_SOCKET_SESSION_ID => isset($_SERVER['HTTP_WEBSOCKET_SESSIONID']) ? $_SERVER['HTTP_WEBSOCKET_SESSIONID'] : null,
            AppConstants::COMPONENT => 'crudhub',
            AppConstants::USER_UUID => $userId,
            AppConstants::TRANSACTION_DATE => round(microtime(true) * 1000),
            AppConstants::USER => $userName,
            AppConstants::TITLE => $title
        ];
    }
}
