<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Service\IriHelper;
use Psr\Log\LoggerInterface;
use App\Entity\Custom\Comment;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use App\Controller\BaseController;
use ApiPlatform\Core\Util\CloneTrait;
use App\Entity\Settings\SystemSettings;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Intl\Exception\MethodNotImplementedException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;

class CommentsController extends BaseController
{
    use CloneTrait;

    public const ENABLED = 'enabled';
    const FLG_IS_IMPORTANT = 'isImportant';

    public function __construct(
        ContainerInterface $containers,
        ResourceClassResolverInterface $resourceClassResolver,
        private FsrVoter $fsrVoter,
        private IriHelper $iriHelper,
        private EntityManagerInterface $entityManager,
        private HttpKernelInterface $kernel,
        TagAwareCacheInterface $cache,
        MetadataHelper $metadataHelper,
        private ParameterBagInterface $parameters,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function getRecordCommentAction(Request $request, String $module, String $recordId, String $id)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $module);
        $moduleIri = sprintf('%s%s/%s', BaseController::API_PREFIX, $module, $recordId);
        $this->iriHelper->findOrThrowNotFound($moduleIri);
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.comments');
        //TODO: this has to be read from request
        $GLOBALS["__associatedFieldRequest__"] = true;
        $commentsIri = sprintf('%scomments/%s', BaseController::API_PREFIX, $id);
        $commentRecord = $this->iriHelper->findOrThrowNotFound($commentsIri);
        $commentResource = Comment::class;
        $this->addCommentResourceToRequest($request, $commentResource, 'get');
        return $commentRecord;
    }

    public function updateAction(Request $request, $id)
    {
        $commentModificationAllowed = null;
        $commentResource = Comment::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.comments');
        $systemRepository = $this->entityManager->getRepository(SystemSettings::class);
        $systemSetting = $systemRepository->findAll();
        $commentSettings = $systemSetting[0]->getPublicValues()['commentModification'];
        if (!array_key_exists(self::ENABLED, $commentSettings) || !$commentSettings[self::ENABLED]) {
            throw new MethodNotImplementedException(ErrorConstants::COMMENT_MODIFICATION_BLOCKED);
        }
        $commentsIri = sprintf('%scomments/%s', BaseController::API_PREFIX, $id);
        $object = $this->iriHelper->findOrThrowNotFound($commentsIri);
        if ($object->getIsDeleted()) {
            throw new AccessDeniedException(ErrorConstants::MESSAGE_MODIFICATION_NOT_ALLOWED);
        }

        // Only the creatUser of comment can edit in the permitted time window, or the admin with security:update permissions
        $user = $this->getUser()->getUserId();
        if (
            ($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . BaseController::RESOURCE_SECURITY))
            ||
            ($object->getCreateUser()->getUserId() == $user && ($object->getModifyDate()->getTimestamp() > $_SERVER['REQUEST_TIME'] - (int) $commentSettings['timeWindow']))

        ) {
            $commentModificationAllowed = true;
        }

        if (!$commentModificationAllowed) {
            throw new AccessDeniedException(ErrorConstants::MESSAGE_MODIFICATION_NOT_ALLOWED);
        }

        $groups = ["fsr_all", "fsr_primary", "password"];
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => $groups]
        );

        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);
        $denormalizedObject = $this->serializer->deserialize(
            $request->getContent(),
            $commentResource,
            'jsonld',
            ['object_to_populate' => $object, 'fetch_data' => false]
        );
        $request->attributes->set('data', $denormalizedObject);

        // Read listener is not called because the resource api class is not set
        // Hence the previous_data attribute does not get set
        // Setting here manually
        $request->attributes->set('previous_data', $this->clone($object));
        $this->addCommentResourceToRequest($request, $commentResource, 'put');
        return $denormalizedObject;
    }

    public function deleteAction(Request $request, $id)
    {
        $systemRepository = $this->entityManager->getRepository(SystemSettings::class);
        $systemSetting = $systemRepository->findAll();
        $commentSettings = $systemSetting[0]->getPublicValues()['commentModification'];
        if (!array_key_exists(self::ENABLED, $commentSettings) || !$commentSettings[self::ENABLED]) {
            throw new BadRequestHttpException(ErrorConstants::COMMENT_DELETE_NOT_ALLOWED);
        }
        $commentResource = Comment::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.comments');

        $commentsIri = sprintf('%scomments/%s', BaseController::API_PREFIX, $id);
        $object = $this->iriHelper->findOrThrowNotFound($commentsIri);

        $user = $this->getUser()->getUserId();
        if (array_key_exists('softDelete', $commentSettings) && !$commentSettings['softDelete']) {
            $commentDeletionAllowed = false;
            if (
                ($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . BaseController::RESOURCE_SECURITY))
                ||
                ($object->getCreateUser()->getUserId() == $user && ($object->getModifyDate()->getTimestamp() > $_SERVER['REQUEST_TIME'] - (int) $commentSettings['timeWindow']))
            ) {
                $commentDeletionAllowed = true;
            }

            // Proceed with delete request.
            if (!$commentDeletionAllowed) {
                throw new AccessDeniedException(ErrorConstants::COMMENT_DELETE_NOT_ALLOWED);
            } else {
                $max_relation_count = 100;
                if ($this->parameters->has('max_relation_count')) {
                    $max_relation_count = $this->parameters->get('max_relation_count');
                }

                $normalizedPreviousData = $this->serializer->normalize(
                    $object,
                    'jsonld',
                    ["asJson" => true, "relationships" => true, "groups" => ["fsr_all"], "fsr_max_relation_count" => $max_relation_count]
                );
                $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
                $request->attributes->set('previous_data', $object);
                $this->addCommentResourceToRequest($request, $commentResource, 'delete');
                // this should handle record deletion
                return $object;
            }
        } else {
            $commentModificationAllowed = false;
            // create a PUT subrequest
            $subRequest = Request::create($commentsIri, 'PUT', [], [], [], [], '{"isDeleted":true, "recordTags": []}');
            $subRequest->headers->replace($request->headers->all());

            if (
                ($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . BaseController::RESOURCE_SECURITY))
                ||
                ($object->getCreateUser()->getUserId() == $user && ($object->getModifyDate()->getTimestamp() > $_SERVER['REQUEST_TIME'] - (int) $commentSettings['timeWindow']))

            ) {
                $commentModificationAllowed = true;
            }

            if (!$commentModificationAllowed) {
                throw new AccessDeniedException(ErrorConstants::MESSAGE_DELETE_NOT_ALLOWED);
            }
            try {
                return $this->kernel->handle($subRequest, HttpKernelInterface::SUB_REQUEST);
            } catch (BadRequestHttpException | \Exception $e) {
                return new Response('Failed to delete the comment record', 400);
            }
        }
    }

    public function updateIsImportantFlag(Request $request, $id)
    {
        $commentResource = Comment::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.comments');

        $commentsIri = sprintf('%scomments/%s', BaseController::API_PREFIX, $id);
        $object = $this->iriHelper->findOrThrowNotFound($commentsIri);
        if ($object->getIsDeleted()) {
            throw new AccessDeniedException(ErrorConstants::MESSAGE_MODIFICATION_NOT_ALLOWED);
        }

        $objectData = json_decode($request->getContent(), true);

        if(!key_exists( self::FLG_IS_IMPORTANT , $objectData) || count($objectData) != 1) {
            throw new BadRequestHttpException('Invalid request body.');
        }

        $groups = ["fsr_all", "fsr_primary", "password"];
        $normalizedPreviousData = $this->serializer->normalize($object,
            'jsonld', ["asJson" => true, "relationships" => true, "groups" => $groups]
        );

        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);

        $denormalizedObject = $this->serializer->deserialize(
            $request->getContent(), $commentResource,
            'jsonld', ['object_to_populate' => $object, 'fetch_data' => false]
        );

        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('previous_data', $this->clone($object));
        $this->addCommentResourceToRequest($request, $commentResource, 'put');
        return $denormalizedObject;
    }

    private function addCommentResourceToRequest($request, $commentResource, $method = 'post')
    {
        $request->attributes->set('_api_collection_operation_name', $method);
        $request->attributes->set('_api_item_operation_name', $method);
        $request->attributes->set('_api_resource_class', $commentResource);
        $request->attributes->set('_format', 'jsonld');
        $request->overrideGlobals();
    }
}
