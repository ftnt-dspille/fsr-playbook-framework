<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Entity\Query\Query;
use App\Entity\Query\UserQuery;
use App\Service\UtilityService;
use App\Providers\QueryProvider;
use App\Query\ExpressionBuilder;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use Doctrine\ORM\EntityManagerInterface;
use ApiPlatform\Api\IriConverterInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use ApiPlatform\Core\DataProvider\CollectionDataProviderInterface;
use ApiPlatform\Core\Serializer\SerializerContextBuilderInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class QueryResourceController extends AbstractController
{

    const ASSIGNEE_KEY = 'assignee';

    protected $fsrVoter;
    private $queryProvider;
    private $serializerContextBuilder;
    private $collectionDataProvider;
    private $iriConverter;

    public function __construct(
        FsrVoter $fsrVoter,
        QueryProvider $queryProvider,
        CollectionDataProviderInterface $collectionDataProvider,
        IriConverterInterface $iriConverter,
        SerializerContextBuilderInterface $serializerContextBuilder,
        protected EntityManagerInterface $entityManager,
        protected UtilityService $utilityService,
        protected SerializerInterface $serializer
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->queryProvider = $queryProvider;
        $this->collectionDataProvider = $collectionDataProvider;
        $this->iriConverter = $iriConverter;
        $this->serializerContextBuilder = $serializerContextBuilder;
        $this->serializer = $serializer;
    }

    /**
     * @param Request $request
     * @return \Dunglas\ApiBundle\JsonLd\Response
     */
    public function getAction(Request $request)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.application');
        $queryLimit = $request->get('$limit', 30);
        $queryPage = $request->get('$page', 1);
        $currentUserIri = $this->iriConverter->getIriFromResource($this->getUser());
        $accessibleQueryFilter = ExpressionBuilder::logicOr(
            ExpressionBuilder::field(self::ASSIGNEE_KEY)->equals(''),
            ExpressionBuilder::field(self::ASSIGNEE_KEY)->isNull(true),
            ExpressionBuilder::field(self::ASSIGNEE_KEY)->equals($currentUserIri)
        );
        $this->queryProvider->setAdditionalFilters($accessibleQueryFilter->toArray());
        $request->overrideGlobals();

        $attributes['filters'] = ['$limit' => $queryLimit, '$page' => $queryPage];
        $attributes['resource_class'] = Query::class;
        $attributes['collection_operation_name'] = "get";
        $context = $this->serializerContextBuilder->createFromRequest($request, true, $attributes);
        $entities = $this->collectionDataProvider->getCollection(Query::class, $request, $attributes);
        $data = $this->serializer->normalize($entities, 'jsonld', $context);
        return new JsonResponse($data);
    }

    public function postAction(Request $request)
    {
        $resource = UserQuery::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.application');
        $decodedRequestData = json_decode($request->getContent(), true);
        $currentUserIri = $this->iriConverter->getIriFromResource($this->getUser());
        $decodedRequestData[self::ASSIGNEE_KEY] = $currentUserIri;
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($decodedRequestData),
            $resource,
            'jsonld',
            ['fetch_data' => false, 'ignore_authorization' => true, 'ignore_field_authorization' => true]
        );
        $request->attributes->set('_api_collection_operation_name', 'post');
        $request->attributes->set('_api_item_operation_name', 'post');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->overrideGlobals();

        return $denormalizedObject;
    }

    public function putAction(Request $request, $uuid)
    {
        $resource = UserQuery::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.application');
        $decodedRequestData = json_decode($request->getContent(), true);
        $currentUserIri = $this->iriConverter->getIriFromResource($this->getUser());
        if ($decodedRequestData[self::ASSIGNEE_KEY] != $currentUserIri) {
            throw new AccessDeniedException();
        }
        $userQueryRepo = $this->entityManager->getRepository($resource);
        $existingObj = $this->utilityService->getItemWithWhere($userQueryRepo, ['uuid' => $uuid]);
        if (!$existingObj) {
            throw new NotFoundHttpException('No record found with given IRI');
        }
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($decodedRequestData),
            $resource,
            'jsonld',
            ['object_to_populate' => $existingObj[0], 'fetch_data' => false, 'ignore_authorization' => true, 'ignore_field_authorization' => true]
        );
        $request->attributes->set('_api_collection_operation_name', 'put');
        $request->attributes->set('_api_item_operation_name', 'put');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->overrideGlobals();

        return $denormalizedObject;
    }

    public function deleteAction(Request $request, $uuid)
    {
        $resource = UserQuery::class;
        $method = 'delete';
        $userQueryRepo = $this->entityManager->getRepository($resource);
        $existingObj = $userQueryRepo->findOneBy(["uuid" => $uuid]);
        if (!$existingObj) {
            throw new NotFoundHttpException(ErrorConstants::RECORD_NOT_EXISTS);
        }
        $currentUserIri = $this->iriConverter->getIriFromResource($this->getUser());
        if ($existingObj->getAssignee() != $currentUserIri && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.application')) {
            throw new AccessDeniedException();
        } else {
            $normalizedPreviousData = $this->serializer->normalize(
                $existingObj,
                'jsonld',
                ["asJson" => true, "relationships" => true, "groups" => ["fsr_all"]]
            );
            $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
            $request->attributes->set('previous_data', $existingObj);
            $request->attributes->set('_api_collection_operation_name', $method);
            $request->attributes->set('_api_item_operation_name', $method);
            $request->attributes->set('_api_resource_class', $resource);
            $request->attributes->set('_format', 'jsonld');
            $request->overrideGlobals();
            return $existingObj;
        }
    }
}
