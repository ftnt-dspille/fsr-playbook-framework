<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class YumRepoController extends AbstractController
{
    public function yumRepoAction(Request $request)
    {
        $yumRepoDetails = [];
        $yumRepoDetails['yumRepo'] = getenv("REPOSERVER");
        $yumRepoDetails['yumRepoUrl'] =  sprintf('https://%s/', getenv("REPOSERVER"));
        return new JsonResponse($yumRepoDetails);
    }
}
