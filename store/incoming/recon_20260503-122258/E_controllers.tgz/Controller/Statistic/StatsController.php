<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller\Statistic;

use App\Utility\StatsUtility;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\ActionSuggestion\Statistic;
use Symfony\Component\HttpFoundation\Request;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class StatsController extends AbstractController
{

    public function __construct(
        protected EntityManagerInterface $entityManager,
        protected FsrVoter $fsrVoter,
        protected SerializerInterface $serializer,
        protected UtilityService $utilityService,
        protected StatsUtility $statsUtility
    ) {
    }

    public function getRecommendedActions(Request $request)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.application');
        $requestData = json_decode($request->getContent(), true);
        $resource = $requestData['resource'] ?? null;
        $recordUuid = $requestData['recordUuid'] ?? null;
        $similarRecordsObj = $requestData['similarRecordsUuid'] ?? [];
        if (is_null($resource) || is_null($recordUuid)) {
            throw $this->createNotFoundException('Either resource or record uuid is not available');
        }
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $resource);
        $statsRepo = $this->entityManager->getRepository(Statistic::class);
        $orderBy = [
            ['field' => 'o.createDate', 'direction' => 'ASC']
        ];
        if (!empty($similarRecordsObj)) {
            $similarUuidList = array_map(function ($item) {
                return $item['uuid'];
            }, $similarRecordsObj);

            $statsFilter = ['recordUuid' => $similarUuidList, 'statsType' => $this->statsUtility::STATS_TYPE['Workflow']];
            $statisticResults = $this->utilityService->getItemWithWhere($statsRepo, $statsFilter, $orderBy);
            $statsMap = [];
            $actionUuidToNameMap = [];
            foreach ($statisticResults as $statisticResult) {
                $statsMap[$statisticResult->getRecordUuid()][] = $statisticResult->getActionUuid();
                $actionUuidToNameMap[$statisticResult->getActionUuid()] = $statisticResult->getAction();
            }
            [$sequence, $weightedGraph] = $this->statsUtility->computeActionSequence($statsMap, $similarRecordsObj);
            $preExecutedWorkflow = $this->statsUtility->getCurrentExecuteWorkflow($recordUuid);
            return new JsonResponse(["sequence" => $sequence, 'executedPlaybooks' => $preExecutedWorkflow, 'weightedGraph' => $weightedGraph]);
        }
        $successMsg['message'] = "No Suitable suggestion found";
        return new JsonResponse($successMsg);
    }
}
