<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Constants\AppConstants;
use App\Security\Voter\FsrVoter;
use App\Service\SamlActorService;
use Doctrine\ORM\EntityManagerInterface;
use ApiPlatform\Api\IriConverterInterface;
use App\Service\AccessibleTeamIdsProvider;
use GuzzleHttp\Psr7\Request as GuzzleRequest;
use Symfony\Component\HttpFoundation\Request;
use GuzzleHttp\Exception\BadResponseException;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class GatewayActionController extends AbstractController
{
    public function __construct(
        protected SamlActorService $samlActorService,
        protected TokenStorageInterface $tokenStorage,
        protected FsrVoter $fsrVoter,
        protected IriConverterInterface $iriConverter,
        protected AccessibleTeamIdsProvider $accessibleTeamIdsProvider,
        protected EntityManagerInterface $entityManager,
        protected ContainerInterface $containers
    ) {
    }

    public const USER_UUID = 'userId';
    public const USER = 'user';
    public const REMOTE_ADDR = 'source';

    public function sendRequest($client, $gatewayRequest)
    {
        try {
            $response = $client->send($gatewayRequest);
            $statusCode = $response->getStatusCode();
            if ($statusCode >= 400) {
                $errMsg = "Failed to get response from audit log";
                return new JsonResponse($errMsg, $statusCode);
            } else {
                $jsonDecodeResponse = json_decode($response->getBody()->getContents(), true);
                return new JsonResponse($jsonDecodeResponse, $statusCode);
            }
        } catch (BadResponseException $exception) {
            // Get the exception as string on json
            $response = $exception->getResponse();
            // Convert the string of json to the json
            $respBody = json_decode($response->getBody()->getContents(), true);
            $error = $respBody['message'] ?? $respBody['Error'];
            return new JsonResponse($error, 400);
        }
    }

    public function gatewayRouteAction(Request $request)
    {
        $requestPath = $request->getPathInfo();

        $objectData = json_decode($request->getContent(), true);
        $objectData['isAdmin'] = false;
        $this->checkAuthorization($request->getMethod(), $objectData);
        if ($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'security')) {
            $objectData['isAdmin'] = true;
        }
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . substr($requestPath,strlen("/api/gateway"));

        $objectData['teams'] = $this->getAccessibleTeamIris();
        $objectData['current_user'] = $this->iriConverter->getIriFromResource($this->getUser());
        $headers = array(
            "Content-type" => "application/json",
        );
        $gatewayRequest = new GuzzleRequest('post', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function checkAuthorization($method, $objectData = [], $skipMethodCheck=false)
    {
        if (isset($objectData['userId']) && $objectData['userId'] == $this->getUser()->getUuid()) {
            if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'activities')) {
                throw new AccessDeniedException();
            }
            return;
        }
        if($skipMethodCheck && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'security')){
            throw new AccessDeniedException();
        }
        elseif ($method === 'POST' && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'security')) {
            throw new AccessDeniedException();
        }
    }

    /**
     * @return array
     */
    protected function getAccessibleTeamIris()
    {
        $teamBaseIri = AppConstants::TEAM_IRI;
        $accessibleTeamIds = $this->accessibleTeamIdsProvider->getDataForCurrentUser();
        $accessibleTeamIris = array_map(fn($teamId) => sprintf('%s/%s', $teamBaseIri, $teamId), $accessibleTeamIds);
        return json_decode(json_encode($accessibleTeamIris), true);
    }

    public function gatewayRouteIdAction(Request $request, $auditId)
    {
        $this->checkAuthorization($request->getMethod(), [], true);
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/audit/activities/';
        if (isset($auditId) && $auditId != null) {
            $gatewayUri = $gatewayUri . $auditId;
        } else {
            $errMsg['message'] = "Invalid ID";
            return new JsonResponse($errMsg, 404);
        }
        $headers = ["Content-type" => "application/json"];
        $gatewayRequest = new GuzzleRequest('get', $gatewayUri, $headers, $request->getContent());
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewayDeleteRouteAction(Request $request)
    {
        $this->checkAuthorization($request->getMethod());
        $this->checkAuditDeleteAuthorization($request->getMethod());
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/audit/activities?';
        $query = $request->query->all();
        foreach ($query as $key => $value) {
            $gatewayUri = $gatewayUri . $key . '=' . $value . '&';
        }
        $gatewayUri = substr($gatewayUri, 0, -1);
        $headers = ["Content-type" => "application/json"];
        $gatewayRequest = new GuzzleRequest('delete', $gatewayUri, $headers);
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function checkAuditDeleteAuthorization($method)
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . 'activities')) {
            throw new AccessDeniedException();
        }
    }

    public function gatewayDeleteActivitiesRouteAction(Request $request)
    {
        $this->checkAuthorization($request->getMethod());
        $this->checkAuditDeleteAuthorization($request->getMethod());
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/audit/activities/delete';
        $headers = ["Content-type" => "application/json"];
        $objectData = json_decode($request->getContent(), true);
        $objectData[self::USER_UUID] = $this->getUser()->getUuid();
        $objectData[self::USER] = $this->extractUserName();
        $objectData[self::REMOTE_ADDR] = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $gatewayRequest = new GuzzleRequest('post', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewayGetRouteAction(Request $request)
    {

        $this->checkAuthorization($request->getMethod());
        $this->checkAuditDeleteAuthorization($request->getMethod());
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/audit/activities/ttl';
        $headers = ["Content-type" => "application/json"];
        $gatewayRequest = new GuzzleRequest('get', $gatewayUri, $headers);
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewayGetAuditOperations(Request $request)
    {

        $this->fsrVoter->denyUnlessAccessGranted('read.activities');
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/audit/operations?' . $request->getQueryString();
        $headers = ["Content-type" => "application/json"];
        $gatewayRequest = new GuzzleRequest('get', $gatewayUri, $headers);
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewayPostRouteAction(Request $request)
    {
        $this->checkAuthorization($request->getMethod());
        $objectData = json_decode($request->getContent(), true);
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/audit/activities/ttl';
        $headers = ["Content-type" => "application/json"];
        $objectData[self::USER_UUID] = $this->getUser()->getUuid();
        $objectData[self::USER] = $this->extractUserName();
        $objectData[self::REMOTE_ADDR] = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $gatewayRequest = new GuzzleRequest('post', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewayttlDeleteRouteAction(Request $request)
    {
        $this->checkAuthorization($request->getMethod());
        $this->checkAuditDeleteAuthorization($request->getMethod());
        $objectData = json_decode($request->getContent(), true);
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/audit/activities/ttl';
        $headers = ["Content-type" => "application/json"];
        $objectData[self::USER_UUID] = $this->getUser()->getUuid();
        $objectData[self::USER] = $this->extractUserName();
        $objectData[self::REMOTE_ADDR] = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $gatewayRequest = new GuzzleRequest('delete', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }
    /**
     * @return string
     */
    private function extractUserName()
    {
        if (method_exists($this->getUser(), "getfirstname")) {
            if (method_exists($this->getUser(), "getlastname")) {
                $userName = $this->getUser()->getfirstname() . ' ' . $this->getUser()->getlastname();
            } else {
                $userName = $this->getUser()->getfirstname();
            }
        } else {
            $userName = $this->getUser()->getname();
        }
        return $userName;
    }

    public function gatewaySyslogGetAction(Request $request)
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'security')) {
            throw new AccessDeniedException();
        }
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/config/syslog';
        $headers = ["Content-type" => "application/json"];
        $gatewayRequest = new GuzzleRequest('get', $gatewayUri, $headers);
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewaySyslogPostAction(Request $request)
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . 'security')) {
            throw new AccessDeniedException();
        }

        $objectData = json_decode($request->getContent(), true);
        $objectData[self::USER_UUID] = $this->getUser()->getUuid();
        $objectData[self::USER] = $this->extractUserName();
        $objectData[self::REMOTE_ADDR] = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/config/syslog';
        $originalHeader = $request->headers->all();
        $headers = ["Content-type" => "application/json", "is-cluster-call" => $originalHeader["is-cluster-call"]];
        $gatewayRequest = new GuzzleRequest('post', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewaySyslogPutAction(Request $request)
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . 'security')) {
            throw new AccessDeniedException();
        }
        $objectData = json_decode($request->getContent(), true);
        $objectData[self::USER_UUID] = $this->getUser()->getUuid();
        $objectData[self::USER] = $this->extractUserName();
        $objectData[self::REMOTE_ADDR] = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/config/syslog';
        $originalHeader = $request->headers->all();
        $headers = ["Content-type" => "application/json", "is-cluster-call" => $originalHeader["is-cluster-call"]];
        $gatewayRequest = new GuzzleRequest('put', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewaySyslogDeleteAction(Request $request, $uuid)
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . 'security')) {
            throw new AccessDeniedException();
        }

        $objectData = json_decode($request->getContent(), true);
        $objectData[self::USER_UUID] = $this->getUser()->getUuid();
        $objectData[self::USER] = $this->extractUserName();
        $objectData[self::REMOTE_ADDR] = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . '/config/syslog/';
        if (isset($uuid) && $uuid != null) {
            $gatewayUri = $gatewayUri . $uuid;
        } else {
            $errMsg['message'] = "Invalid UUId";
            return new JsonResponse($errMsg, 404);
        }
        $originalHeader = $request->headers->all();
        $headers = ["Content-type" => "application/json", "is-cluster-call" => $originalHeader["is-cluster-call"]];
        $gatewayRequest = new GuzzleRequest('delete', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }

    public function gatewaySyslogReconcileAction(Request $request)
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . 'security')) {
            throw new AccessDeniedException();
        }

        $objectData = json_decode($request->getContent(), true);
        $objectData[self::USER_UUID] = $this->getUser()->getUuid();
        $objectData[self::USER] = $this->extractUserName();
        $objectData[self::REMOTE_ADDR] = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $gatewayUri = $this->getParameter('gateway.uri');
        $gatewayUri = $gatewayUri . 'config/syslog/reconcile';
        $originalHeader = $request->headers->all();
        $headers = ["Content-type" => "application/json", "is-cluster-call" => $originalHeader["is-cluster-call"]];
        $gatewayRequest = new GuzzleRequest('post', $gatewayUri, $headers, json_encode($objectData));
        $gatewayClient = $this->containers->get("app.proxy.client.saml");
        return $this->sendRequest($gatewayClient, $gatewayRequest);
    }
}
