<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Psr\Log\LoggerInterface;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use App\Service\BulkRequestService;
use Doctrine\ORM\EntityManagerInterface;
use ApiPlatform\Api\IriConverterInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Providers\PermissionsDictionaryBuilder;
use ApiPlatform\Core\Exception\ExceptionInterface;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class BulkCreateController extends BaseController
{
    /** @var  FsrVoter */
    private $fsrVoter;

    /** @var  EntityManagerInterface */
    protected $entityManager;

    protected $bulkRequestService;

    const OPTION_KEY = 'options';
    const CLONE_KEY = 'cloneField';
    const RELATIONSHIP_KEY = 'relationships';

    public function __construct(
        FsrVoter $fsrVoter,
        ResourceClassResolverInterface $resourceClassResolver,
        ContainerInterface $containers,
        private IriConverterInterface $iriConverter,
        EntityManagerInterface $entityManager,
        SerializerInterface $serializer,
        BulkRequestService $bulkRequestService,
        protected MetadataHelper $metadataHelper,
        TagAwareCacheInterface $cache,
        protected LoggerInterface $logger
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->entityManager = $entityManager;
        $this->bulkRequestService = $bulkRequestService;
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function bulkCreate(Request $request, $moduleType)
    {
        $resourceClass = $this->getResourceFromClassName($moduleType);
        $failedObj =[];
        $module = $this->metadataHelper->getModuleFromClassName($resourceClass);
        if (!($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . $module))) {
            throw new AccessDeniedException();
        }

        // TODO: validate if payload is an array or single object
        $objectData = json_decode($request->getContent());
        $headers = $request->headers->all();
        $queryParams = $request->query->all();
        if ((is_array($objectData) && array_key_exists(self::SELECTIVE_FIELDS, $objectData)) || isset($objectData->{self::SELECTIVE_FIELDS}) ) {
            $selectedFields = $objectData->{self::SELECTIVE_FIELDS};
            $queryParams[self::SELECTIVE_FIELDS] = implode(',', $selectedFields);
        }
        if ((is_array($objectData) && array_key_exists("cloneIds", $objectData)) || isset($objectData->{'cloneIds'})) {
            $objectDataJson = json_decode($request->getContent(), true);
            $processedResponse = $this->prepareClonePayload($objectDataJson, $moduleType, $resourceClass);
            $objectsToClone = $processedResponse[0];
            $failedCloneObjects = $processedResponse[1];
            if (sizeof($failedCloneObjects) > 0) {
                array_push($failedObj, $failedCloneObjects);
            }
            $objectData->{'data'} = $objectsToClone;
        }
        return $this->bulkRequestService->prepareRecordSubRequest($resourceClass, $objectData, '/api/3/' . $moduleType, $headers, $queryParams);
    }

    private function prepareClonePayload(array $objectDataJson, string $moduleType, string $resourceClass): array
    {
        $data = [];
        $failedObj = [];
        $cloneFieldNames = [];
        if (
            array_key_exists(self::OPTION_KEY, $objectDataJson) &&
            array_key_exists(self::CLONE_KEY, $objectDataJson[self::OPTION_KEY]) &&
            ($objectDataJson[self::OPTION_KEY][self::CLONE_KEY] !== null)
        ) {
            $cloneFieldNames[] = $objectDataJson[self::OPTION_KEY][self::CLONE_KEY];
        }
        foreach ($objectDataJson['cloneIds'] as $cId) {
            if (isset($cId)) {
                $explodeId = explode('/', $cId);
                $id = end($explodeId);
                // check if resourceClass matches the one in iri
                $resourceInIRI = prev($explodeId);
                if ($resourceInIRI != $moduleType) {
                    throw new BadRequestHttpException(ErrorConstants::RESOURCE_DOES_NOT_MATCH);
                }
                $object = null;
                try {
                    $resourceContext = ['resource_class' => $resourceClass];
                    $object = $this->iriConverter->getResourceFromIri($cId, $resourceContext + ['fetch_data' => true]);
                    if (!$object) {
                        array_push($failedObj, $id);
                    } else {
                        if (array_key_exists(self::OPTION_KEY, $objectDataJson) && array_key_exists(self::RELATIONSHIP_KEY, $objectDataJson[self::OPTION_KEY]) && $objectDataJson[self::OPTION_KEY][self::RELATIONSHIP_KEY]) {
                            $resourceContext["relationships"] = true;
                        }
                        $normalized_data = $this->serializer->normalize($object, self::NORMALIZER_METHOD, $resourceContext);

                        $repository = $this->entityManager->getRepository($resourceClass);

                        $entityFieldMap = $this->metadataHelper->getEntityFields($resourceClass) ?? null;
                        foreach($entityFieldMap['displayName'] as $displayName) {
                            if (!in_array($displayName, $cloneFieldNames)) {
                                $cloneFieldNames[] = $displayName;
                            }
                        }

                        foreach ($cloneFieldNames as $cloneFieldName) {
                            if ($cloneFieldName && array_key_exists($cloneFieldName, $normalized_data) && $normalized_data[$cloneFieldName] && is_string($normalized_data[$cloneFieldName])) {
                                $newValue = $normalized_data[$cloneFieldName] . ' (1)';
                                $number = 1;
                                while ($repository->findOneBy([$cloneFieldName => $newValue]) != null) {
                                    $newValue = $normalized_data[$cloneFieldName] . ' (' . ++$number . ')';
                                }
                                if (array_key_exists($cloneFieldName, $normalized_data) && $normalized_data[$cloneFieldName]) {
                                    $normalized_data[$cloneFieldName] = $newValue;
                                }
                            }
                        }

                        unset($normalized_data['id']);
                        unset($normalized_data['uuid']);
                        if (isset($normalized_data['tenantRecordId'])) {
                            unset($normalized_data['tenantRecordId']);
                        }
                        unset($normalized_data['@id']);
                    }
                    $data[] = $normalized_data;
                } catch (Exception | ExceptionInterface $exception) {
                    if ($exception instanceof ExceptionInterface) {
                        $err = $exception->__toString();
                    } else {
                        $err = [$exception->getMessage()];
                    }
                    array_push($failedObj, $err);
                    continue;
                }
            } else {
                array_push($failedObj, $cId);
            }
        }
        return array($data, $failedObj);
    }
}
