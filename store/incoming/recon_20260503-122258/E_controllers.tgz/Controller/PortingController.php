<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Entity\Core\ExportJob;
use App\Entity\Core\ExportTemplate;
use App\Entity\Core\ImportJob;
use App\Providers\PermissionsDictionaryBuilder;
use App\Security\Voter\FsrVoter;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Ramsey\Uuid\Uuid;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use App\Constants\AppConstants;

class PortingController extends AbstractController
{
    /** @var FsrVoter */
    private $fsrVoter;

    /** @var TokenStorageInterface */
    private $tokenStorage;

    /** @var EntityManagerInterface */
    private $entityManager;

    public function __construct(FsrVoter $fsrVoter, TokenStorageInterface $tokenStorage, EntityManagerInterface $entityManager)
    {
        $this->fsrVoter = $fsrVoter;
        $this->tokenStorage = $tokenStorage;
        $this->entityManager = $entityManager;
    }
    /**
     * @param Request $request
     * @return JsonResponse
     * @throws DeserializationException
     */
    public function exportStartAction(Request $request)
    {
        if (
            !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . PermissionsDictionaryBuilder::MODULE_APPLICATION) ||
            !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . PermissionsDictionaryBuilder::MODULE_SECURITY) ||
            !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . PermissionsDictionaryBuilder::MODULE_SECURITY) ||
            !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.files')
        ) {
            throw new AccessDeniedException();
        }

        $token = $this->tokenStorage->getToken();
        $repository = $this->entityManager->getRepository(ExportTemplate::class);
        $uuid = $request->get('template');
        $solutionPack = null;
        $fileName = $this->cleanFileName($request->get('fileName'));
        if (!Uuid::isValid($uuid)) {
            throw new \Exception(sprintf('Invalid uuid: %s', $uuid));
        }
        /** @var ExportTemplate $ExportTemplate */
        $exportTemplate = $repository->find($uuid);
        $rootDir = $this->getParameter('kernel.project_dir');
        $cmd = '';
        if ($exportTemplate) {
            $solutionPack = $exportTemplate->getSolutionPack();
            if (!is_null($solutionPack)) {
                $dependenciesArray = $solutionPack->getDependencies();
                if (is_array($dependenciesArray)) {
                    foreach ($dependenciesArray as $dependencyItemKey => $dependencyItemValue) {
                        if (is_array($dependencyItemValue) && array_key_exists('version', $dependencyItemValue)) {
                            unset($dependencyItemValue['version']);
                        }
                        $dependenciesArray[$dependencyItemKey] = $dependencyItemValue;
                    }
                    $solutionPack->setDependencies($dependenciesArray);
                }
                $exportTemplate->setSolutionPack($solutionPack);
            }
            $exportJob = new ExportJob();
            $exportJob->setTemplate($exportTemplate);
            $exportJob->setFileName($fileName);
            $jobUuid = Uuid::uuid4()->toString();
            $exportJob->setUuid($jobUuid);
            $this->entityManager->persist($exportJob);
            $this->entityManager->flush();
            if ($solutionPack) {
                $solutionPack->setExportJob($exportJob);
                $this->entityManager->persist($solutionPack);
                $this->entityManager->flush();
            }

            $tokenPart = '';
            $tokenType = 'HMAC';
            if (method_exists($this->getUser(), "getfirstname")) {
                $tokenType = 'JWT';
            }
            if ($token->getCredentials()) {
                $tokenPart = sprintf('--user-token=%s --token-type=%s', $token->getCredentials(), $tokenType);
            }
            $cmd = sprintf('/usr/bin/php %s/bin/console fortisoar:jobs:export --job-uuid=%s %s', $rootDir, $jobUuid, $tokenPart);
        } else {
            $msg = "Export template does not exist - Uuid = " . $uuid;
            throw new HttpException(Response::HTTP_NOT_FOUND, $msg);
        }
        chdir($rootDir . '/../');
        exec(sprintf('bash -c "exec nohup setsid %s > /var/log/cyops/cyops-api/last_config_export.log 2>&1 &"', $cmd));

        return new JsonResponse([
            '@type' => 'ExportJob',
            'jobUuid' => $jobUuid
        ]);
    }

    /**
     * @param Request $request
     * @param string $id
     * @return JsonResponse
     * @throws DeserializationException
     */
    public function importStartAction(Request $request, $id)
    {
        return $this->runCommand($id, false, [
            "result" => "Started import",
            "progress" => 0
        ]);
    }

    /**
     * @param string $id
     * @return JsonResponse
     * @throws DeserializationException
     */
    private function runCommand($id, $dryRun, $successResponse)
    {
        if (
            !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . PermissionsDictionaryBuilder::MODULE_APPLICATION) ||
            !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . PermissionsDictionaryBuilder::MODULE_SECURITY)
        ) {
            throw new AccessDeniedException();
        }
        if (!Uuid::isValid($id)) {
            throw new \Exception(sprintf('Invalid uuid: %s', $id));
        }
        $token = $this->tokenStorage->getToken();
        $repository = $this->entityManager->getRepository(ImportJob::class);
        /** @var ImportJob $importJob */
        $importJob = $repository->find($id);
        $tokenType = 'HMAC';
        if (method_exists($this->getUser(), "getfirstname")) {
            $tokenType = 'JWT';
        }
        $cmd = '';

        if ($importJob) {
            $tokenPart = '';
            if ($token->getCredentials()) {
                $tokenPart = sprintf('--user-token=%s --token-type=%s', $token->getCredentials(), $tokenType);
            }
            $cmd = sprintf('/usr/bin/php /opt/cyops-api/bin/console fortisoar:jobs:import --job-uuid=%s %s %s', $id, ($dryRun ? '-o' : ''), $tokenPart);
        } else {
            $msg = "Import job does not exist - Uuid = " . $id;
            throw new HttpException(Response::HTTP_NOT_FOUND, $msg);
        }
        chdir($this->getParameter('kernel.project_dir') . '/../');
        exec(sprintf('bash -c "exec nohup setsid %s > /var/log/cyops/cyops-api/last_config_import.log 2>&1 &"', $cmd));

        return new JsonResponse([
            '@type' => 'ImportJob',
            'status' => $successResponse
        ]);
    }

    /**
     * @param Request $request
     * @param string $id
     * @return JsonResponse
     * @throws DeserializationException
     */
    public function importParamsAction(Request $request, $id)
    {
        return $this->runCommand($id, true, [
            "result" => "Import job options populated"
        ]);
    }

    protected function cleanFileName(string $name)
    {
        return preg_replace(AppConstants::FILE_NAME_CLEANUP_REGEX, '_', $name);
    }
}
