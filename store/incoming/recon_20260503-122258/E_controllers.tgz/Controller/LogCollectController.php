<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Providers\PermissionsDictionaryBuilder;
use App\Security\Voter\FsrVoter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;

class LogCollectController extends AbstractController
{
    public const LOG_COLLECT_WORKSPACE_PATH = "/opt/cyops-api/workspace/logs/";

    public function __construct(private FsrVoter $fsrVoter)
    {
    }

    public function downloadFile(Request $request)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.security');
        $filename = $request->query->get('filename');
        // filename should not be empty, should be starting with fortisoar loags and should not be a directory to allow traversal
        if (empty($filename) || !str_starts_with($filename, "fortisoar-logs") || str_contains($filename, '/') || str_contains($filename, '\\')) {
            return new JsonResponse([], Response::HTTP_BAD_REQUEST);
        }
        if (!file_exists(self::LOG_COLLECT_WORKSPACE_PATH . $filename)) {
            return new JsonResponse([], Response::HTTP_NOT_FOUND);
        } else {
            $response = new Response();
            $response->headers->set('Content-Type', 'application/octet-stream');
            $response->headers->set('Content-Disposition', 'attachment; filename=' . $filename);
            $response->headers->set('X-Accel-Redirect', '/log-collect/' . $filename);
            return $response;
        }
    }
}
