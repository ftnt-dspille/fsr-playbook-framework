<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Providers\QueryProvider;
use App\Security\Voter\FsrVoter;
use App\Service\GenericTemplateService;
use App\Entity\ViewTemplate\GenericTemplate;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\ViewTemplate\UserDefaultTemplate;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use ApiPlatform\Core\DataProvider\ItemDataProviderInterface;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class GenericTemplateController extends AbstractController
{

    protected $genericTemplateService;

    protected $fsrVoter;

    protected $chainItemDataProvider;

    protected $queryProvider;

    public function __construct(
        GenericTemplateService $genericTemplateService,
        FsrVoter $fsrVoter,
        ItemDataProviderInterface $chainItemDataProvider,
        QueryProvider $queryProvider,
        protected SerializerInterface $serializer,
        protected EntityManagerInterface $entityManager
    ) {
        $this->genericTemplateService = $genericTemplateService;
        $this->fsrVoter = $fsrVoter;
        $this->chainItemDataProvider = $chainItemDataProvider;
        $this->queryProvider = $queryProvider;
        $this->serializer = $serializer;
        $this->entityManager = $entityManager;
    }

    protected $allowedType = ['dashboard', 'reporting'];
    const RELATIONSHIP_KEY = "\$relationships";
    const ENABLED = 'enabled';

    /**
     * @param $type String
     */
    private function isAllowedType($type)
    {
        if (!in_array($type, $this->allowedType)) {
            throw new BadRequestHttpException("Invalid Type.");
        }
    }

    public function createDefaultUserTemplateAction(Request $request, $type, $id)
    {
        $this->isAllowedType($type);
        $genericTemplateProvider = $this->genericTemplateService;
        $resource = GenericTemplate::class;
        $genericTemplate = $this->chainItemDataProvider->getItem($resource, ["uuid" => $id]);
        if (!$genericTemplate) {
            throw new NotFoundHttpException("Template with given id does not exists");
        }
        $savedTemplate = $genericTemplateProvider->saveDefaultUserTemplate($type, $id, $genericTemplate);
        if ($savedTemplate) {
            return new JsonResponse('Success');
        } else {
            return new Response(null, Response::HTTP_FORBIDDEN);
        }
    }

    public function getDefaultUserTemplateAction(Request $request, $type)
    {
        $this->isAllowedType($type);
        $genericTemplateProvider = $this->genericTemplateService;
        $user = $genericTemplateProvider->getCurrentUser()->getUuid();
        $entityRepo = $this->entityManager->getRepository(UserDefaultTemplate::class);
        $defaultTemplate = $entityRepo->findBy(["userId" => $user]);
        if (count($defaultTemplate)) {
            return new JsonResponse($this->serializer->normalize($defaultTemplate, 'jsonld'), Response::HTTP_OK);
        } else {
            return new JsonResponse([], Response::HTTP_OK);
        }
    }

    public function deleteDefaultUserTemplateAction($type)
    {
        $this->isAllowedType($type);
        $genericTemplateProvider = $this->genericTemplateService;
        $user = $genericTemplateProvider->getCurrentUser()->getUuid();
        $templateRepo = $this->entityManager->getRepository(UserDefaultTemplate::class);
        $template = $templateRepo->findOneBy(array("userId" => $user));
        if (!is_null($template)) {
            $genericTemplateProvider->deleteTemplate($template);
            return new JsonResponse('Success');
        } else {
            return new Response(null, Response::HTTP_NOT_FOUND);
        }
    }

    public function resetTemplateAction(Request $request, $type, $id)
    {
        $this->isAllowedType($type);
        $genericTemplateProvider = $this->genericTemplateService;
        $resource = GenericTemplate::class;
        $genericTemplate = $this->chainItemDataProvider->getItem($resource, ["uuid" => $id]);
        if (!$genericTemplate) {
            throw new NotFoundHttpException("Template with Provided UUID does not exists");
        }
        $parentTemplateId = $genericTemplate->getParentTemplateId();
        if (!empty($parentTemplateId) && !is_null($parentTemplateId)) {
            $parentDashBoard = $this->chainItemDataProvider->getItem($resource, ["uuid" => $parentTemplateId]);
            if (!$parentDashBoard) {
                throw new NotFoundHttpException("Parent Template ID provided does not exists");
            }
            $genericTemplate->setConfig($parentDashBoard->getConfig());
            $genericTemplateProvider->saveTemplate($genericTemplate);
        }
        return new JsonResponse('Success');
    }
}
