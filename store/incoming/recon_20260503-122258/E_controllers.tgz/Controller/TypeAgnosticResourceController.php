<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Psr\Log\LoggerInterface;
use App\Service\TeamsProvider;
use App\Constants\AppConstants;
use App\Service\MetadataHelper;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use App\Service\BulkRequestService;
use App\Service\InsertExpressionBuilder;
use Doctrine\Inflector\InflectorFactory;
use Doctrine\ORM\EntityManagerInterface;
use App\Service\NormalizerUtilityService;
use App\Entity\ModelMetadata\ModelMetadata;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Core\Exception\ItemNotFoundException;
use App\EventSubscriber\MqMessagebroadcastSubscriber;
use ApiPlatform\Core\Exception\InvalidArgumentException;
use App\Utility\PayloadUtils;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class TypeAgnosticResourceController extends AbstractController
{
    private const SQL_GENERIC_QUERY = "INSERT INTO %s (%s) VALUES %s ON CONFLICT (%s) DO UPDATE set %s returning uuid";

    public function __construct(
        private BulkRequestService $bulkRequestService,
        private MetadataHelper $metadataHelper,
        private ContainerInterface $containers,
        private EntityManagerInterface $entityManager,
        private NormalizerUtilityService $normalizerUtilityService,
        private FsrVoter $fsrVoter,
        private TeamsProvider $teamProvider,
        private InsertExpressionBuilder $insertExpressionBuilder,
        protected LoggerInterface $logger,
        protected UtilityService $utilityService,
        protected PayloadUtils $payloadUtils
    ) {
    }

    public function createRecords(Request $request)
    {
        $auditData = [];
        $replicationDataPost = [];
        $replicationDataPut = [];
        $replicationDataDelete = [];
        $replicationWorkflow = [];
        $objectData = json_decode($request->getContent(), true);
        $headers = $request->headers->all();
        $queryParams = $request->query->all();
        $failedObj = [];
        $successObj = [];
        $createMode = 'insert';
        $replaceIfExists = false;
        if (array_key_exists('route', $objectData)) {
            $commonRouteName = $objectData['route'];
            $createMode = array_key_exists('__mode', $objectData) ? $objectData['__mode'] : 'insert';
            $replaceIfExists = array_key_exists('__replace', $objectData) ? $objectData['__replace'] : false;
            $commonSubrequestPath = ($createMode == "insert") ? '/api/3/' . $commonRouteName : '/api/3/upsert/' . $commonRouteName;
            if (array_key_exists('data', $objectData)) {
                $objectData = $objectData['data'];
            } elseif (array_key_exists('__data', $objectData)) {
                $objectData = $objectData['__data'];
            }
            $method = 'POST';
        }
        $fail_detected = false;
        foreach ($objectData as $k => $item) {
            if (isset($commonSubrequestPath)) {
                $subrequestPath = $commonSubrequestPath;
                if ($replaceIfExists) {
                    $item['__replace'] = $replaceIfExists;
                }
            } else {
                if (!array_key_exists('@type', $item)) {
                    throw new InvalidArgumentException(ErrorConstants::TYPE_MUST_BE_SPECIFIED);
                }
                if (array_key_exists('@id', $item)) {
                    $method = 'PUT';
                    $subrequestPath = $item['@id'];
                } else {
                    try {
                        $routeName = $this->metadataHelper->getTypeFromShortName($item['@type']);
                        $subrequestPath = '/api/3/' . $routeName;
                        $method = 'POST';
                    } catch (ItemNotFoundException $infe) {
                        $this->logger->error("Resource not found : " . $routeName . ". Invalid resource type");
                    } catch (\Exception $e) {
                        $this->logger->error('Failure: ' . $e->getMessage());
                    }
                }
            }
            $this->bulkRequestService->updateReferenceToIriAndCheckForRelation($item);
            // workflows have an issue with cascade persist unless the container is reinitialized
            $reinitializeKernel = false;
            if ($fail_detected || $item['@type'] === 'Workflow' || $item['@type'] === 'WorkflowCollection') {
                $reinitializeKernel = true;
                $fail_detected = false;
            }
            unset($item['@type']);
            $response = $this->bulkRequestService->executeSubRequest(
                $k,
                $subrequestPath,
                $method,
                $headers,
                $queryParams,
                json_encode($item),
                $auditData,
                $replicationDataPost,
                $replicationDataPut,
                $replicationDataDelete,
                $replicationWorkflow,
                'agnostic_bulk',
                $reinitializeKernel
            );
            if ($response->getStatusCode() == Response::HTTP_CREATED || $response->getStatusCode() == Response::HTTP_OK) {
                $successObj[] = json_decode($response->getContent(), true);
            } else {
                $failedObj[] = "Index #" . $k . " failed with error: " . $response->getContent();
                // entity manager gets closed if an exception occurs. So proceeding to the next set of objects will not work
                $fail_detected = true;
            }
        }
        if (empty($failedObj)) {
            $responseCode = Response::HTTP_OK;
        } else {
            $responseCode = Response::HTTP_BAD_REQUEST;
        }
        // skip serialization for perf intensive bulk inserts
        if ($this->normalizerUtilityService->getOption('statusOnly', array(), false, true)) {
            $response = ['peristed' => count($successObj), 'failed' => count($failedObj)];
        } else {
            $response = ['persisted' => $successObj, 'failed' => $failedObj];
        }
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->setContentType('application/json');
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->publish(
            json_encode($auditData),
            MqMessagebroadcastSubscriber::DEFAULT_KEY
        );
        // type agnostic sends only audit data. doesn't send data to tenant node
        return new JsonResponse($response, $responseCode);
    }

    public function createSqlRecords(Request $request, $resourceShortName)
    {
        $resourceClass = $this->metadataHelper->getResourceFromClassName($resourceShortName);
        $classMeta = $this->entityManager->getClassMetadata($resourceClass);
        $module = $this->metadataHelper->getModuleFromClassName($resourceClass);
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . $module);
        $objectData = json_decode($request->getContent(), true);
        $this->payloadUtils->validatePayload($resourceClass, $objectData);

        $mmdRepository = $this->entityManager->getRepository(ModelMetadata::class);
        $mmdObject = $mmdRepository->findBy(["type" => $resourceShortName]);
        if (!count($mmdObject)) {
            return new Response(sprintf("%s not found", $resourceShortName), Response::HTTP_BAD_REQUEST);
        }

        if (array_key_exists('uniqueConstraints', $classMeta->table)) {
            $constraintName = $module . '_unique';
            $uniqueColumn = $classMeta->table['uniqueConstraints'][$constraintName]['columns'];
        } else {
            $uniqueColumn = ['uuid'];
        }
        $this->logger->debug("Unique Column identified: ". implode(',', $uniqueColumn));

        $tableName = $classMeta->getTableName();
        [$sqlInsertParams, $picklistFields, $dateTimeField, $multiselectPickListField, $lookupFields, $booleanFields] = $this->insertExpressionBuilder->iterateMmd(
            $mmdObject[0],
            $resourceClass
        );
        [$sqlValue, $queryParams, $multiselectQueries, $tagQueries, $selfFeedLinkingQueries, $tags, $uuidList] =
            $this->insertExpressionBuilder->getSqlInsertValues(
                $module,
                $classMeta,
                $objectData,
                $sqlInsertParams,
                $picklistFields,
                $dateTimeField,
                $multiselectPickListField,
                $lookupFields,
                $booleanFields
            );

        # Remove the UUID field from Conflict SQL params, as UUID should be preserved.
        $excludedParams = array_diff($sqlInsertParams, ['uuid']);
        # Add only those params to conflicts, which are present in incoming JSON, we will be considering only first object of list for same.
        $excludedParams = array_intersect($excludedParams, array_map('strtolower', array_keys($objectData['data'][0])));
        array_walk($excludedParams, function (&$value) {
            $value = "$value=Excluded.$value";
        });
        # "INSERT INTO %s (%s) VALUES %s ON CONFLICT (%s) DO UPDATE set %s returning uuid";
        $finalQuery = sprintf(
            self::SQL_GENERIC_QUERY,
            $tableName,
            implode(',', $sqlInsertParams),
            $sqlValue,
            implode(',', $uniqueColumn),
            implode(',', $excludedParams)
        );
        try {
            $this->entityManager->getConnection()->executeStatement($finalQuery, $queryParams);

            if ($uniqueColumn[0] != 'uuid') {
                $sql = sprintf("select uuid from $tableName where uuid in ('%s')", implode("','", $uuidList));
                $dbUuids = $this->entityManager->getConnection()->fetchAllAssociative($sql);
                if (empty($dbUuids)) {
                    return new JsonResponse(array("status" => "success"), Response::HTTP_OK);
                }
                foreach ($dbUuids as $dbUuid) {
                    $existingUuids[] = $dbUuid['uuid'];
                }
            } else {
                $existingUuids = $uuidList;
            }
            $this->insertExpressionBuilder->handleMultiSelectInsertion($multiselectQueries, $existingUuids);
            if ($this->insertExpressionBuilder->isTaggable($resourceClass)) {
                $this->insertExpressionBuilder->insertTags($tagQueries, $tags, $existingUuids);
            }
            if ($this->insertExpressionBuilder->isOwnable($resourceClass)) {
                $this->insertExpressionBuilder->handleOwnablity($module, $existingUuids);
            }
            if ($module == 'threat_intel_feeds') {
                // for threat intel feeds, related self linking is supported
                $this->insertExpressionBuilder->handleFeedSelfLinking($selfFeedLinkingQueries, $existingUuids);
                // flush the config prop object
                $this->entityManager->flush();
            }
            # Sending the message to audit for bulk insertion request.
            $itemToBroadcast = $this->prepareChangeData(
                $existingUuids,
                'Bulk Insert',
                $resourceShortName
            );
            $itemToBroadcast[AppConstants::ELASTIC_SEARCH_OPERATION_KEY] = 'bulk_insert';

            $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->setContentType('application/json');
            $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->publish(json_encode([$itemToBroadcast]), AppConstants::DEFAULT_KEY);
        } catch (InvalidArgumentException | \Exception $e) {
            if (method_exists($e, 'getPrevious')) {
                $conflictMessage = explode("\nDETAIL:  ", $e->getPrevious()->getMessage())[1];
                if (is_null($conflictMessage) || empty($conflictMessage)) {
                    $conflictMessage = explode("ERROR:  ", $e->getPrevious()->getMessage())[1];
                }
                throw new BadRequestHttpException("Error: " . $conflictMessage);
            }
            throw new BadRequestHttpException("Error occurred while creating record: " . $e->getMessage());
        }

        return new JsonResponse(array("status" => "success", "uuids" => $existingUuids), Response::HTTP_OK);
    }

    private function getUserName()
    {
        $user = $this->getUser();
        if (method_exists($user, 'getFirstname')) {
            return $user->getFirstname() . ' ' . $user->getLastname();
        }
        return $user->getName();
    }

    private function prepareChangeData(
        $createdObject,
        $method,
        $resourceShortName
    ) {
        $delta_data = [];
        $delta_data['newData'] = $createdObject;
        $delta_data['changeData'] = $resourceShortName;
        $userName = $this->getUserName();
        $userId = $this->getUser()->getUuid();
        return [
            AppConstants::DELTA_DATA => $delta_data,
            AppConstants::HTTP_METHOD => $method,
            AppConstants::REMOTE_ADDR => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            AppConstants::WEB_SOCKET_SESSION_ID => isset($_SERVER['HTTP_WEBSOCKET_SESSIONID']) ? $_SERVER['HTTP_WEBSOCKET_SESSIONID'] : null,
            AppConstants::COMPONENT => 'crudhub',
            AppConstants::ENTITY_TYPE => $resourceShortName,
            AppConstants::USER_UUID => $userId,
            AppConstants::TRANSACTION_DATE => round(microtime(true) * 1000),
            AppConstants::USER => $userName
        ];
    }
}
