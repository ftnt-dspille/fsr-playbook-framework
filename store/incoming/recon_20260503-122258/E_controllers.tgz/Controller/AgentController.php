<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Service\IriHelper;
use App\Entity\Custom\Agent;
use Psr\Log\LoggerInterface;
use App\Service\UtilityService;
use App\Providers\QueryProvider;
use App\Query\ExpressionBuilder;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use Symfony\Component\Process\Process;
use Doctrine\ORM\EntityManagerInterface;
use GuzzleHttp\Psr7\Request as GuzzleRequest;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use ApiPlatform\Core\DataProvider\CollectionDataProviderInterface;
use ApiPlatform\Core\Serializer\SerializerContextBuilderInterface;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

// Only Adding Code for Agent Create and Update.
// This code needs to be generalized hence commeneted entire code
// Need discussion on this Controller
class AgentController extends AbstractController
{
    const MODULE_TYPE = "agents";
    const ALLOW_REMOTE_MMD = 'allowRemoteMMDModification';
    const REPLICATION_ROUTINGKEY = 'route.crudhub.tenant.request.agentconfig';
    const ARCHIVESOURCE = '/opt/cyops-api/agentconfig/source/';
    const ARCHIVEDESTINATION = '/opt/cyops-api/agentconfig/destination/';
    const ARCHIVEFILE = '/opt/cyops-api/agentconfig/';
    const MANAGE_PWD = '/opt/cyops/scripts/manage_passwords.py';

    protected $fsrVoter;
    protected $utilityService;
    protected $entityManager;
    protected $iriHelper;
    protected $containers;
    private $queryProvider;
    private $serializerContextBuilder;
    private $collectionDataProvider;

    public function __construct(
        FsrVoter $fsrVoter,
        UtilityService $utilityService,
        EntityManagerInterface $entityManager,
        IriHelper $iriHelper,
        QueryProvider $queryProvider,
        SerializerContextBuilderInterface $serializerContextBuilder,
        CollectionDataProviderInterface $collectionDataProvider,
        protected SerializerInterface $serializer,
        ContainerInterface $containers,
        protected LoggerInterface $logger
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->utilityService = $utilityService;
        $this->entityManager = $entityManager;
        $this->iriHelper = $iriHelper;
        $this->queryProvider = $queryProvider;
        $this->serializerContextBuilder = $serializerContextBuilder;
        $this->collectionDataProvider = $collectionDataProvider;
        $this->serializer = $serializer;
        $this->containers = $containers;
    }

    /**
     * @param Request $request
     * @return Response|static
     */
    public function getAction(Request $request)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.agents');
        $queryLimit = $request->get('$limit', 30);
        $queryPage = $request->get('$page', 1);
        $accessibleQueryFilter =
            ExpressionBuilder::logicAnd(
                ExpressionBuilder::logicOr(
                    ExpressionBuilder::field('role')->notEquals('master')
                ),
                ExpressionBuilder::logicOr(
                    ExpressionBuilder::field('role')->notEquals('self')
                )
            );
        $this->queryProvider->setAdditionalFilters($accessibleQueryFilter->toArray());
        $request->overrideGlobals();

        $attributes['filters'] = ['$limit' => $queryLimit, '$page' => $queryPage];
        $attributes['resource_class'] = Agent::class;
        $attributes['collection_operation_name'] = "get";
        $context = $this->serializerContextBuilder->createFromRequest($request, true, $attributes);
        $associatedEntities = $this->collectionDataProvider->getCollection(Agent::class, $request, $attributes);
        $data1 = $this->serializer->normalize($associatedEntities, 'jsonld', $context);
        return new JsonResponse($data1);
    }

    public function postAction(Request $request)
    {
        $resource = Agent::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.agents');
        $decodedRequestData = json_decode($request->getContent(), true);
        $this->prePostCheck($decodedRequestData, $resource);
        $request_data = $this->prePostAdd($decodedRequestData);
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($request_data),
            $resource,
            'jsonld',
            ['fetch_data' => false]
        );
        $request->attributes->set('_api_collection_operation_name', 'post');
        $request->attributes->set('_api_item_operation_name', 'post');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->overrideGlobals();

        return $denormalizedObject;
    }

    /**
     * @param $decodedRequestData
     * @throws BadRequestHttpException
     */
    public function prePostCheck($decodedRequestData, $resource)
    {
        $agentRepo = $this->entityManager->getRepository($resource);
        $agentId = isset($decodedRequestData['agentId']) ? $decodedRequestData['agentId'] : null;
        if ($agentId) {
            $existingAgentObj = $this->utilityService->getItemWithWhere($agentRepo, ['agentId' => $agentId]);
            if ($existingAgentObj) {
                throw new BadRequestHttpException(sprintf(ErrorConstants::AGENT_ID_EXISTS, $agentId));
            }
        }
        $agentName = isset($decodedRequestData['name']) ? $decodedRequestData['name'] : null;
        if ($agentName) {
            $existingAgentObj = $this->utilityService->getItemWithWhere($agentRepo, ['name' => $agentName]);
            if ($existingAgentObj) {
                throw new BadRequestHttpException(sprintf(ErrorConstants::AGENT_NAME_EXISTS, $agentName));
            }
        }

        if ($decodedRequestData['isLocal']) {
            throw new BadRequestHttpException('UnAuthorized Access');
        }

        if (isset($decodedRequestData['role']) && $decodedRequestData['role'] == 'self') {
            throw new BadRequestHttpException(ErrorConstants::SELF_AGENT_ADD_DETECTED);
        }
    }

    public function importEncryptionKey($enc_key)
    {
        $dasUri = $this->containers->getParameter('das.uri');
        $dasClient = $this->containers->get("app.proxy.client.das");
        $key = ["encryption_key" => $enc_key];
        $headers =["Content-type" => "application/json"];
        $dasRequests = new GuzzleRequest('post', $dasUri . '/encryption-key/', $headers, json_encode($key));
        try {
            $dasResponse = $dasClient->send($dasRequests);
        } catch (\Exception $e) {
            $errMsg = $e->getResponse() ? json_decode($e->getResponse()->getBody()->read(2048), true) : ["message" => $e->getMessage()];
            $errMsgStr = is_array($errMsg) ? json_encode($errMsg) : $errMsg;
            $this->logger->error($errMsgStr);
            throw new BadRequestHttpException(sprintf(ErrorConstants::ENCRYPTION_KEY_IMPORT_FAILED, $errMsgStr));
        }
    }

    public function getAgentPassword($password)
    {
        $waitTime = 6;
        $attemptCount = 5;
        $output = '';
        do {
            sleep($waitTime);
            $process = new Process(['python3', self::MANAGE_PWD, '--decrypt', $password, 'jQp3(7@jod#j38d1']);
            $process->run();
            // executes after the command finishes
            if (!$process->isSuccessful()) {
                throw new ProcessFailedException($process);
            }
            $output = $process->getOutput();

            if (str_starts_with($output, 'Password:')) {
                return trim(substr($output, strlen('Password:'), strlen($output)));
            }
            $attemptCount--;
        } while ($attemptCount > 0);
        throw new BadRequestHttpException(sprintf(ErrorConstants::DB_PASSWORD_DECRYPT_FAILED, $output));
    }

    public function generateAgentEncryptionKey()
    {
        $process = new Process(['python3', self::MANAGE_PWD, '--generate-key','--type','peerwise']);
        $process->run();

        // executes after the command finishes
        if (!$process->isSuccessful()) {
            $this->logger->error(sprintf(ErrorConstants::ENCRYPTION_KEY_GENERATION_FAILED, trim($process->getErrorOutput() ?: $process->getOutput())));
            throw new ProcessFailedException($process);
        }
        $output = $process->getOutput();

        if (!str_starts_with($output, 'PE')) {
            $this->logger->error(sprintf(ErrorConstants::ENCRYPTION_KEY_GENERATION_FAILED, $output));
            throw new BadRequestHttpException(sprintf(ErrorConstants::ENCRYPTION_KEY_GENERATION_FAILED, $output));
        } else {
            return trim($output);
        }
    }

    public function prePostAdd($decodedRequestData)
    {
        if (!isset($decodedRequestData['encryptionKey'])) {
            $decodedRequestData['encryptionKey'] = $this->generateAgentEncryptionKey();
        } else {
            $this->importEncryptionKey($decodedRequestData['encryptionKey']);
        }
        if (!isset($decodedRequestData['configstatus'])) {
            $decodedRequestData['configstatus'] = '/api/3/picklists/0dff7239-38a4-4dc8-9fe6-97932d2bd35f';
        }
        if (!isset($decodedRequestData['configurationHealth'])) {
            $decodedRequestData['configurationHealth'] = '/api/3/picklists/fb340c77-c2c6-471d-8081-77c9302b4bfb';
        }
        if (!isset($decodedRequestData['agentId'])) {
            $decodedRequestData['agentId'] = bin2hex(random_bytes(16));
        }
        if (!isset($decodedRequestData['password'])) {
            $decodedRequestData['password'] = bin2hex(random_bytes(16));
        } else {
            $decodedRequestData['password'] = $this->getAgentPassword($decodedRequestData['password']);
        }
        if (!isset($decodedRequestData['vhost'])) {
            $decodedRequestData['vhost'] = 'vhost_' . $decodedRequestData['agentId'];
        }
        if (!isset($decodedRequestData['username'])) {
            $decodedRequestData['username'] = 'user_' . $decodedRequestData['agentId'];
        }
        if (!isset($decodedRequestData['tenants'])) {
            $decodedRequestData['tenants'] = ['/api/3/tenants/b3a700f7-00be-4ef9-90c6-3c8fe6e1be63'];
        }
        if (!isset($decodedRequestData['ssl'])) {
            $decodedRequestData['ssl'] = true;
        }
        if (!isset($decodedRequestData['agentType'])) {
            $decodedRequestData['agentType'] = '502cb999-d0fe-466f-9d99-1f3300513e14';
        }
        if (!isset($decodedRequestData['role'])) {
            $decodedRequestData['role'] = 'tenant';
        }
        if (!isset($decodedRequestData['active'])) {
            $decodedRequestData['active'] = true;
        }
        if (!isset($decodedRequestData['version'])) {
            $decodedRequestData['version'] = $this->getParameter('product_version');
        }
        if ($decodedRequestData['allowRemoteConnectorOperation'] == null) {
            $decodedRequestData['allowRemoteConnectorOperation'] = true;
        }
        if (isset($decodedRequestData['clientCert']) && $decodedRequestData['clientCert']) {
            $this->validateClientCert($decodedRequestData['clientCert']);
            $decodedRequestData['clientCertExpiry'] = $this->getClientCertExpiry($decodedRequestData['clientCert']);
        }
        $decodedRequestData['isLocal'] = false;

        return $decodedRequestData;
    }

    public function prePutValidate($decodedRequestData)
    {
        if (isset($decodedRequestData['encryptionKey'])) {
            $this->importEncryptionKey($decodedRequestData['encryptionKey']);
        }

        if (isset($decodedRequestData['password'])) {
            $decodedRequestData['password'] = $this->getAgentPassword($decodedRequestData['password']);
        }

        if (isset($decodedRequestData['clientCert']) && $decodedRequestData['clientCert']) {
            $this->validateClientCert($decodedRequestData['clientCert']);
            $decodedRequestData['clientCertExpiry'] = $this->getClientCertExpiry($decodedRequestData['clientCert']);
        }
        return $decodedRequestData;
    }

    public function getClientCertExpiry($clientCert)
    {
        $data = openssl_x509_parse($clientCert);
        return $data['validTo_time_t'];
    }

    public function validateClientCert($clientCert)
    {
        $data = openssl_x509_parse($clientCert);
        if (array_key_exists("extensions", $data) && array_key_exists("extendedKeyUsage", $data["extensions"])) {
            $extendedKeyUsage = $data["extensions"]["extendedKeyUsage"];
            if (!strpos($extendedKeyUsage, "Client Authentication")) {
                throw new BadRequestHttpException(ErrorConstants::INVALID_CLIENT_CERT);
            }
        }
    }

    public function putAction(Request $request, $id)
    {
        $context = [];
        $resource = Agent::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.agents');
        $objectData = json_decode($request->getContent(), true);
        $objectData = $this->prePutValidate($objectData);
        $object = $this->iriHelper->findOrThrowNotFound('/api/3/agents/' . $id);
        $classPath = get_class($object);

        $groups = $this->utilityService->identifyChangeFields(json_decode($request->getContent()), $classPath);
        array_push($groups, "fsr_all");
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => array_merge($groups, ['password'])]
        );

        $context['object_to_populate'] = $object;
        if (array_key_exists('upgradeMessage', $objectData) && !is_null($objectData['upgradeMessage']) && $object->getUpgradeMessage()) {
            $objectData['upgradeMessage'] = $object->getUpgradeMessage() . ' <br> ' . $objectData['upgradeMessage'];
        }
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($objectData),
            $resource,
            'jsonld',
            $context + ['fetch_data' => false]
        );

        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);

        $request->attributes->set('_api_collection_operation_name', 'put');
        $request->attributes->set('_api_item_operation_name', 'put');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->attributes->set('previous_data', $object);
        $request->overrideGlobals();
        return $denormalizedObject;
    }

    public function deleteAction(Request $request, $id)
    {
        $resource = Agent::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.agents');
        $object = $this->iriHelper->findOrThrowNotFound('/api/3/agents/' . $id);
        $classPath = get_class($object);
        if ($object->getRole() == 'self') {
            return new Response("Deletion of self Agent is not allowed", Response::HTTP_BAD_REQUEST);
        }
        $groups = $this->utilityService->identifyChangeFields(json_decode($request->getContent()), $classPath);
        array_push($groups, "fsr_all");
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => $groups]
        );
        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);
        $request->attributes->set('_api_item_operation_name', 'delete');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $object);
        $request->attributes->set('_format', 'jsonld');
        $request->attributes->set('previous_data', $object);
        $request->overrideGlobals();
        return $object;
    }
}
