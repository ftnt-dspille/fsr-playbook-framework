<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Ramsey\Uuid\Uuid;
use Psr\Log\LoggerInterface;
use App\Constants\AppConstants;
use App\Service\MetadataHelper;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use App\Controller\BaseController;
use ApiPlatform\Api\IriConverterInterface;
use App\Service\AccessibleTeamIdsProvider;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class SearchController extends BaseController
{

    protected $iriConverter;

    protected $accessibleTeamIdsProvider;

    protected $fsrVoter;

    protected $utilityService;

    public function __construct(
        IriConverterInterface $iriConverter,
        AccessibleTeamIdsProvider $accessibleTeamIdsProvider,
        ContainerInterface $containers,
        ResourceClassResolverInterface $resourceClassResolver,
        MetadataHelper $metadataHelper,
        FsrVoter $fsrVoter,
        TagAwareCacheInterface $cache,
        UtilityService $utilityService,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->iriConverter = $iriConverter;
        $this->accessibleTeamIdsProvider = $accessibleTeamIdsProvider;
        $this->fsrVoter = $fsrVoter;
        $this->utilityService = $utilityService;
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function search(Request $request)
    {
        $query = json_decode($request->getContent());

        $offset = isset($query->offset) ? intval($query->offset) : 0;
        $size = isset($query->size) ? $offset + intval($query->size) : 30;
        $recordModifiedFromDt = isset($query->modifyDateGte) ? $query->modifyDateGte : 0;
        $recordModifiedToDt = isset($query->modifyDateLte) ? $query->modifyDateLte : 0;
        $searchType = isset($query->searchType) ? $query->searchType : '_default';
        // Index List Send by UI
        $type = isset($query->index) ? $query->index : [];
        $index = $this->filterAccessibleTypes($type);
        $search_term = isset($query->q) ? $query->q : [];

        if (count($index) === 0) {
            throw new BadRequestHttpException('You must indicate which index to search on.\
            If index were specified, you do not have sufficient permissions to search against them.');
        }
        if (count($search_term) === 0) {
            throw new BadRequestHttpException('You must provide search term with minimal three character.');
        }

        $filter_term = $this->getAccessibleTeamIris();
        $current_user = $this->iriConverter->getIriFromResource($this->getUser());
        $sort = isset($query->sort) ? $query->sort : '_score';

        $payload = [
            'offset' => $offset,
            'size' => $size,
            'index' => $index,
            'filter_term' => $filter_term,
            'current_user' => $current_user,
            'search_term' => $search_term,
            'sort' => $sort,
            'recordModifiedFromDt' => $recordModifiedFromDt,
            'recordModifiedToDt' => $recordModifiedToDt,
            'searchType' => $searchType,
        ];

        $data = [
            'payload' => $payload,
            'esoperation' => 'search',
        ];

        $member = $this->sendSearchAction([$data], 'cyops.crudhub.essearch');
        $response = [
            'totalItems' => $member->search_result->total->value ? $member->search_result->total->value : 0,
            'results' => $member->search_result->hits ? $member->search_result->hits : [],
            'context_code' => $member->context_code ? $member->context_code : 400,
        ];
        return new JsonResponse($response);
    }

    public function searchSimilar(Request $request)
    {
        $query = json_decode($request->getContent());
        $module_type = $query->module_type;
        if (!$module_type) {
            throw new BadRequestHttpException("Module Type is Missing in request");
        }

        $offset = isset($query->offset) ? intval($query->offset) : 0;
        $size = isset($query->size) ? $offset + intval($query->size) : 30;

        $id = $query->id;
        $docs = $query->docs;
        $fields = $query->fields;

        $sort = isset($query->sort) ? $query->sort : '_score';
        $filter = $query->filter;

        $payload = [
            'id' => $id,
            'docs' => $docs,
            'offset' => $offset,
            'size' => $size,
            'index' => $query->index,
            'sort' => $sort,
            'from_date' => $query->fromDate,
            'fields' => $fields,
            'filter' => $filter,
        ];

        $query_type = $query->query_type;
        $aggs = $query->aggs;
        if ($query_type === 'prediction') {
            $payload['aggs'] = $aggs;
            $output_fields = [];

            foreach ($fields as $item) {
                array_push($output_fields, $item->name);
            }
            foreach ($aggs as $item) {
                array_push($output_fields, $item);
            }

            $payload['output_fields'] = $output_fields;
        } else {
            $teams = $this->getAccessibleTeamIris();
            $payload['current_user'] = $this->iriConverter->getIriFromResource($this->getUser());
            $payload['teams'] = $teams;
            $payload['aggs'] = $aggs;
            $output_fields = $query->output_fields;
            $payload['output_fields'] = $output_fields;
        }

        $data = [
            'esoperation' => 'similar',
            'payload' => $payload,
        ];

        $response = $this->sendSearchAction([$data], 'cyops.crudhub.essearch');
        $iris = [];

        if (isset($response->status_code) && $response->status_code >= 400) {
            throw new BadRequestHttpException($response->error);
        }

        foreach ($response->result as $item) {
            array_push($iris, $item->{'_id'});
        }
        if ($iris) {
            $filter = ['uuid' => $iris];
            // Add relevent code changes
            $moduleresource = $this->getResourceFromClassName($module_type);
            $managerRegistry = $this->containers->get('doctrine');
            $manager = $managerRegistry->getManagerForClass($moduleresource);
            $modelMetaDataRepository = $manager->getRepository($moduleresource);

            $pg_data = $this->utilityService->getItemWithWhere($modelMetaDataRepository, $filter);
            $serializer = $this->containers->get('serializer');

            $resourceContext = ['resource_class' => $moduleresource];
            $data = $serializer->normalize(
                $pg_data,
                'jsonld',
                $resourceContext + ['groups' => array_merge($output_fields, ['uuid', 'id']), "ignore_html_escape" => true]
            );
            $output = [];
            foreach ($response->result as $result) {
                foreach ($data['hydra:member'] as $item) {
                    $id_explode = explode('/', $item['@id']);
                    if ($result->{'_id'} == end($id_explode)) {
                        $item['__score'] = $result->{'_score'};
                        array_push($output, $item);
                        break;
                    }
                }
            }

            $response->{'result'} = $output;
        }
        return new JsonResponse($response);
    }

    public function searchStatus(Request $request)
    {
        $payload = [];
        $data = [
            'payload' => $payload,
            'esoperation' => 'status',
        ];
        $member = $this->sendSearchAction([$data], 'cyops.crudhub.status');
        $response = [
            'totalItems' => $member,
        ];
        return new JsonResponse($response);
    }

    protected function filterAccessibleTypes($types)
    {
        $allowedType = [];
        foreach ($types as $type) {
            $perm = sprintf('read.%s', $type);
            if ($this->fsrVoter->isGranted($perm)) {
                $allowedType[] = $type;
            }
        }
        return $allowedType;
    }

    /**
     * @return array
     */
    protected function getAccessibleTeamIris()
    {
        $teamBaseIri = AppConstants::TEAM_IRI;
        $accessibleTeamIds = $this->accessibleTeamIdsProvider->getDataForCurrentUser();
        $accessibleTeamIris = array_map(function ($teamId) use ($teamBaseIri) {
            return sprintf('%s/%s', $teamBaseIri, $teamId);
        }, $accessibleTeamIds);
        return json_decode(json_encode($accessibleTeamIris), true);
    }

    public function sendSearchAction(array $data, $key = 'cyops.crudhub.essearch')
    {
        $request_uuid = Uuid::uuid4()->toString();
        $client = $this->containers->get('old_sound_rabbit_mq.parallel_rpc');
        try {
            $client->addRequest(json_encode($data), 'cyops.crudhub.datanotify', $request_uuid, $key, 50);
            return json_decode($client->getReplies()[$request_uuid]);
        } catch (BadRequestHttpException | \Exception $exception) {
            throw new BadRequestHttpException('Search Indexing is in progress, please try after some time');
        }
    }
}
