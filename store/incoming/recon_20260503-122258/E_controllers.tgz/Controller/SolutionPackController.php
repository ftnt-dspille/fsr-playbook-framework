<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Ramsey\Uuid\Uuid;
use App\Entity\Core\Tag;
use App\Entity\Core\File;
use App\Entity\Core\PgFile;
use Psr\Log\LoggerInterface;
use App\Entity\Core\ImportJob;
use App\Constants\AppConstants;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use App\Entity\Core\SolutionPack;
use App\Entity\Authorization\Team;
use App\Service\BulkRequestService;
use Doctrine\Inflector\InflectorFactory;
use Doctrine\ORM\EntityManagerInterface;
use ApiPlatform\Api\IriConverterInterface;
use App\Service\SolutionPackUtilityService;
use Digilist\DependencyGraph\DependencyNode;
use Symfony\Component\Filesystem\Filesystem;
use Digilist\DependencyGraph\DependencyGraph;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use App\EventSubscriber\MqMessagebroadcastSubscriber;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpKernel\Exception\HttpException;
use ApiPlatform\Core\DataProvider\ItemDataProviderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class SolutionPackController extends BaseController
{
    public const TMP_PATH = "/tmp/solutionpacks/";
    public const DATA_ROUTING_KEY = 'key.api.notify';
    public const DUPLICATE_MESSAGE = "DUPLICATEMESSAGE";
    public const SOLUTION_PACK = 'solutionPack';
    public const CONNECTOR = 'connector';
    public const WIDGET = 'widget';
    public const INSTALL_DEPTH = 10;

    /** @var FileSystem */
    protected $fileSystem;

    public function __construct(
        protected FsrVoter $fsrVoter,
        protected EntityManagerInterface $entityManager,
        protected ContainerInterface $containers,
        protected SolutionPackUtilityService $utilityService,
        protected ItemDataProviderInterface $itemDataProvider,
        protected BulkRequestService $bulkRequestService,
        protected ResourceClassResolverInterface $resourceClassResolver,
        protected TagAwareCacheInterface $cache,
        protected TokenStorageInterface $tokenStorage,
        protected MetadataHelper $metadataHelper,
        protected LoggerInterface $logger,
        protected IriConverterInterface $iriConverter,
        protected SerializerInterface $serializer
    ) {
        $this->fileSystem = new Filesystem();
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }


    public function previewAction(Request $request)
    {
        if (!$this->fsrVoter->isGranted("create.solutionpacks")) {
            throw new AccessDeniedException();
        }
        if ($request->files->has('file') &&  $request->query->get('$type', self::SOLUTION_PACK) == self::SOLUTION_PACK) {
            $entityRepository = $this->entityManager->getRepository(SolutionPack::class);
            list($fileBasePath, $fileExtractedPath, $fileName) = $this->dumpFileToTemp($request);
            if (!file_exists($fileExtractedPath . 'info.json')) {
                $this->fileSystem->remove($fileBasePath);
                throw new BadRequestHttpException("Required metadata info.json file missing from the uploaded file. Upload a valid solution pack.");
            }
            $infoContent = json_decode(file_get_contents($fileExtractedPath . 'info.json'), true);
            $customSolutionPack = [];
            $filter = [];
            if (!array_key_exists('version', $infoContent) || !array_key_exists('name', $infoContent) || !array_key_exists('label', $infoContent) || !array_key_exists('type', $infoContent) || empty($infoContent['version']) || empty($infoContent['name']) || empty($infoContent['label']) || empty($infoContent['type']) || ($infoContent['type'] != AppConstants::SOLUTIONPACK_TYPE && $infoContent['type'] != AppConstants::MULTICONTENT_TYPE)) {
                $this->fileSystem->remove($fileBasePath);
                throw new BadRequestHttpException("Incorrect required metadata in info.json file. Upload a valid solution pack.");
            }
            if (isset($infoContent['dependencies'])) {
                foreach ($infoContent['dependencies'] as $value) {
                    $customSolutionPack[$value['name']] = ['name' => $value['name'], 'label' => $value['label']];
                    $filter[] = $value['name'];
                }
                $allDependencies =  $entityRepository->findBy(['name' => $filter]);
                foreach ($allDependencies as $value) {
                    if (array_key_exists($value->getName(), $customSolutionPack)) {
                        unset($customSolutionPack[$value->getName()]);
                    }
                }
            }
            if (array_key_exists('installed', $infoContent) && !$infoContent['installed']) {
                $this->fileSystem->remove($fileBasePath);
                throw new BadRequestHttpException("Uploaded solution pack is in draft mode. install the solution pack on source environment and Export again.");
            }
            if (!empty($customSolutionPack)) {
                $infoContent['customDependencies'] = $customSolutionPack;
            }
            $infoContent['existsOnRepo'] = false;
            $existingRecord =  $entityRepository->findBy(['name' => $infoContent['name'], 'local' => false]);
            if ($existingRecord) {
                $infoContent['existsOnRepo'] = true;
            }
            $infoContent['infoContent'] = $infoContent;
            $infoContent['iconLarge'] = $this->updateSPImage($infoContent, $fileExtractedPath);
            $this->fileSystem->remove($fileBasePath);
            return new JsonResponse($infoContent);
        }
        return new JsonResponse([], Response::HTTP_BAD_REQUEST);
    }

    private function _installIntegration($fileExtractedPath, $fileType, $fileNameExplode, $replace)
    {
        $uri = sprintf('%s/import-connector/%s/?replace=%s&format=json', $this->containers->getParameter('integrations.uri'), $fileNameExplode, $replace);
        $fileStream = fopen($fileExtractedPath, 'rb');
        $token = $this->tokenStorage->getToken();
        $authorization = $token ? sprintf("Bearer %s", $token->getCredentials()) : null;
        $params = [
            'verify' => false,
            'body' => $fileStream,
            'headers' => [
                'Authorization' => $authorization
            ]
        ];
        try {
            $client = $this->containers->get("app.proxy.client.integrations");
            $integrationResponse = $client->request('POST', $uri, $params);
            $integrationResponseBody = json_decode($integrationResponse->getBody());
            $solutionRecord = $this->utilityService->getRecord($integrationResponseBody->name, $integrationResponseBody->version, $fileType);
            if ($solutionRecord) {
                $integrationResponseBody->uuid = $solutionRecord->getUuid();
                return new JsonResponse($integrationResponseBody, $integrationResponse->getStatusCode());
            } else {
                $solutionPack = new SolutionPack();
                $solutionPack->setUuid(Uuid::uuid4()->toString());
                $solutionPack->setName($integrationResponseBody->name);
                $solutionPack->setVersion($integrationResponseBody->version);
                $solutionPack->setDraft(false);
                $solutionPack->setInstalled($integrationResponseBody->installed);
                $solutionPack->setType($fileType);
                $solutionPack->setInfoContent((array)$integrationResponseBody->data);
                $solutionPack->setDraft(false);
                $solutionPack->setRecordId($integrationResponseBody->id);
                $solutionPack->setLabel($integrationResponseBody->label);
                $solutionPack->setPublisher($integrationResponseBody->publisher);
                $solutionPack->setIconLarge($integrationResponseBody->icon_large);
                $solutionPack->setDescription($integrationResponseBody->description);
                $solutionPack->setDevelopment($integrationResponseBody->development);
                $this->entityManager->persist($solutionPack);
                $this->entityManager->flush();
                $integrationResponseBody->uuid = $solutionPack->getUuid();
                return new JsonResponse($integrationResponseBody, $integrationResponse->getStatusCode());
            }
        } catch (BadRequestHttpException | \Exception $e) {
            throw new BadRequestHttpException("Connector with same name is already active.");
        }
    }

    private function _installWidget($fileExtractedPath, $fileName, $replace)
    {
        $uri = sprintf('%s/api/3/widgets/import', $this->containers->getParameter(AppConstants::CRUDHUB_PARAMETER_KEY));
        $fileStream = fopen($fileExtractedPath, 'r');
        $token = $this->tokenStorage->getToken();
        $authorization = $token ? sprintf("Bearer %s", $token->getCredentials()) : null;
        $client = new \GuzzleHttp\Client();

        $params = [
            'verify' => false,
            'multipart' => [
                [
                    'name' => 'replace',
                    'contents' => $replace,
                    'headers' => ['Content-Type' => 'application/json']
                ],
                [
                    'name' => 'file',
                    'contents' => $fileStream,
                    'filename' => $fileName,
                    'headers' => ['Content-Type' => 'application/gzip']
                ]
            ],
            'headers' => [
                'Authorization' => $authorization
            ]
        ];
        try {
            $response = $client->request('POST', $uri, $params);
            return new JsonResponse(json_decode($response->getBody()), $response->getStatusCode());
        } catch (BadRequestHttpException | \Exception $e) {
            $res = $e->getResponse();
            $resAsStr = $res->getBody()->getContents();
            $errMsg = json_decode($e->getResponse()->getBody()->read(2048), true);
            if ($resAsStr) {
                throw new BadRequestHttpException($resAsStr);
            } elseif ($errMsg) {
                throw new BadRequestHttpException($errMsg);
            } else {
                throw new BadRequestHttpException($e->getMessage());
            }
        }
    }

    public function install(Request $request)
    {
        $source = 'file';
        $name = null;
        $version = null;
        try {
            if (!$request->files->has('file')) {
                $requestBody = json_decode($request->getContent());
                $name = $requestBody->name;
                $version = $requestBody->version;
                $buildNumber =  $requestBody->buildNumber ?? "latest";
                $source = 'repo';

                list($fileBasePath, $fileExtractedPath, $fileName) = $this->utilityService->downloadAndDumpToTemp($name, $version, $buildNumber);
                $infoContent = file_exists($fileExtractedPath . 'info.json') ? json_decode(file_get_contents($fileExtractedPath . 'info.json'), true) : [];
                $installableType =  $infoContent && array_key_exists('type', $infoContent) ? $infoContent['type'] : "";
                $installItemName = $infoContent && array_key_exists('name', $infoContent) ? $infoContent['name'] : "";
                $this->utilityService->validateInstallationEligibility($installItemName, $installableType, $fileBasePath);
            } else {
                $fileType = $request->query->get('$type', self::SOLUTION_PACK);
                $replace = $request->query->get('$replace', false);

                list($fileBasePath, $fileExtractedPath, $fileName) = $this->dumpFileToTemp($request, $fileType);
                $fileName = $request->files->get('file')->getClientOriginalName();
                $fileNameExplode = explode(".", $fileName, -1)[0];
                $infoContent = file_exists($fileExtractedPath . 'info.json') ? json_decode(file_get_contents($fileExtractedPath . 'info.json'), true) : [];
                $installItemName = $infoContent && array_key_exists('name', $infoContent) ? $infoContent['name'] : "";

                $this->utilityService->validateInstallationEligibility($installItemName, $fileType, $fileBasePath);

                if ($fileType == 'connector') {
                    if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . PermissionsDictionaryBuilder::MODULE_CONNECTORS)) {
                        throw new AccessDeniedException();
                    }
                    return $this->_installIntegration($fileExtractedPath, $fileType, $fileNameExplode, $replace);
                } elseif ($fileType == 'widget') {
                    if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . PermissionsDictionaryBuilder::MODULE_WIDGETS)) {
                        throw new AccessDeniedException();
                    }
                    return $this->_installWidget($fileExtractedPath, $fileName, $replace);
                }
            }
            $replace = $request->query->getBoolean('$replace');
            $validContent = $this->validateInstallation($fileExtractedPath, $replace);
            $installSequence = $validContent[0];
            $infoContent = $validContent[1];
            if ($installSequence) {
                foreach ($installSequence as $installItemName) {
                    $this->utilityService->validateInstallationEligibility($installItemName, AppConstants::SOLUTIONPACK_TYPE);
                }
            }
            if (
                ($infoContent['type'] == 'connector' && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . PermissionsDictionaryBuilder::MODULE_CONNECTORS)) ||
                ($infoContent['type'] == 'widget' && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . PermissionsDictionaryBuilder::MODULE_WIDGETS)) ||
                (($infoContent['type'] == AppConstants::SOLUTIONPACK_TYPE || $infoContent['type'] == AppConstants::MULTICONTENT_TYPE)  && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . PermissionsDictionaryBuilder::MODULE_SOLUTIONPACKS))
            ) {
                throw new AccessDeniedException();
            }

            $infoContentDefault = $validContent[1];
            if (is_null($infoContent) || $infoContent == false) {
                $this->fileSystem->remove($fileBasePath);
                throw new BadRequestHttpException("Solution Pack already installed.");
            }
            if (is_array($validContent[1]) && array_key_exists("contents", $validContent[1])) {
                $this->validateContentsRBAC($validContent[1]["contents"], $infoContent['type']);
            }
            //handle upload file scenario
            if (is_null($name) || is_null($version)) {
                $name = $infoContent['name'];
                $version = $infoContent['version'];
            }
            $file = $this->utilityService->uploadFile($fileBasePath, $fileName);
            $infoContent['draft'] = false;
            $infoContent['installed'] = false;
            $infoContent['infoContent'] = $infoContentDefault;
            $recordType =  $infoContent['type'] == AppConstants::MULTICONTENT_TYPE ? AppConstants::SOLUTIONPACK_TYPE : $infoContent['type'];
            if ($replace || $source != 'repo') {
                $existingRecord = $this->utilityService->getRecord($name, $version, $recordType);
            } else {
                $existingRecord = $this->utilityService->getRecord($name, null, $recordType, $source);
            }
            if ($existingRecord) {
                $this->utilityService->removeFileObj($existingRecord, true, true, true);
            }
            $importJob = new ImportJob();
            $importJob->setUuid(Uuid::uuid4()->toString());
            $importJob->setFile(AppConstants::FILE_IRI . $file->getUuid());
            $importJob->setStatus(AppConstants::STATUS['DRAFT']);
            $importJob->setType('SolutionPack Import');
            $this->entityManager->persist($importJob);
            $this->entityManager->flush();
            $infoContent['iconLarge'] = $this->updateSPImage($infoContent, $fileExtractedPath);
            if ($existingRecord) {
                if ($source == 'repo') {
                    $existingRecord->setCertified($infoContent['certified']);
                } else {
                    $existingRecord->setCertified(false);
                    $existingRecord->setLocal(true);
                }

                //since the record is available in DB only update the status.
                $existingRecord->setFile(AppConstants::FILE_IRI . $file->getUuid());
                $existingRecord->setImportJob($importJob);
                $updatedRecord = $this->updateMarketPlaceInDB($existingRecord, $infoContent);
                if (!$updatedRecord) {
                    throw new BadRequestHttpException("During the installation of the solution pack and updating the solution pack record, an error occurred. Check prod.log file.");
                }
            } else {
                //case when install is from repo and the data is not yet synced in DB.
                if ($source == 'repo') {
                    $infoContent['local'] = false;
                } else {
                    $infoContent['local'] = true;
                    $infoContent['certified'] = false;
                }
                //case when upload a custom pack which is not from repo.
                $infoContent['file'] = $file->getUuid();
                $infoContent['importJob'] = $importJob;
                $updatedRecord = $this->saveMarketPlaceInDB($infoContent);
            }

            $index = 0;
            foreach ($installSequence as $index => $dependencyName) {
                if ($infoContent['name'] != $dependencyName) {
                    $importedBy = [["name" => $updatedRecord['label'], 'apiName' => $infoContent['name'], 'version' => $infoContent['version']]];
                    $minVersion = null;
                    foreach ($infoContent['dependencies'] as $item) {
                        if ($dependencyName == $item['name']) {
                            $importedBy = [['apiName' => $infoContent['name'], 'name' =>  $updatedRecord['label'], 'version' => $infoContent['version']]];
                            $minVersion = $item['minVersion'];
                            break;
                        }
                    }
                    $previousDep = $index != 0 ? $installSequence[$index - 1] : null;
                    $this->logger->info($dependencyName);
                    $this->sendData([[
                        "operation" => "dependencyInstall",
                        "entityType" => self::SOLUTION_PACK,
                        "name" => $dependencyName,
                        'minVersion' => $minVersion,
                        "importedBy" => $importedBy,
                        "source" => $source,
                        "userId" => $this->utilityService->getCurrentUser()->getUserId(),
                        "tokenType" => $this->utilityService->getCurrentUserType(),
                        "userToken" => $this->utilityService->getTokenFromStorage(),
                        "previousDep" => $previousDep
                    ]]);
                }
            }
            $consumerRecord['local'] = $updatedRecord['local'];
            $previousDep = $index != 0 ? $installSequence[$index - 1] : null;
            $this->sendData([
                [
                    "operation" => "install",
                    "entityType" => self::SOLUTION_PACK,
                    "name" => $infoContent['name'],
                    "version" => $infoContent['version'],
                    "data" => [],
                    "source" => $source,
                    "userId" => $this->utilityService->getCurrentUser()->getUserId(),
                    "tokenType" => $this->utilityService->getCurrentUserType(),
                    "userToken" => $this->utilityService->getTokenFromStorage(),
                    "previousDep" => $previousDep
                ]
            ]);
            $this->fileSystem->remove($fileBasePath);
            //Audit Solution pack  Installed Triggered.
            $body = $this->utilityService->prepareChangeData([], $updatedRecord, $updatedRecord['uuid'], "Create");
            $this->sendData([$body], MqMessagebroadcastSubscriber::DEFAULT_KEY);
            return new JsonResponse($updatedRecord);
        } catch (BadRequestHttpException $e) {
            throw $e;
        } catch (\Throwable $th) {
            $this->fileSystem->remove($fileBasePath);
            throw $th;
        }
    }

    public function updateAction(Request $request)
    {
        if (!$this->fsrVoter->isGranted("update.solutionpacks")) {
            throw new AccessDeniedException();
        }
        $source = 'file';
        $name = null;
        $version = null;
        try {
            if (!$request->files->has('file')) {
                $requestBody = json_decode($request->getContent());
                $name = $requestBody->name;
                $version = $requestBody->version;
                $buildNumber =  $requestBody->buildNumber ?? "latest";
                list($fileBasePath, $fileExtractedPath, $fileName) = $this->utilityService->downloadAndDumpToTemp($name, $version, $buildNumber);
                $source = 'repo';
            } else {
                list($fileBasePath, $fileExtractedPath, $fileName) = $this->dumpFileToTemp($request, self::SOLUTION_PACK);
            }
            $validContent = $this->validateInstallation($fileExtractedPath, true);
            $installSequence = $validContent[0];
            $infoContent = $validContent[1];
            $infoContentDefault = $validContent[1];
            if (!$infoContent) {
                //clean up extracted files
                return new JsonResponse("Solution pack already installed");
            }
            if (is_array($validContent[1]) && array_key_exists("contents", $validContent[1])) {
                $this->validateContentsRBAC($validContent[1]["contents"], $infoContent['type']);
            }
            // handle upload file scenario
            if (is_null($name) || is_null($version)) {
                $name = $infoContent['name'];
                $version = $infoContent['version'];
            }
            $file = $this->utilityService->uploadFile($fileBasePath, $fileName);
            $infoContent['draft'] = false;
            $infoContent['installed'] = true;
            $infoContent['infoContent'] = $infoContentDefault;
            if ($infoContent['type'] == 'connector') {
                $existingRecord = $this->utilityService->getRecord($infoContent['name'], $infoContent['version'], $infoContent['type']);
                if (!$existingRecord) {
                    $existingRecord = $this->saveMarketPlaceInDB($infoContent, true);
                }
            } else {
                $recordType =  $infoContent['type'] == AppConstants::MULTICONTENT_TYPE ? AppConstants::SOLUTIONPACK_TYPE : $infoContent['type'];
                $existingRecord = $this->utilityService->getRecord($name, null, $recordType);
            }
            if ($existingRecord) {
                $this->utilityService->removeFileObj($existingRecord, true, true, true);
                $importJob = new ImportJob();
                $importJob->setFile(AppConstants::FILE_IRI . $file->getUuid());
                $importJob->setUuid(Uuid::uuid4()->toString());
                $importJob->setStatus(AppConstants::STATUS['DRAFT']);
                $importJob->setType('SolutionPack Import');
                $this->entityManager->persist($importJob);
                $this->entityManager->flush();
                //since the record is available in DB only update the status.
                $existingRecord->setFile(AppConstants::FILE_IRI . $file->getUuid());
                $existingRecord->setImportJob($importJob);
                if ($source == 'repo') {
                    $existingRecord->setCertified($infoContent['certified']);
                } else {
                    $existingRecord->setCertified(false);
                    $existingRecord->setLocal(true);
                }
                $updatedRecord = $this->updateMarketPlaceInDB($existingRecord, $infoContent);
                if (!$updatedRecord) {
                    throw new BadRequestHttpException("During the upgrade of the solution pack, an error occurred when updating the solution pack record. Check prod.log file.");
                }
                foreach ($installSequence as $key => $value) {
                    if ($infoContent['name'] != $value) {
                        $importedBy = [['apiName' => $infoContent['name'], 'name' =>  $updatedRecord['label'], 'version' => $infoContent['version']]];
                        $this->sendData([[
                            "operation" => "dependencyInstall",
                            "entityType" => self::SOLUTION_PACK,
                            "name" => $value,
                            "importedBy" => $importedBy,
                            "source" => $source,
                            "userId" => $this->utilityService->getCurrentUser()->getUserId(),
                            "tokenType" => $this->utilityService->getCurrentUserType(),
                            "userToken" => $this->utilityService->getTokenFromStorage()
                        ]]);
                    }
                }
                $this->sendData([["operation" => "update",  "entityType" => self::SOLUTION_PACK, "name" => $infoContent['name'], "data" =>  $updatedRecord, "source" => $source, "userId" => $this->utilityService->getCurrentUser()->getUserId(), "tokenType" => $this->utilityService->getCurrentUserType(), "userToken" => $this->utilityService->getTokenFromStorage()]]);
                $serializer = $this->containers->get('serializer');
                $context['relationships'] = true;
                $oldData = $serializer->normalize($existingRecord, 'jsonld', $context);
                $body = $this->utilityService->prepareChangeData($oldData, $updatedRecord, $updatedRecord['uuid'], "Update");
                $this->sendData([$body], MqMessagebroadcastSubscriber::DEFAULT_KEY);
            }
            $this->fileSystem->remove($fileBasePath);
            return new JsonResponse($updatedRecord ?? [], $existingRecord ? Response::HTTP_OK : Response::HTTP_NOT_FOUND);
        } catch (\Throwable $th) {
            $this->fileSystem->remove($fileBasePath);
            throw $th;
        }
    }

    public function deleteAction(Request $request, $uuid)
    {
        if (!$this->fsrVoter->isGranted("delete.solutionpacks")) {
            throw new AccessDeniedException();
        }

        $repository = $this->entityManager->getRepository(SolutionPack::class);
        $solutionPack = $repository->findOneBy(array("uuid" => $uuid));
        $serializer = $this->containers->get('serializer');
        $context['relationships'] = true;
        $oldData = $serializer->normalize($solutionPack, 'jsonld', $context);
        $this->utilityService->removeFileObj($solutionPack, true, true, true);
        $objectData = $request ? json_decode($request->getContent()) : null;
        if ($solutionPack && $objectData && property_exists($objectData, 'nonLocalNonRepoSpClean') && $objectData->nonLocalNonRepoSpClean) {
            $this->entityManager->remove($solutionPack);
            $this->entityManager->flush();
        } elseif ($solutionPack && !$solutionPack->getLocal()) {
            $solutionPack->setDraft(false);
            $solutionPack->setDevelopment(false);
            $solutionPack->setInstalled(false);
            $solutionPack->setStatus(null);
            $solutionPack->setTemplate(null);
            $solutionPack->setImportJob(null);
            $solutionPack->setFile(null);
            $solutionPack->setExportJob(null);
            $latestAvailableVersion = $solutionPack->getLatestAvailableVersion();
            if ($latestAvailableVersion) {
                $solutionPack->setVersion($latestAvailableVersion);
                $solutionPack->setLatestAvailableVersion(null);
            }
            $this->entityManager->persist($solutionPack);
            $this->entityManager->flush();
        } else {
            if (!$this->entityManager->isOpen()) {
                $this->containers->get('doctrine')->getManagerForClass(SolutionPack::class);
            }
            $this->entityManager->remove($solutionPack);
            $this->entityManager->flush();
        }
        $body = $this->utilityService->prepareChangeData($oldData, [], $oldData['uuid'], "Delete");
        $this->sendData([$body], MqMessagebroadcastSubscriber::DEFAULT_KEY);
        return new JsonResponse(Response::HTTP_NOT_FOUND);
    }

    public function syncAction(Request $request)
    {

        if (!$this->fsrVoter->isGranted("update.solutionpacks")) {
            throw new AccessDeniedException();
        }
        $force = $request->get('$force', false);
        if ($force) {
            $command = '/usr/bin/php /opt/cyops-api/bin/console app:contenthub:sync --force';
        } else {
            $command = '/usr/bin/php /opt/cyops-api/bin/console app:contenthub:sync';
        }
        chdir($this->containers->getParameter('kernel.project_dir'));
        exec(sprintf('bash -c "exec nohup setsid %s > /var/log/cyops/cyops-api/last_contenthubsync.log 2>&1 &"', $command));

        return new JsonResponse("Solution pack list is synced with repo server successfully");
    }

    public function sendData(array $data, $key = self::DATA_ROUTING_KEY)
    {
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->setContentType('application/json');
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->publish(json_encode($data), $key);
    }

    protected function updateMarketPlaceInDB($marketPlaceRecord, $updatedInfoContent = null)
    {
        try {
            if ($updatedInfoContent) {
                $marketPlaceData = is_array($updatedInfoContent) ? (object)$updatedInfoContent : $updatedInfoContent;
                $marketPlaceRecord->setVersion($marketPlaceData->version);
                if (isset($marketPlaceData->buildNumber)) {
                    $marketPlaceRecord->setBuildNumber($marketPlaceData->buildNumber);
                }
                $marketPlaceRecord->setDraft(false);
                $marketPlaceRecord->setInstalled(false);
                $marketPlaceRecord->setInfoContent($marketPlaceData->infoContent);
                $marketPlaceRecord->setDraft(false);
                $marketPlaceRecord->setPublisher($marketPlaceData->publisher);
                // setCertified is not called since custom upload should not be certified .
                if ($marketPlaceRecord->getlocal()) {
                    $marketPlaceRecord->setInfoPath($marketPlaceData->infoPath);
                    $categories = $this->utilityService->prepareCategoryData($marketPlaceData->category);
                    if (!empty($categories)) {
                        foreach ($categories as $category) {
                            $picklistObject = $this->iriConverter->getResourceFromIri($category, ['fetch_data' => false]);
                            $marketPlaceRecord->addCategory($picklistObject);
                        }
                    }
                }
                if (!empty($marketPlaceData->iconLarge)) {
                    $marketPlaceRecord->setIconLarge($marketPlaceData->iconLarge);
                }
                $marketPlaceRecord->setDescription($marketPlaceData->description);
                $marketPlaceRecord->setLabel($marketPlaceData->label);
                if (isset($marketPlaceData->dependencies)) {
                    $marketPlaceRecord->setDependencies($marketPlaceData->dependencies);
                }
                $timestamp = new \DateTime();
                if (isset($marketPlaceData->publishedDate)) {
                    $timestamp->setTimestamp($marketPlaceData->publishedDate);
                }
                $marketPlaceRecord->setPublishedDate($timestamp);
                if (isset($marketPlaceData->prerequisite)) {
                    $marketPlaceRecord->setPrerequisite($marketPlaceData->prerequisite);
                }
                if ((isset($marketPlaceData->sourceControlStats) && $marketPlaceData->sourceControlStats) || (isset($marketPlaceData->scm) && $marketPlaceData->scm)) {
                    $marketPlaceRecord->setSourceControlStats($marketPlaceData->sourceControlStats ?? $marketPlaceData->scm);
                }
                $marketPlaceRecord->setStatus("Installing");
                $marketPlaceRecord->setFeaturedTags(isset($marketPlaceData->featuredTags) ? $marketPlaceData->featuredTags : []);
                $marketPlaceRecord->setFeatured(isset($marketPlaceData->{'featured'}) ? $marketPlaceData->featured : false);
                if (isset($marketPlaceData->recordTags)) {
                    $tags = $this->utilityService->importTags($marketPlaceData->recordTags);
                }
                foreach ($marketPlaceRecord->getRecordTags() as $tag) {
                    $marketPlaceRecord->removeRecordTag($tag);
                }
                if (isset($tags)) {
                    foreach ($tags as $tag) {
                        $marketPlaceRecord->addRecordTag($this->iriConverter->getResourceFromIri('/api/3/tags/' . $tag, ['resource_class' => Tag::class, 'fetch_data' => false]));
                    }
                }
            } else {
                $marketPlaceRecord->setDraft(false);
                $marketPlaceRecord->setStatus("Installing");
            }
            $this->entityManager->persist($marketPlaceRecord);
            $this->entityManager->flush();

            $serializer = $this->containers->get('serializer');
            $context['relationships'] = true;
            return $serializer->normalize($marketPlaceRecord, 'jsonld', $context);
        } catch (UniqueConstraintViolationException $e) {
            $this->logger->error("updateMarketPlaceInDB UniqueConstraintViolationException : " . $e->getMessage());
            return false;
        } catch (BadRequestHttpException $e) {
            $this->logger->error("updateMarketPlaceInDB BadRequestHttpException : " . $e->getMessage());
            return false;
        }
    }

    protected function updateSPImage($marketplaceData, $tmpFilePath)
    {
        $imageData = null;
        if (is_array($marketplaceData) && array_key_exists("iconLarge", $marketplaceData)) {
            $imageData = $marketplaceData['iconLarge'];
        }
        if ($imageData && $marketplaceData['type'] == strtolower(self::SOLUTION_PACK)) {
            $isImageDataBaseEncoded = preg_match('#^data:image/\w+;base64,#i', $imageData);
            if (!$isImageDataBaseEncoded) { // To check if any of the old SP have image data, in that case we just insert it in db as it is
                $imagePath = $tmpFilePath . 'images/' . $imageData;
                if (file_exists($imagePath)) {
                    $imagePath = realpath($imagePath);
                    if (strpos(realpath(dirname($imagePath)), AppConstants::TMP_SAFE_PATH) !== 0) {
                        $this->logger->warning(ErrorConstants::INVALID_FILE_NAME);
                        return null;
                    }
                    $imageDataString = file_get_contents($imagePath);
                    $imageData = "data:image/jpeg;base64," . base64_encode($imageDataString);
                }
            }
        }

        return $imageData;
    }

    protected function saveMarketPlaceInDB($marketPlaceData, $returnEntity = false)
    {
        try {
            $marketPlaceData = is_array($marketPlaceData) ? (object)$marketPlaceData : $marketPlaceData;
            $solutionPack = new SolutionPack();
            $solutionPack->setName($marketPlaceData->name);
            $solutionPack->setVersion($marketPlaceData->version);
            if (property_exists($solutionPack, 'setBuildNumber') && property_exists($marketPlaceData, 'buildNumber')) {
                $solutionPack->setBuildNumber($marketPlaceData->buildNumber);
            }
            $solutionPack->setDraft(false);
            $solutionPack->setInstalled(false);
            $solutionPack->setType($marketPlaceData->type ? strtolower($marketPlaceData->type) : strtolower(self::SOLUTION_PACK));
            $solutionPack->setInfoContent($marketPlaceData->infoContent);
            if (property_exists($marketPlaceData, "importJob")) {
                $solutionPack->setImportJob($marketPlaceData->importJob);
            }
            $solutionPack->setPublisher($marketPlaceData->publisher);
            // setCertified is not called since custom upload should not be certified .
            if (property_exists($solutionPack, 'setInfoPath') && property_exists($marketPlaceData, 'infoPath')) {
                $solutionPack->setInfoPath($marketPlaceData->infoPath);
            }
            $solutionPack->setIconLarge($marketPlaceData->iconLarge);
            $solutionPack->setDescription($marketPlaceData->description);
            $marketPlaceData->label = $marketPlaceData->label ?? $marketPlaceData->display;
            $solutionPack->setLabel($marketPlaceData->label);
            if (property_exists($marketPlaceData, "dependencies")) {
                $solutionPack->setDependencies($marketPlaceData->dependencies);
            }
            $solutionPack->setPrerequisite($marketPlaceData->prerequisite ?? null);
            if (property_exists($solutionPack, 'setFeaturedTags') && property_exists($marketPlaceData, 'featuredTags')) {
                $solutionPack->setFeaturedTags($marketPlaceData->featuredTags);
            }
            if (property_exists($marketPlaceData, "local")) {
                $solutionPack->setLocal($marketPlaceData->local);
            }
            $solutionPack->setCertified($marketPlaceData->certified);
            $solutionPack->setFeatured(isset($marketPlaceData->{'featured'}) ? $marketPlaceData->featured : false);
            if (!empty($marketPlaceData->category)) {
                $categoryValues = $this->utilityService->prepareCategoryData($marketPlaceData->category);
                foreach ($categoryValues as $picklist_iri) {
                    $picklistObject = $this->iriConverter->getResourceFromIri($picklist_iri, ['fetch_data' => false]);
                    $solutionPack->addCategory($picklistObject);
                }
            }
            if (property_exists($marketPlaceData, 'recordTags')) {
                $tags = $this->utilityService->importTags($marketPlaceData->recordTags);
            }
            foreach ($solutionPack->getRecordTags() as $tag) {
                $solutionPack->removeRecordTag($tag);
            }
            if (isset($tags)) {
                foreach ($tags as $tag) {
                    $solutionPack->addRecordTag($this->iriConverter->getResourceFromIri('/api/3/tags/' . $tag, ['resource_class' => Tag::class, 'fetch_data' => false]));
                }
            }

            $this->entityManager->persist($solutionPack);
            $this->entityManager->flush();
            if ($returnEntity) {
                return $solutionPack;
            }
            $serializer = $this->container->get('serializer');
            $context['relationships'] = true;
            return $serializer->normalize($solutionPack, 'jsonld', $context);
        } catch (UniqueConstraintViolationException $e) {
            return new JsonResponse($e->getMessage(), Response::HTTP_CONFLICT);
        } catch (BadRequestHttpException $e) {
            return new JsonResponse($e->getMessage(), Response::HTTP_BAD_REQUEST);
        }
    }

    protected function dumpFileToTemp($request, $type = self::SOLUTION_PACK)
    {
        /** @var UploadedFile $upload */
        $upload = $request->files->get('file');
        $fileName = $upload->getClientOriginalName();
        $fileExt = $upload->getClientOriginalExtension();
        $fileNameExplode = explode("." . $fileExt, $fileName)[0];
        $openFile = $upload->openFile();
        $readFile = $openFile->fread($openFile->getSize());
        $this->fileSystem->mkdir(self::TMP_PATH);
        $tempPath = self::TMP_PATH . $fileNameExplode . '/';
        $archiveFolder = $this->utilityService->unzipFile($readFile, $fileName, $tempPath);
        if ($type == 'widget' || $type == 'connector') {
            $sDir = scandir($tempPath);
            foreach ($sDir as $value) {
                if (!in_array($value, array(".", "..")) && !str_starts_with($value, "__")) {
                    return [$tempPath, $tempPath . $value, $value];
                }
            }
        }
        $sDir = scandir($archiveFolder);
        foreach ($sDir as $value) {
            if (!in_array($value, array(".", "..")) && !str_starts_with($value, "__") && is_dir($tempPath . $fileNameExplode)) {
                return [$tempPath, $tempPath . $fileNameExplode . "/", $fileName];
            }
        }
        foreach ($sDir as $value) {
            if (!in_array($value, array(".", "..")) && !str_starts_with($value, "__") && is_dir($tempPath  . $value)) {
                return [$tempPath, $tempPath . $value . "/", $fileName];
            }
        }
    }

    private function checkExistingPermission($name)
    {
        $createPermissionString = sprintf("create.%s", $name);
        $updatePermissionString = sprintf("update.%s", $name);
        if ($this->fsrVoter->isGranted($createPermissionString) && $this->fsrVoter->isGranted($updatePermissionString)) {
            return true;
        }
        return false;
    }

    private function validateContentsRBAC($contents, $type)
    {
        $role_map = $this->containers->getParameter('role_map');
        $needPermissionsFor = [];
        if (isset($contents)) {
            foreach ($contents as $key => $value) {
                if (is_array($role_map) && array_key_exists($key, $role_map) && $role_map[$key] && !$this->checkExistingPermission($role_map[$key]) && !in_array($role_map[$key], $needPermissionsFor)) {
                    if ($role_map[$key] == 'workflows') {
                        array_push($needPermissionsFor, 'Playbooks');
                    } else {
                        array_push($needPermissionsFor, ucwords($role_map[$key]));
                    }
                }
            }
        }
        $requiredSecurity = false;
        if (!$this->fsrVoter->isGranted("read.security")) {
            $requiredSecurity = true;
        }
        $type = ($type == AppConstants::MULTICONTENT_TYPE) ? AppConstants::SOLUTIONPACK_TYPE : $type;
        if (!empty($needPermissionsFor)) {
            $permissionsFor = array_unique($needPermissionsFor);
            $errorMessage = sprintf("This %s cannot be installed because you do not have required permissions. You need 'Read', 'Create' and 'Update' permissions for the %s module(s)", ucwords($type), implode(", ", $permissionsFor));
            $errorMessage = in_array('Security', $permissionsFor) ? $errorMessage . "." : $errorMessage . " and 'Read' for the Security module.";
            throw new BadRequestHttpException($errorMessage);
        } elseif ($requiredSecurity) {
            $errorMessage = sprintf("This %s cannot be installed because you do not have required permissions. You need 'Read' permissions for the Security module.", ucwords($type));
            throw new BadRequestHttpException($errorMessage);
        }
    }

    private function get_latest_compatible_version(mixed $compatibility_versions): string
    {
        $latest_compatible_version = "";
        if (is_array($compatibility_versions)) {
            foreach ($compatibility_versions as $compatible_version) {
                $latest_compatible_version = str_replace('.', '', $latest_compatible_version) <= str_replace('.', '', $compatible_version) ? $compatible_version : $latest_compatible_version;
            }
        } else {
            $latest_compatible_version = $compatibility_versions;
        }
        return $latest_compatible_version;
    }

    private function get_compatible_version_data(array $infoContent): mixed
    {
        if ($infoContent["type"] == "widget") {
            $compatible_version_data = array_key_exists(AppConstants::COMPATIBILITY, $infoContent["metadata"]) ? $infoContent["metadata"][AppConstants::COMPATIBILITY] : [];
        } elseif ($infoContent["type"] == "solutionpack") {
            $compatible_version_data = array_key_exists(AppConstants::FSR_MIN_COMPATIBILITY, $infoContent) ? $infoContent[AppConstants::FSR_MIN_COMPATIBILITY] : "";
        } else {
            $compatible_version_data = [];
        }
        return $compatible_version_data;
    }

    public function validateInstallation(string $infoPath, bool $replace = false)
    {
        $infoContent = json_decode(file_get_contents($infoPath . 'info.json'), true);
        if (!file_exists($infoPath . 'info.json')) {
            throw new BadRequestHttpException("Required metadata info.json is not present in the installation file.");
        }
        $compatibility_version_data = $this->get_compatible_version_data($infoContent);
        $compatibility_version = $this->get_latest_compatible_version($compatibility_version_data);
        $is_compatible = $compatibility_version ? $this->checkCompatibilityVersion($compatibility_version) : true;
        if (array_key_exists(AppConstants::FSR_MIN_COMPATIBILITY, $infoContent) && !$is_compatible) {
            throw new BadRequestHttpException('Solution pack is not compatible with the current platform version.');
        } elseif (array_key_exists(AppConstants::COMPATIBILITY, $infoContent["metadata"] ?? []) && !$is_compatible) {
            throw new BadRequestHttpException('Widget is not compatible with the current platform version.');
        }

        if ($replace == false  && $this->checkInstalledRecord($infoContent['name'], $infoContent['version'])) {
            return [[], false];
        }
        $installSequence = [];
        if (isset($infoContent['dependencies'])) {
            $dependencyMatrix = $this->getDependencyList($infoContent['name'], $infoContent['dependencies'], 0);
            $installSequence = $this->validateDependencyList($dependencyMatrix);
        }
        return [$installSequence, $infoContent];
    }

    protected function checkInstalledRecord($name, $version)
    {
        $repository = $this->entityManager->getRepository(SolutionPack::class);
        $existing = $repository->findOneBy(array("name" => $name, "version" => $version, "installed" => true));
        return $existing ?  $existing : false;
    }

    protected function getExistingRecord($name, $version)
    {
        $repository = $this->entityManager->getRepository(SolutionPack::class);
        $existing = $repository->findOneBy(array("name" => $name, "version" => $version));
        return $existing ?  $existing : false;
    }

    protected function getSolutionPackRecordLatestVersion($name, $dependencies)
    {
        $repository = $this->entityManager->getRepository(SolutionPack::class);
        $allRecords = $repository->findBy(array("name" => $name));
        $latestVersionRecord = new SolutionPack();
        $latestVersionRecord->setVersion("0.0.0");
        $latestVersionRecord->setDependencies($dependencies);
        foreach ($allRecords as $record) {
            $oldRecord = str_replace('.', '', $latestVersionRecord->getVersion());
            $newRecordVersion =  str_replace('.', '', $record->getVersion());
            if ($newRecordVersion > $oldRecord) {
                $latestVersionRecord = $record;
            }
        }

        $serializer = $this->containers->get('serializer');
        return $serializer->normalize($latestVersionRecord, 'jsonld');
    }

    protected function checkCompatibilityVersion(string $fsrMinCompatibilityVersion)
    {
        return str_replace('.', '', $fsrMinCompatibilityVersion) <= str_replace('.', '', $this->containers->getParameter('product_version')) ? true : false;
    }

    protected function getDependencyList($name, $dependencies = [], $depth = 0)
    {
        $dependency = [];
        if ($depth > self::INSTALL_DEPTH) {
            throw new HttpException(Response::HTTP_BAD_REQUEST, "Exhausted the maximum number of dependencies that can be auto-installed. Reduce the number of dependencies and retry.");
        }
        $mainRecord = $this->getSolutionPackRecordLatestVersion($name, $dependencies);
        foreach ($mainRecord['dependencies'] as $value) {
            $dependency[$name][] = $value['name'];
            $record = $this->utilityService->getRecord($value['name'], $value['version'] ?? null);
            //handle the non existence dependency records. custom local dependency not installed
            if ($record == false || empty($record->getDependencies())) {
                $dependency[$value['name']][] = "";
                continue;
            }
            foreach ($record->getDependencies() as $item) {
                $dependency[$value['name']][] = $item['name'];
                $dependencyList = $this->getDependencyList($item['name'], [], $depth + 1);
                if (empty($dependencyList)) {
                    $tempArray[$item['name']][] = "";
                } else {
                    $tempArray = $dependencyList;
                }
                $dependency = array_merge($dependency, $tempArray);
            }
        }
        return $dependency; // fortisime['dependencies']  =["mitre","",],
        //mitre['dependencies']  =["","",]
    }

    protected function validateDependencyList($dependencyMatrix)
    {
        $nodes = [];
        $graph = new DependencyGraph();
        foreach ($dependencyMatrix as $key => $item) {
            if (!array_key_exists($key, $nodes)) {
                $nodes[$key] = new DependencyNode($key);
            }
            foreach ($item as $value) {
                if ($value != "") {
                    if (!array_key_exists($value, $nodes)) {
                        $nodes[$value] = new DependencyNode($value);
                    }
                    $graph->addDependency($nodes[$key], $nodes[$value]);
                }
            }
        }
        return $graph->resolve(); // returns [D, E, C, B, A]
        //handle the cyclic dependency this will throw an exception .
    }
    protected function saveFileFromRequest($request)
    {
        $fileUuid = Uuid::uuid4()->toString();
        $teamsRepo = $this->entityManager->getRepository(Team::class);
        $teams = $teamsRepo->findAll();
        $pgFile = new PgFile();
        /** @var UploadedFile $upload */
        $upload = $request->files->get('file');
        $strm = fopen($upload->getPathname(), 'rb');
        $pgFile->setFile(base64_encode(stream_get_contents($strm)));
        $pgFile->setUuid(Uuid::uuid4()->toString());
        $this->entityManager->persist($pgFile);
        $this->entityManager->flush();

        $file = new File();
        $file->setFilename($upload->getClientOriginalName());
        $file->setMimeType($upload->getClientMimeType());
        $file->setSize($upload->getSize());
        $timestamp = new \DateTime('NOW', new \DateTimeZone('UTC'));
        $file->setUploadDate($timestamp);
        $file->setFile($pgFile->getUuid());
        $file->setUuid($fileUuid);
        $file->setId($fileUuid);
        foreach ($teams as $team) {
            $file->addOwner($team);
        }
        $this->entityManager->persist($file);
        $this->entityManager->flush();
        return $file->getUuid();
    }

    public function tagsAction(Request $request, $moduleType)
    {

        if (!$this->fsrVoter->isGranted("read.application")) {
            throw new AccessDeniedException();
        }
        $inflector = InflectorFactory::create()->build();
        $moduleSingularizeName = strtolower($inflector->classify($inflector->singularize($moduleType)));
        $tableName = $moduleSingularizeName . '_tag';
        $finalQuery = "select tag_uuid from " . $tableName;
        $allTags = $this->entityManager->getConnection()->fetchAllAssociative($finalQuery);
        $data = ['@type' => 'hydra:Collection', 'hydra:member' => $allTags, 'hydra:totalItems' => sizeof($allTags)];
        return new JsonResponse($data);
    }
}
