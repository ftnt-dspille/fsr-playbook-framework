<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Psr\Log\LoggerInterface;
use InvalidArgumentException;
use App\Service\MetadataHelper;
use Doctrine\Inflector\InflectorFactory;
use App\Entity\ModelMetadata\ModelMetadata;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\ModelMetadata\StagingModelMetadata;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

abstract class BaseController extends AbstractController
{
    protected $inflector;

    public const NORMALIZER_METHOD = 'jsonld';
    public const SELECTIVE_FIELDS = '__selectFields';
    public const IGNORE_FIELD_KEY = '__ignoreFields';
    public const API_PREFIX = '/api/3/';
    public const RESOURCE_SECURITY = 'security';

    public function __construct(
        protected ResourceClassResolverInterface $resourceClassResolver,
        protected ContainerInterface $containers,
        protected TagAwareCacheInterface $cache,
        protected MetadataHelper $metadataHelper,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->inflector = InflectorFactory::create()->build();
        $this->resourceClassResolver = $resourceClassResolver;
        $this->containers = $containers;
        $this->cache = $cache;
        $this->metadataHelper = $metadataHelper;
        $this->serializer = $serializer;
    }

    /**
     * @param string $type
     * @return StagingModelMetadata|null
     */
    public function getClassNameByType($type)
    {
        //TODO: get this from metadata helper
        /** @var ManagerRegistry $managerRegistry */
        $managerRegistry = $this->container->get('doctrine');
        $queryManager = $managerRegistry->getManagerForClass(ModelMetadata::class);
        $queryRepository = $queryManager->getRepository(ModelMetadata::class);
        try {
            return $queryRepository->findOneBy(array('type' => $type));
        } catch (InvalidArgumentException | \Exception $e) {
            $this->logger->error($e->getMessage());
            throw new NotFoundHttpException('No module for type found');
        }
    }

    public function getResourceFromClassName($resourceShortName)
    {
        return $this->metadataHelper->getResourceFromClassName($resourceShortName);
    }

    public function getSuccessResponse($data, $resource = null, $status = Response::HTTP_OK)
    {
        $normalized_data = $this->serializer->normalize(
            $data,
            self::NORMALIZER_METHOD,
            ['resource_class' => $resource]
        );
        return new JsonResponse(
            $normalized_data,
            $status
        );
    }
}
