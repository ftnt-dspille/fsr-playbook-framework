<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Constants\AppConstants;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class SystemEntitiesMetadataController extends AbstractController
{
    /**
     * @Route("/api/system/fixtures/{moduletype?}", name="api_system_entities_fixtures", methods={"GET"})
     */
    public function getSystemEntitesFixtures(Request $request, $moduletype = null)
    {
        $fixturesData = [];
        $fixtureFiles = [];
        if (file_exists(AppConstants::STATIC_FILE_DIR)) {
            $fixtureFiles = array_diff(scandir(AppConstants::STATIC_FILE_DIR), array_merge(['.', '..'], AppConstants::IGNORE_FIXTURE));
        }
        foreach ($fixtureFiles as $fixtureFile) {
            $fileData = file_get_contents(AppConstants::STATIC_FILE_DIR . $fixtureFile);
            $data = json_decode($fileData, true);
            if ($data) {
                $fixturesData = array_merge($fixturesData, $data);
            }
        }
        $combinedFixturesData = json_decode(json_encode($fixturesData, JSON_PRETTY_PRINT));
        if ($moduletype) {
            return new JsonResponse($combinedFixturesData->{$moduletype}, Response::HTTP_OK);
        }
        $fixtures = [];
        foreach ($combinedFixturesData as $fixture) {
            $fixtures[] = $fixture;
        }
        return new JsonResponse($fixtures);
    }
}
