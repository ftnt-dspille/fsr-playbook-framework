<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Entity\Actors\Actor;
use Doctrine\ORM\EntityManager;
use App\Security\Voter\FsrVoter;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use ApiPlatform\Core\Api\IriConverterInterface;
use App\Providers\PermissionsDictionaryBuilder;
use App\Providers\PermissionsDictionaryProvider;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class PermissionsController extends AbstractController
{

    /** @var PermissionsDictionaryProvider */
    protected $permissionsDictionaryProvider;

    /** @var TokenStorageInterface */
    protected $tokenStorage;

    protected $fsrVoter;

    protected $entityManager;

    /**
     * PermissionResolver constructor.
     * @param PermissionsDictionaryProvider $permissionsDictionaryProvider
     */
    public function __construct(
        PermissionsDictionaryProvider $permissionsDictionaryProvider,
        TokenStorageInterface $tokenStorage,
        FsrVoter $fsrVoter,
        EntityManagerInterface $entityManager
        )
    {
        $this->permissionsDictionaryProvider = $permissionsDictionaryProvider;
        $this->tokenStorage = $tokenStorage;
        $this->fsrVoter = $fsrVoter;
        $this->entityManager = $entityManager;
    }

    public function listAction()
    {
        $actor = $this->tokenStorage->getToken()->getUser();
        $permissionsDictionary = $this->permissionsDictionaryProvider->getDataForActor($actor);

        return new JsonResponse($permissionsDictionary);
    }

    public function aggregatedActorsPermissionAction($uuid)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'security');
        $actorRepository = $this->entityManager->getRepository(Actor::class);
        $actorObj = $actorRepository->findOneBy(['uuid' => $uuid]);
        if (!empty($actorObj)) {
            $permissionsDictionary = $this->permissionsDictionaryProvider->getDataForActor($actorObj);
            return new JsonResponse($permissionsDictionary);
        }
        return new JsonResponse(array('message' => 'No matching record found.'), Response::HTTP_NOT_FOUND);
    }

    /**
     * @param string $moduleName
     * @param string $action
     * @return JsonResponse
     */
    public function getAction($module, $action)
    {

        if (!$this->fsrVoter->isGranted($this->buildPermission($module, $action))) {
            return new JsonResponse(false);
        }
        return new JsonResponse(true);
    }

    /**
     * @param string $moduleName
     * @param string $action
     * @return string
     */
    private function buildPermission($moduleName, $action)
    {
        return sprintf('%s_%s', $action, $moduleName,);
    }
}
