<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Utility\Resolver;
use App\Entity\Actors\Actor;
use Psr\Log\LoggerInterface;
use App\Entity\Custom\Person;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use Symfony\Component\Yaml\Yaml;
use App\Service\SamlActorService;
use App\Controller\BaseController;
use App\Entity\Core\EmailTemplate;
use App\Entity\Settings\SystemSettings;
use Doctrine\ORM\EntityManagerInterface;
use GuzzleHttp\Psr7\Request as GuzzleRequest;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;


class PublicActionController extends BaseController
{
    protected $samlActorService;
    protected $entityManager;
    protected $fsrVoter;

    public function __construct(
        protected ContainerInterface $containers,
        SamlActorService $samlActorService,
        ResourceClassResolverInterface $resourceClassResolver,
        TagAwareCacheInterface $cache,
        MetadataHelper $metadataHelper,
        EntityManagerInterface $entityManager,
        FsrVoter $fsrVoter,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->samlActorService = $samlActorService;
        $this->entityManager = $entityManager;
        $this->fsrVoter = $fsrVoter;
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    /**
     * @return integrationsClient
     */
    public function getIntegrationClient()
    {
        return $this->containers->get("app.proxy.client.integrations");
    }

    /**
     * @return DasClient
     */
    public function getDasClient()
    {
        return $this->containers->get("app.proxy.client.das");
    }

    /**
     * @return ProxyClient
     */
    public function getProxyClient()
    {
        return $this->containers->get("app.proxy.client.workflow");
    }

    public function sendMail($templateId, $dataToReplace, $mailDetails, $integrationClient, $defaultMessage)
    {
        $entityRepository = $this->entityManager->getRepository(EmailTemplate::class);
        $criteria = array('uuid' => $templateId);
        $item = $entityRepository->find($criteria);
        if ($item == null) {
            $email_options = Yaml::parse(file_get_contents('/opt/cyops/configs/cyops-api/mailtemplate.yml'));
            $item = $email_options[$defaultMessage];
        } else {
            $context['ignore_authorization'] = true;
            $context['ignore_field_authorization'] = true;
            $item = $this->serializer->normalize($item, 'jsonld', $context);
        }

        $headers = array(
            "Content-type" => "application/json",
        );
        if (strpos($item['content'], 'https://{{@Server_fqhn}}')) {
            $item['content'] = str_replace('https://{{@Server_fqhn}}', '{{@Server_fqhn}}', $item['content']);
        }
        if (strpos($item['content'], 'https://{{@cyops_hostname}}')) {
            $item['content'] = str_replace('https://{{@cyops_hostname}}', '{{@cyops_hostname}}', $item['content']);
        }
        foreach ($dataToReplace as $key => $value) {
            $item['content'] = str_replace($key, $value, $item['content']);
        }
        $smtpObject = '{
                            "connector": "smtp",
                            "operation": "send_richtext_email",
                            "params": {
                                "ccc": "",
                                "bcc": "",
                                "content_type":"text/html"
                            }
                        }';
        $jsonDecodedSmtp = json_decode($smtpObject, true);
        $jsonDecodedSmtp['params']['subject'] = $item['subject'];
        $jsonDecodedSmtp['params']['content'] = $item['content'];
        $jsonDecodedSmtp['params']['to'] = $mailDetails;
        $smtpUri = $this->containers->getParameter('integrations.uri');
        $smtpUri = $smtpUri . '/execute/?format=json';
        $smtpRequest = new GuzzleRequest('post', $smtpUri, $headers, json_encode($jsonDecodedSmtp));
        try {
            $integrationClient->send($smtpRequest);
        } catch (BadRequestHttpException | \Exception $exception) {
            $this->logger->error($exception->getMessage());
            $errVar = json_decode($exception->getResponse()->getBody()->read(2048), true);
            $this->logger->error($errVar);
            return $errVar;
        }
        return true;
    }

    public function routeForgotPasswordAction(Request $request)
    {
        $objectData = json_decode($request->getContent(), true);
        $token = $objectData['captchResponse'];
        $success = $this->verifyReCaptcha($token);
        if (!$success) {
            return new Response('Invalid Captcha, please verify', Response::HTTP_FORBIDDEN);
        }
        $loginId = $objectData['loginId'];
        $userId = $this->getUserId($loginId);

        if (empty($userId)) {
            return new JsonResponse(["message" => "A link to reset your password will be sent to your official email address subject to the validity of the provided user ID."], Response::HTTP_OK);
        }

        $email = $this->getEmail($userId);
        $data = array(
            'uuid' => $userId,
            'newUser' => false,
            'email' => $email,
        );

        $dasClient = $this->getDasClient();
        $headers = array(
            "Content-type" => "application/json",
        );

        $dasUri = $this->containers->getParameter('das.uri');
        $keyFile = file_get_contents('/opt/cyops-api/src/keys/daspublic.key', true);
        $idKey = base64_encode($keyFile);
        $data['idKey'] = $idKey;
        $dasRequests = new GuzzleRequest('post', $dasUri . '/token?uuid=' . $data['uuid'], $headers, json_encode($data));
        try {
            $dasResponse = $dasClient->send($dasRequests);
            $dasResponseData = $dasResponse->getBody()->getContents();
            $jsonDecodeResponse = json_decode($dasResponseData, true);
            $resCode = $dasResponse->getStatusCode();
        } catch (BadRequestHttpException | \Exception $error) {
            $this->logger->error($error->getMessage());
            $errVar = json_decode($error->getResponse()->getBody()->read(2048), true);
            $errMsg['message'] = $errVar['Error'];
            $errCode = $error->getCode();
            return new JsonResponse($errMsg, $errCode);
        }

        if ($resCode < 300) {
            $managerRegistry = $this->containers->get('doctrine');
            $manager = $managerRegistry->getManagerForClass(SystemSettings::class);
            $systemRepository = $manager->getRepository(SystemSettings::class);
            $systemSetting = $systemRepository->findAll();
            $global_value = $systemSetting[0]->getGlobalValues();
            $system_host = isset($global_value['hostname']) ? $global_value['hostname'] : getenv('HOSTNAME');

            $integrationClient = $this->getIntegrationClient();
            $dataToReplace = [];
            $dataToReplace['{{vars.token}}'] = $jsonDecodeResponse['token'];

            $wfClient = $this->getProxyClient();
            $headers = array(
                "Content-type" => "application/json",
            );
            $workflowUri = $this->containers->getParameter('workflow.uri');
            $workflowRequests = new GuzzleRequest('get', $workflowUri . '/api/dynamic-variable/?format=json&name=Server_fqhn', $headers);
            try {
                $workflowResponse = $wfClient->send($workflowRequests);
                $workflowResponseData = json_decode($workflowResponse->getBody()->getContents(), true);
                if ($workflowResponseData["hydra:totalItems"] > 0) {
                    $system_host = $workflowResponseData["hydra:member"][0]["value"];
                }
            } catch (BadRequestHttpException | \Exception $error) {
                $this->logger->error($error->getMessage());
            }

            $dataToReplace['{{vars.request.baseUri}}'] = $request->getScheme() . "://" . $system_host;
            $dataToReplace['{{@Server_fqhn}}'] = $request->getScheme() . "://" . $system_host;
            $dataToReplace['{{@cyops_hostname}}'] = $request->getScheme() . "://" . $system_host;
            $dataToReplace['{{vars.userId}}'] = $loginId;
            $defaultMessage = 'forgotpassword';
            $mailResponse = $this->sendMail('b9265a6e-7c0d-420a-a8e9-e77f01baf7cb', $dataToReplace, $data['email'], $integrationClient, $defaultMessage);
            if (!(is_array($mailResponse)) && $mailResponse === true) {
                $mailResponse = "Reset token sent to user";
            }
            return new JsonResponse(["message" => "A link to reset your password will be sent to your official email address subject to the validity of the provided user ID."], Response::HTTP_OK);
        }
    }

    public function routeLicenseAction(Request $request)
    {
        $objectData = json_decode($request->getContent(), true);
        $objectData['type'] = 'unauthenticated';
        $objectData['action'] = $objectData['action'] ?? "deploy_license";
        $dasClient = $this->getDasClient();
        $headers = array(
            "Content-type" => "application/json",
            "X-REMOTE_ADDR" => $_SERVER['REMOTE_ADDR'],
        );

        $dasUri = $this->containers->getParameter('das.uri');
        $dasRequests = new GuzzleRequest('post', $dasUri . '/license', $headers, json_encode($objectData));
        try {
            $dasResponse = $dasClient->send($dasRequests);
            $dasResponseData = $dasResponse->getBody()->getContents();
            $jsonDecodeResponse = json_decode($dasResponseData, true);
            $resCode = $dasResponse->getStatusCode();
            return new JsonResponse($jsonDecodeResponse, $resCode);
        } catch (BadRequestHttpException | \Exception $error) {
            $this->logger->error($error->getMessage());
            $errVar = json_decode($error->getResponse()->getBody()->read(2048), true);
            $errMsg['message'] = $errVar['Error'];
            $errCode = $error->getCode();
            return new JsonResponse($errMsg, $errCode);
        }
    }

    /**
     * @param $userId
     * @return string
     */
    private function getEmail($userId)
    {
        $actor = $this->samlActorService->getActor($userId);
        return $actor->getEmail();
    }

    /**
     * @param $token
     * @return bool
     */
    private function verifyReCaptcha($token)
    {
        $googleAPI = $this->containers->getParameter('googleAPI');
        $googleSecrete = $this->containers->getParameter('secretKey');

        $post_data = array(
            'form_params' => [
                'secret' => $googleSecrete,
                'response' => $token
            ]
        );

        $client = new \GuzzleHttp\Client();
        $responseObject = $client->request('POST', $googleAPI, $post_data);
        if ($responseObject->getStatusCode() >= 200 && $responseObject->getStatusCode() < 300) {
            $result = json_decode($responseObject->getBody());
            return $result->success;
        } else {
            return false;
        }
    }

    /**
     * @param $routeIdentifier
     * @return array
     */
    private function findHandlerMapForRoute($routeIdentifier)
    {
        $handlerMap = $this->containers->getParameter('app.proxy.handler.map');

        if (!array_key_exists($routeIdentifier, $handlerMap)) {
            throw new NotFoundHttpException();
        }
        return $handlerMap;
    }

    /**
     * @param $routeIdentifier
     * @return ProxyClient
     */
    public function findHandlerForRoute($routeIdentifier)
    {
        $handler = $this->findHandlerMapForRoute($routeIdentifier);

        return $this->containers->get($handler[$routeIdentifier]['handlerName']);
    }

    /**
     * @param String $loginId
     * @return String
     */
    private function getUserId($loginId)
    {
        $client = $this->findHandlerForRoute('auth');
        $body = ["json" => ["loginid" => $loginId]];
        $userRequestUri = sprintf("%s/%s", $client->getTargetUri(), 'users');
        $response = null;
        try {
            $response = $client->request('POST', $userRequestUri, $body);
            $respBody = json_decode($response->getBody()->getContents(), true);
            return $respBody['uuid'];
        } catch (BadRequestHttpException | \Exception $e) {
            return "";
        }
    }


    public function portalUserAction(Request $request)
    {

        $managerRegistry = $this->containers->get('doctrine');
        $manager = $managerRegistry->getManagerForClass(SystemSettings::class);
        $systemRepository = $manager->getRepository(SystemSettings::class);
        $systemSetting = $systemRepository->findAll();
        $global_value = $systemSetting[0]->getGlobalValues();
        $host = isset($global_value['hostname']) ? $global_value['hostname'] : $_SERVER['HTTP_HOST'];
        $dasClient = $this->getDasClient();
        $request_headers = $request->headers->all();
        $cookie = $request_headers["Cookie"] ?? $request_headers["cookie"] ?? null;
        $request_headers["Cookie"] = $cookie;
        $request_headers["EXTENSION_CONTAINER_HOSTNAME"] = $host;

        $dasUri = $this->containers->getParameter('das.uri');
        $dasRequests = new GuzzleRequest('put', $dasUri . '/token', $request_headers, $request->getContent());
        try {
            $dasResponse = $dasClient->send($dasRequests);
            $dasResponseData = $dasResponse->getBody()->getContents();
            $jsonDecodeResponse = json_decode($dasResponseData, true);
            $resCode = $dasResponse->getStatusCode();
        } catch (BadRequestHttpException | \Exception $error) {
            $this->logger->error($error->getMessage());
            $errMsg['message'] = $error->getMessage();
            $errCode = Response::HTTP_INTERNAL_SERVER_ERROR;
            if ($error->getResponse()) {
                $errVar = json_decode($error->getResponse()->getBody()->read(2048), true);
                // Token status comes in key "Token Status"
                $errMsg['message'] = array_key_exists('Error', $errVar) ? $errVar['Error'] : (array_key_exists('Token Status', $errVar) ? $errVar['Token Status'] : null);
                // When cloud token is invalid, UI needs to redirect user to cloud portal
                $errMsg['portal_url'] =  array_key_exists('portal_url', $errVar) ? $errVar['portal_url'] : null;
                $errCode = $error->getCode();
            }
            return new JsonResponse($errMsg, $errCode);
        }

        if ($resCode < 300) {
            if ($jsonDecodeResponse['user_details']) {
                $this->samlActorService->saveSamlUser(Person::class, $jsonDecodeResponse['user_details']);
            }
            $post_params = $jsonDecodeResponse['post_params'] ?? null;
            $portals =  $jsonDecodeResponse['portals'] ?? null;
            $logout_url =  $jsonDecodeResponse['logout_url'] ?? null;
            $message = $jsonDecodeResponse['message'] ?? null;
            return new JsonResponse(array(
                'token' => $jsonDecodeResponse['new_token'], 'post_params' => $post_params,
                'portals' => $portals, 'logout_url' => $logout_url, 'message' => $message
            ));
        }
    }

    public function getAction()
    {
        $path = 'authentication';
        $documentManagerRegistry = $this->getDoctrine();
        $systemSettingsManager = $documentManagerRegistry->getManagerForClass(SystemSettings::class);

        /** @var SystemSettingsRepository $systemSettingsRepository */
        $systemSettingsRepository = $systemSettingsManager->getRepository(SystemSettings::class);
        $systemSettings = $systemSettingsRepository->getSystemSettings();
        $systemSettingsValues = $systemSettings->getPrivateValues();

        try {
            $resolvedValues = Resolver::get($systemSettingsValues, $path);
        } catch (BadRequestHttpException | \Exception $e) {
            throw new NotFoundHttpException('Not Found');
        }

        return new JsonResponse($resolvedValues);
    }
    
    public function authenticatedPublicAction(Request $request)
    {
        $request_headers = $request->headers->all();
        $cookie = $request_headers["Cookie"] ?? $request_headers["cookie"] ?? null;
        unset($request_headers["cookie"]);

        $custom_headers = array(
            "Content-type" => "application/json"
        );
        $dasClient = $this->getDasClient();
        $dasUri = $this->containers->getParameter('das.uri');

        # Need to prioratize loginId over cookie
        # In case of extension fsr, authentication is cookie based. But if on a regular fsr, cookie is sent along with login creds 
        # then we need to consider the login credentials over cookie. This is to avoid cookie validation failure in DAS.

        try {
            $loginId = json_decode($request->getContent())->credentials->loginid;
        } catch (\Exception $e){
            # loginId to be set as null so that cookie can be considered
            $loginId = null;
        }
        
        if ($loginId){
            $dasRequests = new GuzzleRequest('get', $dasUri . '/users?loginid=' . $loginId, $custom_headers);
        } else if ($cookie){
            $managerRegistry = $this->containers->get('doctrine');
            $manager = $managerRegistry->getManagerForClass(SystemSettings::class);
            $systemRepository = $manager->getRepository(SystemSettings::class);
            $systemSetting = $systemRepository->findAll();
            $global_value = $systemSetting[0]->getGlobalValues();
            $host = isset($global_value['hostname']) ? $global_value['hostname'] : $_SERVER['HTTP_HOST'];

            $custom_headers["Cookie"] = $cookie;
            $custom_headers["EXTENSION_CONTAINER_HOSTNAME"] = $host;
            $dasRequests = new GuzzleRequest('get', $dasUri . '/query/users', $custom_headers);
        }
        try {
            $request_headers = array_merge($custom_headers, $request_headers);
            unset($request_headers["host"]);
            $dasResponse = $dasClient->send($dasRequests);
            $dasResponseData = json_decode($dasResponse->getBody()->getContents());
            if (count($dasResponseData->usersresp)) {
                $dasUuid = $dasResponseData->usersresp[0]->uuid;
            } else {
                return new JsonResponse(["message" => "username not found"]);
            }
            $managerRegistry = $this->containers->get('doctrine');
            $manager = $managerRegistry->getManagerForClass(Actor::class);
            $actorRepository = $manager->getRepository(Actor::class);
            $actor = $actorRepository->findOneBy(["userId" => $dasUuid]);
            if (!is_null($actor) && $this->fsrVoter->isGranted('update.security', $actor)) {
                $request_headers["X-USER"] = $actor->getUuid();
                $request_headers['X-REMOTE_ADDR'] = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
                $dasRequests = new GuzzleRequest('post', $dasUri . '/execute/action', $request_headers, $request->getContent());
                $dasResponse = $dasClient->send($dasRequests);
                return new JsonResponse(json_decode($dasResponse->getBody()->getContents(), true));
            } else {
                return new Response("Access Denied", Response::HTTP_FORBIDDEN);
            }
        } catch (\Exception $e) {
            $errMsg = $e->getResponse() ? json_decode($e->getResponse()->getBody()->read(2048), true) : $e->getMessage();
            $errCode = $e->getCode() ? $e->getCode() : Response::HTTP_BAD_GATEWAY;
            return new JsonResponse($errMsg, $errCode);
        }
    }
}
