<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller\Settings;

use App\Utility\Resolver;
use App\Entity\Actors\Actor;
use InvalidArgumentException;
use App\Service\SettingsHelper;
use App\Security\Voter\FsrVoter;
use App\Entity\Settings\UserSettings;
use App\Entity\Settings\SystemSettings;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Core\DataProvider\ItemDataProviderInterface;
use Symfony\Component\Finder\Exception\AccessDeniedException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

/**
 * Class SettingsController
 */
class SettingsController extends AbstractController
{

    private $settingHelper;

    protected $fsrVoter;

    protected $chainItemDataProvider;

    protected $tokenStorage;

    public function __construct(SettingsHelper $settingHelper, FsrVoter $fsrVoter, ItemDataProviderInterface $chainItemDataProvider, TokenStorageInterface $tokenStorage)
    {
        $this->settingHelper = $settingHelper;
        $this->fsrVoter = $fsrVoter;
        $this->chainItemDataProvider = $chainItemDataProvider;
        $this->tokenStorage = $tokenStorage;
    }

    /**
     * @Route("/api/3/user_settings/{id}/{path?}", name="api_user_settings_get", requirements={"path"=".+"}, methods={"GET"})
     */
    public function getAction($id, $path, Request $request)
    {
        if (!$this->fsrVoter->isGranted("read.application")) {
            throw new AccessDeniedException();
        }
        if ($id == "current") {
            /** @var Actor $actor */
            $actor = $this->tokenStorage->getToken()->getUser();
        } else {
            /** @var Actor $actor */
            $actor = $this->chainItemDataProvider->getItem(Actor::class, ["uuid" => $id]);
        }

        list($userSettings, $systemSettings) = $this->settingHelper->getDataForActor($actor);
        return $this->getSettings($path, $userSettings, $systemSettings);
    }

    /**
     * @Route("/api/3/user_settings/{id}/{path?}", name="api_user_settings_set", requirements={"path"=".+"}, methods={"PUT"})
     */
    public function setAction($id, $path, Request $request)
    {
        $this->fsrVoter->isGranted("update.application");
        $newValues = json_decode($request->getContent(), true);
        if ($id == "current") {
            /** @var Actor $actor */
            $actor = $this->tokenStorage->getToken()->getUser();
        } else {
            /** @var Actor $actor */
            $actor = $this->chainItemDataProvider->getItem(Actor::class, ["uuid" => $id]);
        }

        list($userSettings, $systemSettings) = $this->settingHelper->getDataForActor($actor);

        return $this->setSettings($path, $userSettings, $systemSettings, $newValues);
    }

    /**
     * @Route("/api/3/user_settings/{id}/{path?}", name="api_user_settings_unset", requirements={"path"=".+"}, methods={"DELETE"})
     */
    public function unsetAction($id, $path, Request $request)
    {
        $this->fsrVoter->isGranted("delete_application");

        if ($id == "current") {
            /** @var Actor $actor */
            $actor = $this->tokenStorage->getToken()->getUser();
        } else {
            /** @var Actor $actor */
            $actor = $this->chainItemDataProvider->getItem(Actor::class, ["uuid" => $id]);
        }

        list($userSettings, $systemSettings) = $this->settingHelper->getDataForActor($actor);

        return $this->unsetSettings($path, $userSettings, $systemSettings);
    }

    /**
     * @param string $path
     * @param UserSettings $userSettings
     * @param SystemSettings $systemSettings
     * @param $newValues
     *
     * @return JsonResponse
     */
    protected function setSettings($path, $userSettings, $systemSettings, $newValues)
    {
        $userSettingsValues = $userSettings->getPublicValues();

        Resolver::set($userSettingsValues, $path, $newValues, '/');

        $this->settingHelper->saveUserSettings($userSettings, $userSettingsValues);
        $userSettingsValues = $this->settingHelper->getMergedSettings($userSettings, $systemSettings);

        return new JsonResponse($userSettingsValues);
    }

    /**
     * @param string $path
     * @param UserSettings $userSettings
     * @param SystemSettings $systemSettings
     *
     * @return JsonResponse
     */
    protected function getSettings($path, $userSettings, $systemSettings)
    {
        $userSettingsValues = $this->settingHelper->getMergedSettings($userSettings, $systemSettings);

        if (empty($path)) {
            //Empty path means return entire object and not the empty string key
            return new JsonResponse($userSettingsValues);
        }

        try {
            $resolvedValues = Resolver::get($userSettingsValues, $path, '/');
        } catch (InvalidArgumentException | \Exception $e) {
            throw new NotFoundHttpException('Not Found');
        }

        return new JsonResponse($resolvedValues);
    }

    /**
     * @param string $path
     * @param UserSettings $userSettings
     * @param SystemSettings $systemSettings
     *
     * @return JsonResponse
     */
    private function unsetSettings($path, $userSettings, $systemSettings)
    {
        $userSettingsValues = $userSettings->getPublicValues();

        if (empty($path)) {
            //Empty path means return entire object and not the empty string key
            return new JsonResponse($userSettingsValues);
        }

        try {
            Resolver::uset($userSettingsValues, $path, '/');
        } catch (InvalidArgumentException | \Exception $e) {
            throw new NotFoundHttpException('Not Found');
        }

        $this->settingHelper->saveUserSettings($userSettings, $userSettingsValues);
        $userSettingsValues = $this->settingHelper->getMergedSettings($userSettings, $systemSettings);

        return new JsonResponse($userSettingsValues);
    }

    public function cgetAction(Request $request)
    {
        throw $this->createNotFoundException();
    }

    public function cpostAction(Request $request)
    {
        throw $this->createNotFoundException();
    }
}
