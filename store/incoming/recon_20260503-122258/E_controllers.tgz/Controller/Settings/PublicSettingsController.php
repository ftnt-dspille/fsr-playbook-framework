<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller\Settings;

use App\Utility\Resolver;
use InvalidArgumentException;
use App\Entity\Settings\SystemSettings;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\SystemSettingsRepository;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

/**
 * Class PublicSettingsController
 */
class PublicSettingsController extends AbstractController
{

    public function __construct(
        private EntityManagerInterface $entityManager
    ) {
    }

    /**
     * @Route(
     *     name="get_settings_authentication_message",
     *     path="/api/public/settings/authentication",
     *     methods={"GET"}
     * )
     */
    public function getAction()
    {
        $path = 'authentication';
        /** @var SystemSettingsRepository $systemSettingsRepository */
        $systemSettingsRepository = $this->entityManager->getRepository(SystemSettings::class);
        $systemSettingsQueryBuilder = $systemSettingsRepository->createQueryBuilder('ss');

        // Below conditions will get default value.
        $systemSettingsQueryBuilder->where('ss.privateValues IS NOT NULL');
        $systemSettingsQueryBuilder->where('ss.name IS NULL');
        $systemSettings = $systemSettingsQueryBuilder->getQuery()->getResult();
        if (!$systemSettings) {
            throw new BadRequestHttpException('No System Settings Identified');
        }
        $systemSettings = $systemSettings[0];
        $systemSettingsValues = $systemSettings->getPrivateValues();

        try {
            $resolvedValues = Resolver::get($systemSettingsValues, $path);
        } catch (InvalidArgumentException | \Exception $e) {
            throw new NotFoundHttpException('Not Found');
        }

        return new JsonResponse($resolvedValues);
    }
}
