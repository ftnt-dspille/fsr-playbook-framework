<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Service\IriHelper;
use Psr\Log\LoggerInterface;
use App\Constants\AppConstants;
use App\Service\MetadataHelper;
use App\Service\UtilityService;
use App\Security\Voter\FsrVoter;
use App\Constants\ErrorConstants;
use App\Controller\BaseController;
use ApiPlatform\Core\Util\CloneTrait;
use Doctrine\ORM\Mapping\ClassMetadata;
use Doctrine\Inflector\InflectorFactory;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use ApiPlatform\Core\DataProvider\CollectionDataProviderInterface;
use ApiPlatform\Core\Serializer\SerializerContextBuilderInterface;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class AssociationController extends BaseController
{
    use CloneTrait;

    /** @var FsrVoter */
    private $fsrVoter;

    /** @var IriHelper */
    private $iriHelper;

    /** @var  EntityManagerInterface */
    private $entityManager;

    /** @var HttpKernelInterface */
    private $kernel;

    private $utilityService;

    protected $collectionDataProvider;

    protected $serializerContextBuilder;

    protected $inflector;

    public function __construct(
        ContainerInterface $containers,
        ResourceClassResolverInterface $resourceClassResolver,
        FsrVoter $fsrVoter,
        IriHelper $iriHelper,
        EntityManagerInterface $entityManager,
        HttpKernelInterface $kernel,
        MetadataHelper $metadataHelper,
        CollectionDataProviderInterface $collectionDataProvider,
        SerializerContextBuilderInterface $serializerContextBuilder,
        TagAwareCacheInterface $cache,
        UtilityService $utilityService,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->iriHelper = $iriHelper;
        $this->entityManager = $entityManager;
        $this->kernel = $kernel;
        $this->collectionDataProvider = $collectionDataProvider;
        $this->serializerContextBuilder = $serializerContextBuilder;
        $this->utilityService = $utilityService;
        $this->inflector = InflectorFactory::create()->build();
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function getAssociationResult(Request $request, $resourceShortName, $id, $field)
    {
        $queryLimit = $request->get('$limit', 30);
        $queryPage = $request->get('$page', 1);
        $partial = $request->get('$partial', false);

        $resourceClass = $this->getResourceFromClassName($resourceShortName);
        $module = $this->metadataHelper->getModuleFromClassName($resourceClass);

        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $module);
        $item = $this->iriHelper->findOrThrowNotFound('/api/3/' . $resourceShortName . '/' . $id);

        $this->utilityService->validateOwnerShip($request, $item);

        // Check Field Level Permissions
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_FIELD_READ . '.' . $module . '.' . $field);

        $inverseField = null;
        /** @var ManagerRegistry $managerRegistry */
        $managerRegistry = $this->container->get('doctrine');
        $manager = $managerRegistry->getManagerForClass($resourceClass);
        $classMetadata = $manager->getClassMetadata($resourceClass);
        if ($classMetadata->hasAssociation($field)) {
            /** @var ClassMetadata $classMetadata */
            $association = $classMetadata->associationMappings[$field];
            if (in_array($association['type'], [ClassMetadata::MANY_TO_MANY, ClassMetadata::ONE_TO_MANY])) {
                $childClassMetadata = $manager->getClassMetadata($association['targetEntity']);
                $childAssociations = $childClassMetadata->associationMappings;
                foreach ($childAssociations as $childAssociation) {
                    if ($childAssociation['targetEntity'] === $association['sourceEntity']) {
                        if ($association['type'] === $childAssociation['type'] && $childAssociation['type'] === ClassMetadata::MANY_TO_MANY) {
                            $this->logger->info("Request for ManyToManyField Relation");
                            $inverseField = $childAssociation['fieldName'];
                            break;
                        } elseif ($association['type'] !== ClassMetadata::MANY_TO_MANY && in_array($childAssociation['type'], [ClassMetadata::MANY_TO_ONE, ClassMetadata::ONE_TO_MANY])) {
                            $this->logger->info("Request for Lookup or ManyToOneRelation");
                            $inverseField = $childAssociation['fieldName'];
                            break;
                        }
                    }
                }
                $targetEntity = $association['targetEntity'];
                $associationResource = $targetEntity;
                $associationModule = $this->metadataHelper->getModuleFromClassName($associationResource);
                if (is_null($inverseField)) {
                    throw new BadRequestHttpException(ErrorConstants::IMPROPER_RELATION_DEFINITION);
                }
                $request->query->set($inverseField, $item->getUuid());
                if ($this->containers->hasParameter('ignore_rbac_for_related_record') && $this->containers->getParameter('ignore_rbac_for_related_record')) {
                    $GLOBALS['__associatedFieldRequest__'] = true;
                }
                $request->overrideGlobals();
                $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $associationModule);
                $attributes = [];
                $attributes['filters'] = ['$limit' => $queryLimit, '$page' => $queryPage, '$partial' => $partial];
                $attributes['resource_class'] = $associationResource;
                $attributes['collection_operation_name'] = "get";
                $context = $this->serializerContextBuilder->createFromRequest($request, true, $attributes);
                $context['ignore_authorization'] = true;
                $associatedEntities = $this->collectionDataProvider->getCollection($associationResource, $request, $attributes);
                $data1 = $this->serializer->normalize($associatedEntities, AppConstants::NORMALIZER_METHOD, $context);
                return new JsonResponse($data1);
            }
        }
        throw new BadRequestHttpException(sprintf(ErrorConstants::FIELD_MISSING, $field, $resourceShortName));
    }

    /**
     * @param Request $request
     * @param string $id
     * @param string $field
     * @param string $fieldId
     * @return Response
     */
    public function deleteFieldAction(Request $request, $resourceShortName, $id, $field, $fieldId)
    {
        $resourceClass = $this->getResourceFromClassName($resourceShortName);
        $module = $this->metadataHelper->getModuleFromClassName($resourceClass);
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . $module);

        /** @var BaseEntity $object */
        $item = $this->iriHelper->findOrThrowNotFound('/api/3/' . $resourceShortName . '/' . $id);
        $this->utilityService->validateOwnerShip($request, $item);

        $managerRegistry = $this->container->get('doctrine');
        $modelManager = $managerRegistry->getManagerForClass($resourceClass);
        $classMetadata = $modelManager->getClassMetadata($resourceClass);
        if ($classMetadata->hasAssociation($field)) {
            /** @var ClassMetadata $classMetadata */
            $association = $classMetadata->associationMappings[$field];
            if (in_array($association['type'], [ClassMetadata::MANY_TO_MANY, ClassMetadata::ONE_TO_MANY, ClassMetadata::TO_MANY])) {
                $targetEntity = $association['targetEntity'];
                $associateResource = $this->metadataHelper->getTypeFromClassName($targetEntity);
                $associatedModule = $this->metadataHelper->getModuleFromClassName($targetEntity);
                $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.' . $associatedModule);

                $associatedObject = $this->iriHelper->findOrThrowNotFound('/api/3/' . $associateResource . '/' . $fieldId);
                $this->utilityService->validateOwnerShip($request, $associatedObject);
                $fieldName = $association['fieldName'];
                $methodName = $this->inflector->singularize('remove' . $this->inflector->classify($fieldName));
                $item->{$methodName}($associatedObject);
                $modelManager->flush();
                return new JsonResponse([], Response::HTTP_NO_CONTENT);
            }
        }
        throw new BadRequestHttpException("Bad Request");
    }
}
