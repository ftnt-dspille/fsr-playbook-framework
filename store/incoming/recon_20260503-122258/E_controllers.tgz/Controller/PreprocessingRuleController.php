<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Constants\ErrorConstants;
use App\Service\MetadataHelper;
use App\Utility\FilterUtility;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\SerializerInterface;

class PreprocessingRuleController extends AbstractController
{
    public function __construct(
        private FilterUtility       $filterUtility,
        private MetadataHelper      $metadataHelper,
        private SerializerInterface $serializer
    )
    {
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function validate(Request $request): JsonResponse
    {
        $content = json_decode($request->getContent(), true) ?? [];

        if(empty($content['data']) || empty($content['rule'])){
            return new JsonResponse( ErrorConstants::FSR_CH_0000020, Response::HTTP_BAD_REQUEST);
        }

        $data = $content['data'];
        $rule = $content['rule'];
        $output = [];

        if(isset($content['entityType'])){
            $data = $this->resolveReference($content['entityType'], $data);
        }

        $output['output'] = $this->filterUtility->evaluateObject($rule, $data, []);
        return new JsonResponse($output);
    }

    /**
     * @param $entityType
     * @param mixed $data
     * @return mixed
     */
    public function resolveReference($entityType, mixed $data): mixed
    {
        $type = $entityType;
        $resourceClass = $this->metadataHelper->getResourceFromClassName($type);
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($data),
            $resourceClass,
            'jsonld',
            ['fetch_data' => false]
        );
        $data = $this->serializer->serialize($denormalizedObject, 'json', []);
        $data = json_decode($data, true);
        return $data;
    }
}