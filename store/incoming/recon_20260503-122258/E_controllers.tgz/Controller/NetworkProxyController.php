<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Entity\Core\Proxy;
use App\Security\Voter\FsrVoter;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use ApiPlatform\Core\DataProvider\ItemDataProviderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Finder\Exception\AccessDeniedException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class NetworkProxyController extends AbstractController
{

    private $chainItemDataProvider;
    private $fsrVoter;
    private $entityManager;
    private $containers;

    public function __construct(
        ItemDataProviderInterface $chainItemDataProvider, FsrVoter $fsrVoter, 
        EntityManagerInterface $entityManager, ContainerInterface $containers,
        protected SerializerInterface $serializer)
    {
        $this->chainItemDataProvider = $chainItemDataProvider;
        $this->fsrVoter = $fsrVoter;
        $this->entityManager = $entityManager;
        $this->containers = $containers;
        $this->serializer = $serializer;
    }

    const MODULE_TYPE = "proxy";
    const ENCODE_DECODE_FIELDS = ['proxies'];
    const PROXY_UUID = 'c90e8c1b-cu11-as33-3sk-717199a2e182';
    const PROXY_ROUTING_KEY = 'key.crudhub.proxy';
    const NORMALIZER_METHOD = 'jsonld';

    /**
     * @param Request $request
     * @param $id
     * @return Response
     */
    public function getOnIdAction(Request $request, $id)
    {
        return $this->getAction($request);
    }

    /**
     * @param Request $request
     * @return Response|static
     */
    public function getAction(Request $request)
    {
        $resource = Proxy::class;
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'security')) {
            throw new AccessDeniedException();
        }
        $object = $this->chainItemDataProvider->getItem($resource, ["uuid" => self::PROXY_UUID]);
        if (!$object) {
            return new JsonResponse((object) null);
        }
        $serializer = $this->serializer;
        $updatedObject = $serializer->normalize($object, self::NORMALIZER_METHOD);
        return $this->sendResponse($updatedObject);
    }

    public function sendReplicationData(array $data, $routing_key)
    {
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->setContentType('application/json');
        $this->containers->get('old_sound_rabbit_mq.cyops_crud_auditing_producer')->publish(json_encode($data), $routing_key);
    }

    /**
     * @param $dataObject
     * @param bool $publish_data
     * @return \Symfony\Component\HttpFoundation\Response|static
     */
    public function sendResponse($dataObject, $publish_data = false)
    {
        $cloneDataObject = $dataObject;
        $isLocalhost = in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', 'localhost', '::1']);
        $dataObject['proxies'] = json_decode($dataObject['proxies']);
        $cloneDataObject['proxies'] = json_decode($cloneDataObject['proxies']);

        foreach ($cloneDataObject['proxies'] as $ot_key => $fields) {
            $fields->value = $this->buildURL($fields);
        }
        if ($publish_data) {
            $this->sendReplicationData([$cloneDataObject], self::PROXY_ROUTING_KEY);
        }

        if (!$isLocalhost) {
            foreach ($dataObject['proxies'] as $ot_key => $fields) {
                foreach ($fields as $in_key => $value) {
                    if ($in_key == 'password') {
                        $dataObject['proxies']->$ot_key->$in_key = null;
                    }
                }
            }
            return new JsonResponse($dataObject);
        }
        return new JsonResponse($cloneDataObject);
    }

    /**
     * @param $data
     * @return string
     */
    protected function buildURL($data)
    {
        $stringValue = '';
        $protocol = 'http://';
        if (!empty($data->url)) {
            if (str_starts_with($data->url, "http://")) {
                $url = substr($data->url, 7, strlen($data->url));
                $protocol = 'http://';
            } else if (str_starts_with($data->url, "https://")) {
                $url = substr($data->url, 8, strlen($data->url));
                $protocol = 'https://';
            } else {
                $url = $data->url;
            }
            if (!empty($data->username) && !empty($data->password)) {
                $stringValue = $protocol . $data->username . ':' . $data->password . '@' . $url;
            } else {
                $stringValue = $protocol . $url;
            }
            if (!empty($data->port)) {
                $stringValue .= ':' . $data->port;
            }
        }
        return $stringValue;
    }

    /**
     * @param Request $request
     * @return Response
     * @throws DeserializationException
     */
    public function postAction(Request $request)
    {
        $resource = Proxy::class;
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . 'security')) {
            throw new AccessDeniedException();
        }
        $decodedRequestData = json_decode($request->getContent(), true);
        $request_data = $this->prePostAdd($decodedRequestData);
        $serializer = $this->serializer;
        $object = $serializer->deserialize(json_encode($request_data), $resource, 'jsonld');
        $this->entityManager->persist($object);
        $this->entityManager->flush();
        $updatedObject = $serializer->normalize($object, self::NORMALIZER_METHOD);
        return $this->sendResponse($updatedObject, true);
    }

    /**
     * @param $decodedRequestData
     * @return mixed
     */
    public function prePostAdd($decodedRequestData)
    {
        $this->validateProxy($decodedRequestData);
        $decodedRequestData['proxies'] = json_encode($decodedRequestData['proxies']);
        $decodedRequestData['uuid'] = self::PROXY_UUID;
        array_push($decodedRequestData['noProxy'], 'localhost', '127.0.0.1');
        $decodedRequestData['noProxy'] = array_values(array_unique($decodedRequestData['noProxy']));
        return $decodedRequestData;
    }

    /**
     * @param $proxy_body
     */
    private function validateProxy($proxy_body)
    {
        if ($proxy_body === null) {
            throw new BadRequestHttpException("Proxy data cannot be null");
        }
        if (empty($proxy_body['proxies'])) {
            throw new BadRequestHttpException("HTTP and HTTPS Proxy cannot be null");
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @return ProxyController|Response|\Symfony\Component\HttpFoundation\Response|static
     * @throws DeserializationException
     */
    public function putAction(Request $request, $id)
    {
        $resource = Proxy::class;
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . 'security')) {
            throw new AccessDeniedException();
        }

        $object = $this->chainItemDataProvider->getItem($resource, ["uuid" => self::PROXY_UUID]);
        if (!$object) {
            return new JsonResponse((object) null);
        }

        $serializer = $this->serializer;
        $objectData = json_decode($request->getContent(), true);
        $preUpdatedObject = $serializer->normalize($object, self::NORMALIZER_METHOD);

        $request_data = $this->prePutAdd($objectData, $preUpdatedObject);
        $object = $serializer->deserialize(json_encode($request_data), $resource, 'jsonld', ['object_to_populate' => $object]);
        $this->entityManager->persist($object);
        $this->entityManager->flush();
        $updatedObject = $serializer->normalize($object, self::NORMALIZER_METHOD);
        return $this->sendResponse($updatedObject, true);
    }

    /**
     * @param $objectData
     * @param $preUpdatedObject
     * @return mixed
     */
    protected function prePutAdd($objectData, $preUpdatedObject)
    {
        $proxies = json_decode($preUpdatedObject['proxies']);
        $objectData['proxies'] = $this->merge_existing_proxy($proxies, $objectData['proxies'], $objectData['toggle']);
        if (isset($objectData['noProxy'])) {
            array_push($objectData['noProxy'], 'localhost', '127.0.0.1');
            $objectData['noProxy'] = array_values(array_unique($objectData['noProxy']));
        }
        return $objectData;
    }

    /**
     * @param $exiting_proxy
     * @param $new_proxy
     * @return string
     */
    protected function merge_existing_proxy($exiting_proxy, $new_proxy, $copyHttp=false)
    {
        if ($new_proxy) {
            foreach ($new_proxy as $ot_key => $field) {
                if (!array_key_exists("password", $field) && (isset($exiting_proxy?->$ot_key?->password))) {
                        $new_proxy[$ot_key]['password'] = $exiting_proxy->$ot_key->password;
                        if ($copyHttp && !$new_proxy[$ot_key]['password'] && array_key_exists('HTTP_PROXY', $new_proxy)) {
                            $new_proxy[$ot_key]['password'] = $new_proxy['HTTP_PROXY']['password'];
                        }
                }
            }
            return json_encode($new_proxy);
        }
        return json_encode($exiting_proxy);
    }

    /**
     * @param Request $request
     * @param string $id
     */
    public function deleteAction(Request $request, $id)
    {
        throw new BadRequestHttpException("Method Not Implemented");
    }

    /**
     * @param Request $request
     */
    public function bulkAction(Request $request)
    {
        throw new BadRequestHttpException("Bulk Operation on Proxy Module is not allowed");
    }
}
