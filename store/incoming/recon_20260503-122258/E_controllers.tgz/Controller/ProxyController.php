<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use stdClass;
use App\Utility\Resolver;
use Psr\Log\LoggerInterface;
use App\Entity\Actors\ApiKey;
use App\Entity\Custom\Person;
use App\Security\Voter\FsrVoter;
use App\Encoder\CorrectSimpleJWS;
use App\Service\SamlActorService;
use App\Entity\Settings\SystemSettings;
use App\Providers\JwtLogoutKeyProvider;
use App\Service\AccessibleTeamIdsProvider;
use GuzzleHttp\Psr7\Request as GuzzleRequest;
use Symfony\Component\HttpFoundation\Request;
use GuzzleHttp\Exception\BadResponseException;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Cookie;
use App\Encoder\Restricted\RestrictedUserToken;
use App\Providers\PermissionsDictionaryBuilder;
use GuzzleHttp\Psr7\Response as GuzzleResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\Authorization\Voter\VoterInterface;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class ProxyController extends AbstractController
{

    protected $containers;

    protected $samlActorService;

    protected $fsrVoter;

    protected $tokenStorage;

    protected $jwtLogoutProvider;

    private $accessibleTeamIdsProvider;

    private $cache;

    public function __construct(
        AccessibleTeamIdsProvider $accessibleTeamIdsProvider,
        ContainerInterface $containers,
        SamlActorService $samlActorService,
        FsrVoter $fsrVoter,
        TokenStorageInterface $tokenStorage,
        JwtLogoutKeyProvider $jwtLogoutProvider,
        TagAwareCacheInterface $cache,
        protected LoggerInterface $logger
    ) {
        $this->accessibleTeamIdsProvider = $accessibleTeamIdsProvider;
        $this->containers = $containers;
        $this->samlActorService = $samlActorService;
        $this->fsrVoter = $fsrVoter;
        $this->tokenStorage = $tokenStorage;
        $this->jwtLogoutProvider = $jwtLogoutProvider;
        $this->cache = $cache;
    }

    const QUERY_STRING = 'query_string';
    const URL = 'url';
    const BODY = 'body';
    const LOGIN = 'login';
    const LOGOUT = 'logout';
    const SAML = 'saml';
    const USERID = 'userId';
    const USER_REQUEST_URI = "%s/%s?%s";
    const SAML_FAILURE_MESSAGE = 'We are sorry, but the server encountered an error while handling your request. Please contact your administrator for assistance.';
    const CACHED_DYNAMIC_VARIABLES = ['Indicator_Feed_Reputation_Preference'];

    public function proxyRouteAction($routeIdentifier, $route, Request $request, $customHeader = [], $payload = null)
    {
        $token = $this->tokenStorage->getToken();

        $client = $this->findHandlerForRoute($routeIdentifier);
        $permissionGroups = $this->findPermissionGroupsForRoute($routeIdentifier);

        $matchedPermissionGroups = 0;

        if ($this->tokenStorage->getToken() && $this->tokenStorage->getToken()::class != RestrictedUserToken::class) {
            foreach ($permissionGroups as $permissionName => $permissionGroup) {
                /** @var VoterInterface[] $additionalVoters */
                $additionalVoters = [];
                $permissionsRequired = [];
                // Every User should be able to retrieve the config token section so that UI can handle it accordingly.
                // $ignoreAuthorization = false;
                $operator = $permissionGroup['operator'] ?? null;

                //Check method first
                if ($request->getMethod() != $permissionGroup['action']) {
                    continue;
                }

                $uuid = null;

                //This was matched because it had no permissions required
                if (empty($permissionGroup['permissions'])) {
                    $matchedPermissionGroups++;
                }

                //Check permissions
                foreach ($permissionGroup['permissions'] as $permission) {
                    //Check incoming route
                    $routeRegex = sprintf('/%s/', str_replace('/', '\/', $permissionGroup['route']));
                    preg_match($routeRegex, $route, $matches);

                    if (empty($matches)) {
                        continue;
                    }

                    //This was matched because it matched the regex
                    $matchedPermissionGroups++;

                    //Check query strings to make sure it matches
                    if (isset($permissionGroup['params'])) {
                        foreach ($permissionGroup['params'] as $key => $value) {
                            if ($request->query->get($key) != $value) {
                                continue 2; //Continue to next permission group
                            }
                        }
                    }

                    //Build Permissions
                    $permissionsRequired[] = $permission;

                    //Determine where uuid is
                    if (!array_key_exists('uuidLocation', $permissionGroup)) {
                        continue;
                    }
                    $uuidLocation = $permissionGroup['uuidLocation'];

                    // Check if in the URL
                    if (isset($uuidLocation[self::URL])) {
                        $matchNumber = $uuidLocation[self::URL]['matchNumber'];
                        if (count($matches) >= $matchNumber) {
                            $uuid = $matches[$matchNumber];
                        }
                    }

                    // Check if in the BODY
                    if (isset($uuidLocation[self::BODY])) {
                        $path = $uuidLocation[self::BODY]['path'];
                        $bodyAsArray = json_decode($request->getContent(), true);
                        $uuid = Resolver::get($bodyAsArray, $path);
                    }

                    // Check if in the Query String
                    if (isset($uuidLocation[self::QUERY_STRING])) {
                        $queryKey = $uuidLocation[self::QUERY_STRING]['key'];
                        $uuid = $request->query->get($queryKey);
                    }
                    //Build additional voters
                    $additionalVoters[] = $permissionGroup['additionalVoters'];
                }

                //Keep checking for more matched permission groups
                if ($matchedPermissionGroups <= 0) {
                    continue;
                }

                if ($operator && $operator == 'AND') {
                    $permissionMatchCount = 0;
                    foreach ($permissionsRequired as $perm) {
                        if ($this->fsrVoter->isGranted($perm)) {
                            $permissionMatchCount++;
                        }
                    }
                    if ($permissionMatchCount < count($permissionsRequired)) {
                        throw new AccessDeniedException();
                    } else {
                        break;
                    }
                } else {
                    $matched = false;
                    foreach ($permissionsRequired as $perm) {
                        if ($this->fsrVoter->isGranted($perm)) {
                            $matched = true;
                            break;
                        }
                    }
                    if (!empty($additionalVoters)) {
                        if ($token->getUsername() == $uuid) {
                            break;
                        }
                    }
                    if (!$matched) {
                        throw new AccessDeniedException();
                    } else {
                        break;
                    }
                }
            }

            if ($matchedPermissionGroups == 0) {
                throw new AccessDeniedException();
            }
        }

        $userRequestUri = sprintf(self::USER_REQUEST_URI, $client->getTargetUri(), $route, $request->getQueryString());

        if ($payload) {
            $content = $payload;
        } else {
            $content = $request->getContent();
        }

        //Remove host from the headers so guzzle rebuilds it with the port
        $headersExceptForHost = $request->headers->all();
        unset($headersExceptForHost['host']);
        unset($headersExceptForHost['cookie']);
        $headersExceptForHost['X-REMOTE_ADDR'] = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
        if (get_class($this->tokenStorage->getToken()) != RestrictedUserToken::class) {
            $headersExceptForHost['X-USER'] = $this->getUser()->getUuid();
        } else {
            $headersExceptForHost['X-USER-EMAIL'] = $this->tokenStorage->getToken()->getUser()->getEmail();
        }
        $hmacRequest = new GuzzleRequest($request->getMethod(), $userRequestUri, array_merge($headersExceptForHost, $customHeader), $content);

        /** @var GuzzleResponse $response */
        try {
            $response = $client->send($hmacRequest);
        } catch (BadResponseException $exception) {
            $response = $exception->getResponse();
        } catch (\Exception $e) {
            throw new \Exception('Failure: ' . $e->getMessage());
        }
        $response = new Response($response->getBody()->getContents(), $response->getStatusCode(), ['Content-Type' => $response->getHeader('Content-Type')]);
        $contentArray = json_decode($response->getContent(), true);
        if (!is_null($contentArray) && array_key_exists('Error', $contentArray) && str_contains($contentArray['Error'], 'not enough space available')) {
            $response->setContent('{"Error": "Not enough space available in /opt disk. Please run log collect command from terminal."}');
        }
        return $response;
    }

    public function wfProxyRouteAction($routeIdentifier, $route, Request $request)
    {
        if (strpos($route, "api/dynamic-variable/") !== false && $request->getMethod() == "PUT") {
            // get dynamic variable name
            $payload = json_decode($request->getContent(), true);
            $dynamicVariableName = $payload['name'];
            if (array_search($dynamicVariableName, self::CACHED_DYNAMIC_VARIABLES) !== false) {
                $this->cache->delete($dynamicVariableName);
            }
        }
        $teams = json_encode(["/api/3/teams/doesnotexist"]);
        if (get_class($this->tokenStorage->getToken()) != RestrictedUserToken::class) {
            $teams = $this->getAccessibleTeamIris();
        }
        $customHeader = [];
        if ($this->getUser()) {
            $customHeader = ['X-USER' => $this->getUser()->getUuid()];
        }
        if ($request->headers->get('Content-Type') == '' || $request->headers->get('content-type') == '') {
            $customHeader['content-type'] = 'application/json';
        }
        if (in_array($request->getMethod(), ["POST", "DELETE"])) {
            $payload = json_decode($request->getContent(), true);
            if (is_null($payload)) {
                $payload = [];
            }
            $payload['__TEAMS'] = json_decode($teams);
            return $this->proxyRouteAction($routeIdentifier, $route, $request, $customHeader, json_encode($payload));
        }
        return $this->proxyRouteAction($routeIdentifier, $route, $request, []);
    }

    public function ruleProxyRouteAction($routeIdentifier, $route, Request $request)
    {
        $teams = ["/api/3/teams/doesnotexist"];
        if (get_class($this->tokenStorage->getToken()) != RestrictedUserToken::class) {
            $teams = $this->getAccessibleTeamIris();
        }
        if (strpos($route, "api/system-notification/notifications/") !== false && $request->getMethod() == "POST") {
            $query = new stdClass();
            $roles = $this->getLoggedInUserRoles();
            $user_uuid = $this->getUser()->getUuid();
            $query->rbac_info = new stdClass();
            $query->rbac_info->{'teams'} = $teams;
            $query->rbac_info->{'roles'} = $roles;
            $query->rbac_info->{'source'} = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
            $query->rbac_info->{'user'} = $user_uuid;
            return $this->proxyRouteAction($routeIdentifier, $route, $request, [], json_encode($query));
        }
        return $this->proxyRouteAction($routeIdentifier, $route, $request, []);
    }

    public function dasRouteAction($routeIdentifier, $route, Request $request)
    {
        // Blocking all DAS calls using API Key
        if($this->tokenStorage->getToken() &&
            get_class($this->tokenStorage->getToken()->getUser()) == ApiKey::class){
            $this->logger->error($request->getUri(). " call is not allowed using API Key.");
            throw new AccessDeniedException();
        }
        $is_admin = $this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.security');
        $customHeader = array(
            "X-ADMIN-USER" => $is_admin
        );

        return $this->proxyRouteAction($routeIdentifier, $route, $request, $customHeader);
    }

    public function getLoggedInUserRoles()
    {
        $user = $this->getUser();
        $roles_uuid = [];
        foreach ($user->getRoles() as $role) {
            $roles_uuid[] = $role->getUuid();
        }
        return $roles_uuid;
    }

    public function integrationProxyRouteAction($routeIdentifier, $route, Request $request)
    {
        if ($request->getMethod() == "POST" || $request->getMethod() == "PUT" || $request->getMethod() == "DELETE") {
            if (strpos($route, "import-connector") === false) {
                $teams = $this->getAccessibleTeamIris();
                $roles = $this->getLoggedInUserRoles();
                $query = $request->getContent() ? json_decode($request->getContent()) : new stdClass();
                $query->rbac_info = new stdClass();
                $query->rbac_info->{'teams'} = $teams;
                $query->rbac_info->{'roles'} = $roles;
                $query->rbac_info->{'source'} = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
                $query->rbac_info->{'user_iri'} = '/api/3/people/' . $this->getUser()->getUuid();
                return $this->proxyRouteAction($routeIdentifier, $route, $request, [], json_encode($query));
            }
        }
        return $this->proxyRouteAction($routeIdentifier, $route, $request);
    }

    public function postmanProxyRouteAction($routeIdentifier, $route, Request $request)
    {
        if ((strpos($route, "staging-mmd/") !== false && $request->getMethod() == "PUT") || (strpos($route, "publish/") !== false && $request->getMethod() == "POST")) {
            $customheader['X-USER'] = $this->getUser()->getUuid();
            return $this->proxyRouteAction($routeIdentifier, $route, $request, $customheader);
        }
        return $this->proxyRouteAction($routeIdentifier, $route, $request);
    }

    /**
     * @return array
     */
    protected function getAccessibleTeamIris()
    {
        $accessibleTeamIds = $this->accessibleTeamIdsProvider->getDataForCurrentUser();
        return json_encode($accessibleTeamIds);
    }

    public function routePublicSAMLAction($routeIdentifier, $route, Request $request)
    {
        if ($route !== self::LOGIN && $route !== self::LOGOUT) {
            return new Response(null, Response::HTTP_NOT_FOUND);
        }
        // Handle POST request for SOCaaS
        $request_body_str = $request->getContent();
        if (strpos($request_body_str, 'h_key') !== FALSE) {
            $host = $_SERVER['HTTP_HOST'];
            $urlPath = "https://$host/login/";
            $html = "<html><body><script src=\"/redirect_login.js\"></script><div id=\"redirectTrigger\" data-auto-redirect-url=\"$urlPath\"></div></body></html>";
            return new Response($html, 200, ['Content-Type' => 'text/html']);
        }
        $client = $this->findHandlerForRoute($routeIdentifier);
        $userRequestUri = sprintf(self::USER_REQUEST_URI, $client->getTargetUri(), $route, $request->getQueryString());
        //Remove host from the headers so guzzle rebuilds it with the port
        $headersExceptForHost = $request->headers->all();
        unset($headersExceptForHost['host']);
        $hmacRequest = new GuzzleRequest($request->getMethod(), $userRequestUri, $headersExceptForHost, $request->getContent());

        /** @var GuzzleResponse $response */
        try {
            $response = $client->send($hmacRequest, array(self::SAML => true));
            if ($response->getStatusCode() === 200 && $request->getMethod() === 'POST') {
                list('html' => $html, 'token' => $token) = $this->validateSAMLUser($response, $route, $headersExceptForHost);
                $host = isset($global_value['hostname']) ? $global_value['hostname'] : $_SERVER['HTTP_HOST'];
                $response = new  Response($html, $response->getStatusCode(), ['Content-Type' => 'text/html']);

                if ($token){
                # We need to set this cookie for das to consume when ui calls refresh token endpoint. This cookie is used to generate
                # a new auth token. Cookie expiry is set to 1 minute
                    $cookie_expiry =  time() + 60;
                    $saml_cookie = Cookie::create('FSRSAMLCookie')
                        ->withValue($token)
                        ->withExpires($cookie_expiry)
                        ->withHttpOnly(true)
                        ->withSecure(true);
                    $response->headers->setCookie($saml_cookie);
                }
                return $response;
            }
        } catch (BadResponseException $exception) {
            $response = $exception->getResponse();
            $respBody = json_decode($response->getBody()->getContents(), true);
            $error = $respBody['Error'] ??  $respBody['message'] ?? self::SAML_FAILURE_MESSAGE;
            return new Response($this->getErrorHTML($error), $response->getStatusCode(), ['Content-Type' => 'text/html']);
        } catch (\Exception $e) {
            throw new \Exception('Failure: ' . $e->getMessage());
        }
        return new Response($response->getBody()->getContents(), $response->getStatusCode(), ['Content-Type' => $response->getHeader('Content-Type')]);
    }

    public function routeAuthorizedSAMLAction($routeIdentifier, $route, Request $request)
    {
        $client = $this->findHandlerForRoute($routeIdentifier);
        $this->checkAuthorized($request->getMethod());
        $userRequestUri = sprintf(self::USER_REQUEST_URI, $client->getTargetUri(), $route, $request->getQueryString());
        //Remove host from the headers so guzzle rebuilds it with the port
        $headersExceptForHost = $request->headers->all();
        unset($headersExceptForHost['host']);
        $hmacRequest = new GuzzleRequest($request->getMethod(), $userRequestUri, $headersExceptForHost, $request->getContent());

        /** @var GuzzleResponse $response */
        try {
            $response = $client->send($hmacRequest, array(self::SAML => true));
        } catch (BadResponseException $exception) {
            $response = $exception->getResponse();
        } catch (\Exception $e) {
            throw new \Exception('Failure: ' . $e->getMessage());
        }
        return new Response($response->getBody()->getContents(), $response->getStatusCode(), ['Content-Type' => $response->getHeader('Content-Type')]);
    }

    /**
     * @Route("api/archival/{route}/{moduletype}/{id?}", name="app_api_archival_proxy_action", requirements={"id"=".+"}, methods={"POST", "GET", "PUT", "DELETE"})
     */
    public function archivalProxyRouteAction(Request $request, $route, $moduletype, $id)
    {
        $teams = ["/api/3/teams/doesnotexist"];
        if (get_class($this->tokenStorage->getToken()) != RestrictedUserToken::class) {
            $teams = $this->getAccessibleTeamIris();
        }

        if ($route == 'entity') {
            $this->fsrVoter->denyUnlessAccessGranted('read.data_archival');
            $this->fsrVoter->denyUnlessAccessGranted('read.' . $moduletype);
        } else if ($request->getMethod() == 'GET') {
            $this->fsrVoter->denyUnlessAccessGranted('read.data_archival');
        } else if ($request->getMethod() == 'POST') {
            $this->fsrVoter->denyUnlessAccessGranted('create.data_archival');
        } else if ($request->getMethod() == 'PUT') {
            $this->fsrVoter->denyUnlessAccessGranted('update.data_archival');
        } else if ($request->getMethod() == 'DELETE') {
            $this->fsrVoter->denyUnlessAccessGranted('delete.data_archival');
        }
        $client = $this->findHandlerForRoute('archival');
        if (!$id) {
            $archivalRequestUri = sprintf("%s/%s/%s/?%s", $client->getTargetUri(), $route, $moduletype, $request->getQueryString());
        } else {
            $archivalRequestUri = sprintf("%s/%s/%s/%s/?%s", $client->getTargetUri(), $route, $moduletype, $id, $request->getQueryString());
        }

        $body = json_decode($request->getContent());
        if (is_null($body)) {
            $body = new stdClass();
        }
        $body->{'owners'} = $teams;
        //Remove host from the headers so guzzle rebuilds it with the port
        $headersExceptForHost = $request->headers->all();
        $headersExceptForHost['Content-Type'] = 'application/json';
        unset($headersExceptForHost['host']);
        $hmacRequest = new GuzzleRequest($request->getMethod(), $archivalRequestUri, $headersExceptForHost, json_encode($body));

        /** @var GuzzleResponse $response */
        try {
            $response = $client->send($hmacRequest, array(self::SAML => true));
        } catch (BadResponseException $exception) {
            $response = $exception->getResponse();
        } catch (\Exception $e) {
            throw new \Exception('Failure: ' . $e->getMessage());
        }
        return new Response($response->getBody()->getContents(), $response->getStatusCode(), ['Content-Type' => $response->getHeader('Content-Type')]);
    }

    public function routeLogoutAction(Request $request)
    {
        $client = $this->findHandlerForRoute(self::SAML);
        $userRequestUri = sprintf(self::USER_REQUEST_URI, $client->getTargetUri(), self::LOGOUT, $request->getQueryString());
        //Remove host from the headers so guzzle rebuilds it with the port
        $headersExceptForHost = $request->headers->all();
        unset($headersExceptForHost['host']);
        $hmacRequest = new GuzzleRequest($request->getMethod(), $userRequestUri, $headersExceptForHost, $request->getContent());

        /** @var GuzzleResponse $response */
        $response = null;
        try {
            $this->logoutJwtAction($request);
            if (!$request->query->has('loggedout')) {
                $response = $client->send($hmacRequest, array(self::SAML => true));
                return new Response($response->getBody()->getContents(), $response->getStatusCode(), ['Content-Type' => $response->getHeader('Content-Type')]);
            }
        } catch (BadResponseException $exception) {
            $response = $exception->getResponse()->getBody()->read(2048);
        } catch (\Exception $e) {
            throw new \Exception('Failure: ' . $e->getMessage());
        }
        return new Response($response, Response::HTTP_OK);
    }

    /**
     * @param $routeIdentifier
     * @return ProxyClient
     */
    public function findHandlerForRoute($routeIdentifier)
    {
        $handler = $this->findHandlerMapForRoute($routeIdentifier);

        return $this->containers->get($handler[$routeIdentifier]['handlerName']);
    }

    /**
     * @param $routeIdentifier
     * @return array
     */
    private function findHandlerMapForRoute($routeIdentifier)
    {
        $handlerMap = $this->containers->getParameter('app.proxy.handler.map');

        if (!array_key_exists($routeIdentifier, $handlerMap)) {
            throw new NotFoundHttpException();
        }
        return $handlerMap;
    }

    private function logoutJwtAction(Request $request)
    {

        $jwtKey = $request->headers->get('authorization');
        $haHeader = $request->headers->has('is-cluster-call') ? $request->headers->get('is-cluster-call') : false;
        if (!$haHeader) {
            $jws = CorrectSimpleJWS::load($this->tokenStorage->getToken()->getCredentials());
            $jti = $jws->getPayload()['jti'];
            $dasUri = $this->containers->getParameter('das.uri');
            $dasClient = $this->containers->get("app.proxy.client.das");
            $headers = array(
                "Content-type" => "application/json"
            );
            $dasRequests = new GuzzleRequest('delete', $dasUri . '/token/' . $jti . '?uuid=' . $this->getUser()->getUserId(), $headers);
            try {
                $dasResponse = $dasClient->send($dasRequests);
                $resCode = $dasResponse->getStatusCode();
                if ($resCode != 200) {
                    return -1;
                }
            } catch (BadRequestHttpException | \Exception $error) {
                $this->logger->error($error->getMessage());
                return -1;
            }
        }
        $this->jwtLogoutProvider->setJwtLogoutKey($jwtKey);
    }

    public function checkAuthorized($method)
    {
        if ($method === 'POST') {
            if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.' . 'security') && !$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.' . 'security')) {
                throw new AccessDeniedException();
            }
        } else {
            if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . 'security')) {
                throw new AccessDeniedException();
            }
        }
    }
    /**
     * @param $routeIdentifier
     * @return array
     */
    private function findPermissionGroupsForRoute($routeIdentifier)
    {
        $handler = $this->findHandlerMapForRoute($routeIdentifier);
        return $handler[$routeIdentifier]['permissions'];
    }


    /**
     * @param String $userId
     * @param array $headers
     * @return GuzzleResponse $response
     */
    private function authenticateSAMLUser($userId, $headers)
    {
        $client = $this->findHandlerForRoute('auth');
        $body = "{ \"credentials\" : {\"loginid\" : \"$userId\", \"token\" : \"\" }, \"domain\" : \"\" , \"type\" : 6,
                    \"tenant\" : \"crudhub\", \"status\" : 1, \"access_type\": \"Concurrent\"}";
        $userRequestUri = sprintf("%s/%s", $client->getTargetUri(), 'users');
        /** @var GuzzleResponse $response */
        $hmacRequest = new GuzzleRequest('POST', $userRequestUri, $headers, $body);
        return $client->send($hmacRequest);
    }

    /**
     * @param String $userId
     * @param array $headers
     * @return GuzzleResponse $response
     */
    private function getSAMLUserDetail($userId)
    {
        $client = $this->findHandlerForRoute('auth');
        $userRequestUri = sprintf("%s/%s?loginid=%s", $client->getTargetUri(), 'users', $userId);
        /** @var GuzzleResponse $response */
        $custom_headers = array(
            "Content-type" => "application/json"
        );
        $hmacRequest = new GuzzleRequest('GET', $userRequestUri, $custom_headers);
        return $client->send($hmacRequest);
    }


    /**
     * @param GuzzleResponse $response
     * @param String $route
     * @param array $headers
     * @return String $html
     */
    private function validateSAMLUser($response, $route, $headers)
    {
        $userId = null;
        $jwtToken = null;
        $authStatus = null;
        if ($route === self::LOGIN) {
            $actorBody = json_decode($response->getBody()->getContents(), true);
            if (array_key_exists(self::USERID, $actorBody)) {
                $userId = $actorBody[self::USERID];

                # authenticationStatus field is received from FAC.
                $samlAttributes = $actorBody["attributes"];
                if (array_key_exists("authenticationStatus", $samlAttributes)) {
                    $authStatus = $samlAttributes["authenticationStatus"];
                }
                # Validate saml user provioning  
                $preProvisioned = $actorBody["preProvisioned"];
                if ($preProvisioned) {
                    $actor = null;
                    try {
                        $userResp = $this->getSAMLUserDetail($userId, $headers);
                        if ($userResp->getStatusCode() == 200 || $userResp->getStatusCode() == 201) {
                            $userRespBody = json_decode($userResp->getBody()->getContents(), true);
                            if (array_key_exists("usersresp", $userRespBody)) {
                                $userResp = $userRespBody["usersresp"][0];
                                $actor = $this->samlActorService->getActor($userResp["uuid"]);
                            }
                        }
                    } catch (BadResponseException $exception) {
                        $response = $exception->getResponse();
                        $actor = null;
                    }

                    if ($actor === null) {
                        return [
                        "html" => $this->getErrorHTML('The SSO authorization settings are configured for pre-provisioned users. Please contact system administrator to ensure your user credentials are created in the system.'),
                        "token" => null
                        ];
                    }
                }

                /** @var GuzzleResponse $validateResp */
                try {
                    $validateResp = $this->authenticateSAMLUser($userId, $headers);
                    if ($validateResp->getStatusCode() == 200 || $validateResp->getStatusCode() == 201) {
                        $validateRespBody = json_decode($validateResp->getBody()->getContents(), true);
                        $jwtToken = $validateRespBody['token'];
                        $actorBody[self::USERID] = $validateRespBody['uuid'];
                        $actorBody["attributes"]["accessType"] = $validateRespBody['accessType'];
                        $this->samlActorService->saveSamlUser(Person::class, $actorBody);
                        return [
                        "html" => $this->getHTML($jwtToken, $route, $authStatus),
                        "token" => $jwtToken
                        ];
                    } else {
                        $respBody = json_decode($validateResp->getBody()->getContents(), true);
                        // DAS sends error message in key "Error" or "reason"
                        return [
                        "html" => $this->getErrorHTML($respBody['Error'] ?? $respBody['reason']),
                        "token" => null
                        ];
                    }
                } catch (BadResponseException $exception) {
                    $response = $exception->getResponse();
                    $respBody = json_decode($response->getBody()->getContents(), true);
                    // DAS sends error message in key "Error" or "reason"
                    return [
                    "html" => $this->getErrorHTML($respBody['Error'] ?? $respBody['reason']),
                    "token" => null
                    ];
                } catch (\Exception $e) {
                    throw new \Exception('Failure: ' . $e->getMessage());
                }
            } else {
                return [
                "html" => $this->getErrorHTML('Invalid authentication request, no user found'),
                "token" => null
                ];

            }
        }
        return [
        "html" => $this->getHTML($jwtToken, $route, $authStatus),
        "token" => $jwtToken
        ];
    }

    private function getHTML($jwtToken, $route, $authStatus)
    {
        $managerRegistry = $this->containers->get('doctrine');
        $manager = $managerRegistry->getManagerForClass(SystemSettings::class);
        $systemRepository = $manager->getRepository(SystemSettings::class);
        $systemSetting = $systemRepository->findAll();
        $global_value = $systemSetting[0]->getGlobalValues();
        $host = isset($global_value['hostname']) ? $global_value['hostname'] : $_SERVER['HTTP_HOST'];
        $html = "";
        if ($route === self::LOGIN) {
            # When SSO is configured from FSR to FAC and the user has not enabled 2FA, FSR will show nagging message to
            # user to enable 2FA.
            # Following values are received for authStatus field:
            # 1. "password only"
            # 2. "FortiToken only"
            # 3. "password and FortiToken"
            # 4. "password and Email token"
            # 5."password and SMS token"
            # 6. "federated"
            # Only values "password only" and "FortiToken only" identify the case when 2FA is not enabled.
            if ($authStatus != NULL && (strtolower($authStatus) == "password only" || strtolower($authStatus) == "fortitoken only")) {
                $urlPath = "https://$host/login/?saml=true&show_saml_2fa_warning=true";
                $html = "<html><body><script src=\"/redirect_login.js\"></script><div id=\"redirectTrigger\" data-auto-redirect-url=\"$urlPath\"></div></body></html>";
            } else {
                $urlPath = "https://$host/login/?saml=true&show_saml_2fa_warning=false";
                $html = "<html><body><script src=\"/redirect_login.js\"></script><div id=\"redirectTrigger\" data-auto-redirect-url=\"$urlPath\"></div></body></html>";
            }
        } elseif ($route === self::LOGOUT) {
            $urlPath = "https://$host/logout?loggedout=true";
            $html = "<html><body><script src=\"/redirect_login.js\"></script><div id=\"redirectTrigger\" data-auto-redirect-url=\"$urlPath\"></div></body></html>";
        }
        return $html;
    }

    private function getErrorHTML($error)
    {
        $error = urlencode($error);
        $managerRegistry = $this->containers->get('doctrine');
        $manager = $managerRegistry->getManagerForClass(SystemSettings::class);
        $systemRepository = $manager->getRepository(SystemSettings::class);
        $systemSetting = $systemRepository->findAll();
        $global_value = $systemSetting[0]->getGlobalValues();
        $host = isset($global_value['hostname']) ? $global_value['hostname'] : $_SERVER['HTTP_HOST'];
        $urlPath = "https://$host/login/?error=$error";
        $html = "<html><body><script src=\"/redirect_login.js\"></script><div id=\"redirectTrigger\" data-auto-redirect-url=\"$urlPath\"></div></body></html>";
        return $html;
    }
}
