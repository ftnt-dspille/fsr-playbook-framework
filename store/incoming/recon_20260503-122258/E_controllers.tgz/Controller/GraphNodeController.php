<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use Psr\Log\LoggerInterface;
use App\Service\MetadataHelper;
use App\Security\Voter\FsrVoter;
use App\Controller\BaseController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use ApiPlatform\Core\Api\IriConverterInterface;
use App\Providers\PermissionsDictionaryBuilder;
use ApiPlatform\Api\ResourceClassResolverInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use ApiPlatform\Core\DataProvider\ItemDataProviderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class GraphNodeController extends BaseController
{
    public const MAX_COUNT = 100;
    public const MAX_DEPTH = 4;

    protected $visitedNodes = [];
    protected $maxRelation = self::MAX_COUNT;
    protected $depth = self::MAX_DEPTH;
    protected $nodeCounter = 1;
    protected $graph = [];

    public function __construct(
        protected FsrVoter $fsrVoter,
        ResourceClassResolverInterface $resourceClassResolver,
        ContainerInterface $containers,
        protected IriConverterInterface $iriConverter,
        protected ItemDataProviderInterface $chainItemDataProvider,
        TagAwareCacheInterface $cache,
        MetadataHelper $metadataHelper,
        protected SerializerInterface $serializer,
        protected LoggerInterface $logger
    ) {
        parent::__construct($resourceClassResolver, $containers, $cache, $metadataHelper, $serializer, $logger);
    }

    public function getNodes(Request $request, $moduletype, $id)
    {
        $context = [];
        $resource = $this->getResourceFromClassName($moduletype);
        $request_body = json_decode($request->getContent(), true);
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $moduletype);
        $object = $this->chainItemDataProvider->getItem($resource, ["uuid" => $id]);
        if (is_null($object)) {
            throw new NotFoundHttpException('No record found with given ID');
        }
        $context['relationships'] = True;
        //todo :optimize normalizer , try to remove relationship true
        $normalizedObject = $this->serializer->normalize($object, 'jsonld', $context);
        $this->maxRelation = $request_body['count'] ?? self::MAX_COUNT;
        $this->depth = $request_body['depth'] ?? self::MAX_DEPTH;
        unset($request_body['depth']);
        unset($request_body['count']);
        $this->graph['nodes'] = [];
        $this->graph['edges'] = [];
        $rootnode = [];
        $rootnode['id'] = $normalizedObject['@id'];
        $rootnode['size'] = 30;
        array_push($this->visitedNodes, $normalizedObject['@id']);
        if (isset($request_body[$moduletype]['display_field'])) {
            $rootnode['title'] = (string)$normalizedObject[$request_body[$moduletype]['display_field']];
        } else {
            $rootnode['title'] = (string)$normalizedObject["id"];
        }
        $rootnode['label'] = strlen($rootnode['title']) > 20 ? substr($rootnode['title'], 0, 20) . "..." : $rootnode['title'];
        if (isset($request_body[$moduletype])) {
            $rootnode['data'] = $request_body[$moduletype];
        }
        if (isset($request_body[$moduletype]['picklist']) && isset($normalizedObject[$request_body[$moduletype]['picklist']])) {
            $rootnode['color'] = $normalizedObject[$request_body[$moduletype]['picklist']]['color'];
            unset($rootnode['data']['picklist']);
        } elseif (isset($request_body[$moduletype]['color']) && $request_body[$moduletype]['color'] !== '') {
            $rootnode['color'] = $request_body[$moduletype]['color'];
            unset($rootnode['data']['color']);
        }
        $rootnode['moduleType'] = $moduletype;
        $rootnode['group'] = $moduletype;
        $nodesRelation = [];
        if (isset($rootnode['data']['relationships'])) {
            $nodesRelation = $rootnode['data']['relationships'];
        }
        unset($rootnode['data']['relationships']);
        $rootnode['adjacencies'] = [];
        foreach ($nodesRelation as $rkey => $rvalue) {
            $rvalue = $rvalue['field'];

            // if no read permission on related field then only 2 fields (@id, type) is available
            if (isset($normalizedObject[$rvalue]) && is_array($normalizedObject[$rvalue]) && count($normalizedObject[$rvalue]) && (is_countable($normalizedObject[$rvalue][0]) ? count($normalizedObject[$rvalue][0]) : 0) > 2) {
                foreach ($normalizedObject[$rvalue] as $innerKey => $innerValue) {
                    if ($innerKey < $this->maxRelation) {
                        $connectedNode = [];
                        $connectedNode['from'] = $normalizedObject['@id'];
                        $connectedNode['to'] = is_array($innerValue) ? $innerValue['@id']: $innerValue;
                        $this->addToEdge($connectedNode);
                        $this->getSubNodes($connectedNode, $request_body, 1);
                    } else {
                        $connectedNode = [];
                        $connectedNode['from'] = $normalizedObject['@id'];
                        $connectedNode['to'] = $this->nodeCounter;
                        $this->nodeCounter = $this->nodeCounter + 1;
                        $connectedNode['moduleTo'] = is_array($innerValue) ? $innerValue['@id']: $innerValue;
                        $connectedNode['type'] = 'countNode';
                        $connectedNode['showCountNode'] = count($normalizedObject[$rvalue]) - $innerKey;
                        array_push($this->graph['edges'], $connectedNode);
                        $this->getSubNodes($connectedNode, $request_body, 1);
                        break;
                    }
                }
            }
        }
        array_push($this->graph['nodes'], $rootnode);
        return new Response(json_encode($this->graph, JSON_INVALID_UTF8_IGNORE));
    }


    public function getSubNodes($connectedNode, $request_body, $level)
    {
        $context = [];
        if (isset($connectedNode['type']) && $connectedNode['type'] == 'countNode') {
            $explod = explode('/', $connectedNode['moduleTo']);
            $id = end($explod);
            $rootnode = [];
            $resultArry = [];
            $resource = $this->getResourceFromClassName($explod[3]);
            $object = $object = $this->chainItemDataProvider->getItem($resource, ["uuid" => $id]);
            $normalizedObject = $this->serializer->normalize($object, 'jsonld');
            $rootnode['id'] = $connectedNode['to'];
            $rootnode['moduleType'] = $explod[3];
            $rootnode['group'] = $explod[3];
            $rootnode['title'] = strtoupper($explod[3]) . "-(" . (string)$connectedNode['showCountNode'] . "+ " . strtoupper($explod[3]) . " ) ";
            $rootnode['label'] = strlen($rootnode['title']) > 20 ? substr($rootnode['title'], 0, 20) . "..." : $rootnode['title'];
            if (isset($request_body[$explod[3]])) {
                $rootnode['data'] = $request_body[$explod[3]];
                unset($rootnode['data']['relationships']);
            }
            if (isset($request_body[$explod[3]]['picklist']) && isset($normalizedObject[$request_body[$explod[3]]['picklist']])) {
                $rootnode['color'] = $normalizedObject[$request_body[$explod[3]]['picklist']]['color'];
                unset($rootnode['data']['picklist']);
            } elseif (isset($request_body[$explod[3]]['color']) && $request_body[$explod[3]]['color'] !== '') {
                $rootnode['color'] = $request_body[$explod[3]]['color'];
                unset($rootnode['data']['color']);
            }
            $rootnode['type'] = 'countNode';
            $rootnode['data']['tooltip'] = "There are " . (string)$connectedNode['showCountNode'] . " more records, however only " . $this->maxRelation . " are shown in this view";

            array_push($resultArry, $rootnode);
            return $resultArry;
        } else {
            $explod = explode('/', $connectedNode['to']);
            $id = end($explod);
            $rootnode = [];
            $resultArry = [];
            $moduletype = $explod[3];
            $resource = $this->getResourceFromClassName($moduletype);
            if ($this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.' . $moduletype)) {
                ++$level;
                $object = $object = $this->chainItemDataProvider->getItem($resource, ["uuid" => $id]);
                $context['relationships'] = True;
                $group = ["uuid", "id"];
                foreach ($request_body[$explod[3]]['relationships'] as $rvalue) {
                    $group[] = $rvalue['field'];
                }
                if (isset($request_body[$explod[3]]['display_field'])) {
                    $group[] = $request_body[$explod[3]]['display_field'];
                }
                if (isset($request_body[$explod[3]]['picklist'])) {
                    $group[] = $request_body[$explod[3]]['picklist'];
                }
                $context['groups'] = $group;
                $normalizedObject = $this->serializer->normalize($object, 'jsonld', $context);
                $rootnode['id'] = $normalizedObject['@id'];
                $rootnode['moduleType'] = $explod[3];
                $rootnode['group'] = $explod[3];
                if (isset($request_body[$explod[3]]['display_field'])) {
                    $rootnode['title'] = (string)$normalizedObject[$request_body[$explod[3]]['display_field']];
                } else {
                    $rootnode['title'] = (string)$normalizedObject["id"];
                }
                $rootnode['label'] = strlen($rootnode['title']) > 20 ? substr($rootnode['title'], 0, 20) . "..." : $rootnode['title'];
                if (isset($request_body[$explod[3]])) {
                    $rootnode['data'] = $request_body[$explod[3]];
                    unset($rootnode['data']['relationships']);
                }
                if (isset($request_body[$explod[3]]['picklist']) && isset($normalizedObject[$request_body[$explod[3]]['picklist']])) {
                    $rootnode['color'] = $normalizedObject[$request_body[$explod[3]]['picklist']]['color'];
                    unset($rootnode['data']['picklist']);
                } elseif (isset($request_body[$explod[3]]['color']) && $request_body[$explod[3]]['color'] !== '') {
                    $rootnode['color'] = $request_body[$explod[3]]['color'];
                    unset($rootnode['data']['color']);
                }

                if (isset($request_body[$explod[3]]) && $level < $this->depth) {
                    foreach ($request_body[$explod[3]]['relationships'] as $rvalue) {
                        $rvalue = $rvalue['field'];

                        if (isset($normalizedObject[$rvalue]) && is_array($normalizedObject[$rvalue]) && count($normalizedObject[$rvalue])) {
                            foreach ($normalizedObject[$rvalue] as $innerKey => $innerValue) {
                                if ($innerKey < $this->maxRelation) {
                                    $connectedNode = [];
                                    $connectedNode['from'] = $normalizedObject['@id'];
                                    $connectedNode['to'] = is_array($innerValue) ? $innerValue['@id']: $innerValue;
                                    $this->addToEdge($connectedNode);
                                    $this->getSubNodes($connectedNode, $request_body, $level);
                                } else {
                                    $connectedNode = [];
                                    $connectedNode['from'] = $normalizedObject['@id'];
                                    $connectedNode['to'] = $this->nodeCounter;
                                    $this->nodeCounter = $this->nodeCounter + 1;
                                    $connectedNode['moduleTo'] = is_array($innerValue) ? $innerValue['@id']: $innerValue;
                                    $connectedNode['type'] = 'countNode';
                                    $connectedNode['showCountNode'] = count($normalizedObject[$rvalue]) - $innerKey;
                                    array_push($this->graph['edges'], $connectedNode);
                                    $this->getSubNodes($connectedNode, $request_body, $level);
                                    break;
                                }
                            }
                        }
                    }
                }

                if (!in_array($rootnode['id'], $this->visitedNodes)) {
                    array_push($this->graph['nodes'], $rootnode);
                    array_push($this->visitedNodes, $rootnode['id']);
                }
            }
        }
    }

    public function addToEdge($edge)
    {
        $found = false;
        foreach ($this->graph['edges'] as $value) {
            if (($value['from'] == $edge['from'] && $value['to'] == $edge['to']) || ($value['from'] == $edge['to'] && $value['to'] == $edge['from'])) {
                $found = true;
                break;
            }
        }
        if (!$found) {
            array_push($this->graph['edges'], $edge);
        }
    }
}
