<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Service\IriHelper;
use App\Entity\Custom\Router;
use App\Entity\Custom\Tenant;
use App\Entity\Custom\Agent;
use App\Service\UtilityService;
use App\Providers\QueryProvider;
use App\Security\Voter\FsrVoter;
use App\Constants\CacheConstants;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use ApiPlatform\Core\DataProvider\CollectionDataProviderInterface;
use ApiPlatform\Core\Serializer\SerializerContextBuilderInterface;
use App\Constants\AppConstants;
use App\Constants\ErrorConstants;
use App\Service\SKUService;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

// Only Adding Code for Tenant Create and Update.
// This code needs to be generalized hence commeneted entire code
// Need discussion on this Controller
class TenantController extends AbstractController
{
    const MODULE_TYPE = "tenants";
    const TENANT_ROLE_NAME = 'tenant';
    const MASTER_ROLE_NAME = 'master';
    const REPLICATION_ROUTINGKEY = "route.crudhub.tenant.request.tenantconfig";
    const REMOTE_MMD_MODIFICATION_NOT_ALLOWED = 'Modifying Remote MMD Value is not allowed';
    const ALLOW_REMOTE_MMD = 'allowRemoteMMDModification';

    protected $fsrVoter;

    protected $utilityService;

    protected $entityManager;

    protected $iriHelper;

    private $cache;

    private $queryProvider;
    private $collectionDataProvider;
    private $serializerContextBuilder;
    private $skuService;


    public function __construct(
        FsrVoter $fsrVoter,
        UtilityService $utilityService,
        EntityManagerInterface $entityManager,
        IriHelper $iriHelper,
        QueryProvider $queryProvider,
        SerializerContextBuilderInterface $serializerContextBuilder,
        CollectionDataProviderInterface $collectionDataProvider,
        TagAwareCacheInterface $cache,
        protected SerializerInterface $serializer,
        SKUService $skuService,
    ) {
        $this->fsrVoter = $fsrVoter;
        $this->utilityService = $utilityService;
        $this->entityManager = $entityManager;
        $this->iriHelper = $iriHelper;
        $this->queryProvider = $queryProvider;
        $this->serializerContextBuilder = $serializerContextBuilder;
        $this->collectionDataProvider = $collectionDataProvider;
        $this->cache = $cache;
        $this->serializer = $serializer;
        $this->skuService = $skuService;
    }

    /**
     * @param Request $request
     * @return Response|static
     */
    public function getAction(Request $request)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.tenants');
        $queryLimit = $request->get('$limit', 30);
        $queryPage = $request->get('$page', 1);
        $item = $this->cache->getItem('instanceRole');
        if ($item->isHit()) {
            $role = $item->get();
        } else {
            $role = $this->utilityService->getRequiredLicenseDetails(CacheConstants::INSTANCE_ROLE);
        }
        if ($role === self::TENANT_ROLE_NAME) {
            $request->query->set('role$eq', 'self');
        }
        $request->overrideGlobals();
        $attributes['filters'] = ['$limit' => $queryLimit, '$page' => $queryPage];
        $attributes['resource_class'] = Tenant::class;
        $attributes['collection_operation_name'] = "get";
        $context = $this->serializerContextBuilder->createFromRequest($request, true, $attributes);
        $associatedEntities = $this->collectionDataProvider->getCollection(Tenant::class, $request, $attributes);
        $data1 = $this->serializer->normalize($associatedEntities, 'jsonld', $context);
        return new JsonResponse($data1);
    }

    /**
     * @param Request $request
     * @return Response|static
     */
    public function getRouterAction(Request $request)
    {
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.routers');
        $queryLimit = $request->get('$limit', 30);
        $queryPage = $request->get('$page', 1);
        $request->query->set('uuid$neq', 'd134a192-2a3e-4bd9-a4b9-11db811803f6');
        $request->overrideGlobals();
        $attributes['filters'] = ['$limit' => $queryLimit, '$page' => $queryPage];
        $attributes['resource_class'] = Router::class;
        $attributes['collection_operation_name'] = "get";
        $context = $this->serializerContextBuilder->createFromRequest($request, true, $attributes);
        $associatedEntities = $this->collectionDataProvider->getCollection(Router::class, $request, $attributes);
        $data1 = $this->serializer->normalize($associatedEntities, 'jsonld', $context);
        return new JsonResponse($data1);
    }

    /**
     * @param Request $request
     * @return Response
     * @throws DeserializationException
     */
    public function postAction(Request $request)
    {
        $resource = Tenant::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_CREATE . '.tenants');
        $decodedRequestData = json_decode($request->getContent(), true);
        $this->prePostCheck($decodedRequestData, $resource);
        $request_data = $this->prePostAdd($decodedRequestData);
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($request_data),
            $resource,
            'jsonld',
            ['fetch_data' => false]
        );
        $request->attributes->set('_api_collection_operation_name', 'post');
        $request->attributes->set('_api_item_operation_name', 'post');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->overrideGlobals();
        return $denormalizedObject;
    }

    /**
     * @param $decodedRequestData
     * @return bool|Response
     * @throws HttpException
     */
    public function prePostCheck($decodedRequestData, $resource)
    {
        $entityRepo = $this->entityManager->getRepository($resource);
        $tenantId = isset($decodedRequestData['tenantId']) ? $decodedRequestData['tenantId'] : null;
        if ($tenantId) {
            $existingTenantObj = $this->utilityService->getItemWithWhere($entityRepo, ['tenantId' => $tenantId]);
            if ($existingTenantObj) {
                throw new BadRequestHttpException("TenantId: '" . $tenantId . "' already exists, use different TenantId");
            }
        }
        $tenantName = isset($decodedRequestData['name']) ? $decodedRequestData['name'] : null;
        if ($tenantName) {
            $existingTenantObj = $this->utilityService->getItemWithWhere($entityRepo, ['name' => $tenantName]);
            if ($existingTenantObj) {
                throw new BadRequestHttpException("Tenant Name: '" . $tenantName . "' already exists, use different Tenant Name");
            }
        }
        if ($decodedRequestData['role'] == 'self') {
            throw new AccessDeniedException('UnAuthorized Access');
        }
        return true;
    }

    public function prePostAdd($decodedRequestData)
    {
        $configStatus = isset($decodedRequestData['configstatus']) ? $decodedRequestData['configstatus'] : null;
        if (!$configStatus) {
            if (isset($decodedRequestData['isDedicated']) && !$decodedRequestData['isDedicated']) {
                $decodedRequestData[self::ALLOW_REMOTE_MMD] = false;
                if (!isset($decodedRequestData['tenantId'])) {
                    $decodedRequestData['tenantId'] = bin2hex(random_bytes(16));
                }
            } else {
                $decodedRequestData[self::ALLOW_REMOTE_MMD] = true;
            }
            if (!isset($decodedRequestData['role'])) {
                $decodedRequestData['role'] = 'tenant';
            }
        }
        return $decodedRequestData;
    }

    public function prePutValidate($instanceRole, $objectData, $isMmdModificationNotAllowed, $preUpdatedObject)
    {
        if (($instanceRole == self::MASTER_ROLE_NAME) && array_key_exists(self::ALLOW_REMOTE_MMD, $objectData) && $isMmdModificationNotAllowed && $objectData[self::ALLOW_REMOTE_MMD] != $preUpdatedObject[self::ALLOW_REMOTE_MMD]) {
            throw new AccessDeniedException(self::REMOTE_MMD_MODIFICATION_NOT_ALLOWED);
        }
    }

    public function putAction(Request $request, $id)
    {
        $context = [];
        $resource = Tenant::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.tenants');
        $objectData = json_decode($request->getContent(), true);
        $object = $this->iriHelper->findOrThrowNotFound('/api/3/tenants/' . $id);
        $classPath = get_class($object);

        $groups = $this->utilityService->identifyChangeFields(json_decode($request->getContent()), $classPath);
        array_push($groups, "fsr_all");
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => $groups]
        );

        $context['object_to_populate'] = $object;
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($objectData),
            $resource,
            'jsonld',
            $context + ['fetch_data' => false]
        );

        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);

        $request->attributes->set('_api_collection_operation_name', 'put');
        $request->attributes->set('_api_item_operation_name', 'put');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->attributes->set('previous_data', $object);
        $request->overrideGlobals();
        return $denormalizedObject;
    }

    public function routerPutAction(Request $request, $uuid)
    {
        $context = [];
        $resource = Router::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_UPDATE . '.routers');
        $objectData = json_decode($request->getContent(), true);

        if (array_key_exists("health", $objectData)) {
            $newHealth = $objectData["health"];
        } else {
            $newHealth = null;
        }

        if ($newHealth != null) {
            $nodeId = array_key_first($newHealth);
            $conn = $this->entityManager->getConnection();
            $sql = '
                UPDATE routers
                SET health = jsonb_set(coalesce(health,\'{}\'), :path, :value)
                WHERE uuid = :uuid
            ';

            $stmt = $conn->prepare($sql);
            $stmt->bindValue('path', '{' . $nodeId . '}');
            $stmt->bindValue('value', json_encode($newHealth[$nodeId]));
            $stmt->bindValue('uuid', $uuid);
            $stmt->executeQuery();
        }
        
        $object = $this->iriHelper->findOrThrowNotFound('/api/3/routers/' . $uuid);
        $classPath = get_class($object);

        # Handling below in transaction


        $groups = $this->utilityService->identifyChangeFields(json_decode($request->getContent()), $classPath);
        array_push($groups, "fsr_all");
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => array_merge($groups, ['password'])]
        );
        $this->updateConfigStatus($normalizedPreviousData, $uuid);


        $context['object_to_populate'] = $object;
        $keys_to_remove = ["health", "configStatus"];
        
        // Remove the keys
        foreach ($keys_to_remove as $key) {
            unset($objectData[$key]);
        }
        $denormalizedObject = $this->serializer->deserialize(
            json_encode($objectData),
            $resource,
            'jsonld',
            $context + ['fetch_data' => false]
        );


        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);

        $request->attributes->set('_api_collection_operation_name', 'put');
        $request->attributes->set('_api_item_operation_name', 'put');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $denormalizedObject);
        $request->attributes->set('_format', 'jsonld');
        $request->attributes->set('previous_data', $object);
        $request->overrideGlobals();
        return $denormalizedObject;
    }

    public function deleteAction(Request $request, $id)
    {
        $resource = Tenant::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.tenants');
        $object = $this->iriHelper->findOrThrowNotFound('/api/3/tenants/' . $id);
        $classPath = get_class($object);
        if ($object->getRole() == 'self') {
            return new Response("Deletion of self Tenant is not allowed", Response::HTTP_BAD_REQUEST);
        }
        $groups = $this->utilityService->identifyChangeFields(json_decode($request->getContent()), $classPath);
        array_push($groups, "fsr_all");
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => $groups]
        );
        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);

        $request->attributes->set('_api_item_operation_name', 'delete');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $object);
        $request->attributes->set('_format', 'jsonld');
        $request->attributes->set('previous_data', $object);
        $request->overrideGlobals();
        return $object;
    }

    public function routerDeleteAction(Request $request, $uuid)
    {
        $resource = Router::class;
        $this->fsrVoter->denyUnlessAccessGranted(PermissionsDictionaryBuilder::PERM_CRUD_DELETE . '.routers');
        $object = $this->iriHelper->findOrThrowNotFound('/api/3/routers/' . $uuid);
        $groups = ["fsr_all"];
        $normalizedPreviousData = $this->serializer->normalize(
            $object,
            'jsonld',
            ["asJson" => true, "relationships" => true, "groups" => $groups]
        );
        if ($normalizedPreviousData) {
            $agentRepository = $this->entityManager->getRepository(Agent::class);
            $agentsData = $agentRepository->findBy(["router" => $normalizedPreviousData['uuid']]);
            if (!empty($agentsData)) {
                throw new BadRequestHttpException(sprintf(ErrorConstants::SME_IS_IN_USE, count($agentsData)));
            }
        }
        $request->attributes->set('fsr_previous_data', $normalizedPreviousData);
        $request->attributes->set('fsr_change_fields', $groups);
        $request->attributes->set('_api_item_operation_name', 'delete');
        $request->attributes->set('_api_resource_class', $resource);
        $request->attributes->set('data', $object);
        $request->attributes->set('_format', 'jsonld');
        $request->attributes->set('previous_data', $object);
        $request->overrideGlobals();
        return $object;
    }

    public function updateConfigStatus($routerObject, $uuid)
    {
        # Fetch and cache node
        $nodeList = $this->skuService->getHAClusterNodesFromDas();

        if (array_key_exists("health", $routerObject)) {
            $health = $routerObject["health"];
        }

        if(is_null($health)){
            return;
        }

        $resultantStatus = AppConstants::PICKLISTS["CONFIGURATION_STATUS"]["CONFIGURED"];
        $configMessage = null;

        foreach ($health as $hostname => $nodeHealth) {

            if ( in_array($hostname,$nodeList) && $nodeHealth["configStatus"] !== AppConstants::PICKLISTS["CONFIGURATION_STATUS"]["CONFIGURED"]) {
                // If any node is not configured, return "not configured"
                $resultantStatus = AppConstants::PICKLISTS["CONFIGURATION_STATUS"]["CONFIGURATION_FAILED"];
                $configMessage = $nodeHealth["configMessage"];
                break;
            }
        }
        $iriParts = explode('/', $resultantStatus);
        $picklistUuid = end($iriParts);

        $connection = $this->entityManager->getConnection();
        $connection->beginTransaction();
        $retryCount = 5;
        while ($retryCount > 0) {
            try {
                
                # Remove stale entries
                foreach (array_keys($health) as $nodeName){
                    if ( ! in_array($nodeName,$nodeList) ){
                        $sql = '
                        UPDATE routers
                        SET health = health - :nodeName
                        WHERE uuid = :uuid
                        ';
                        $stmt = $connection->prepare($sql);
                        $stmt->bindValue('nodeName', $nodeName);
                        $stmt->bindValue('uuid', $uuid);
                        $stmt->executeQuery();
                    }
                    
                }
                $sql = '
                UPDATE routers
                SET configStatus =:configStatus,
                configMessage = :configMessage
                WHERE uuid = :uuid
                ';
                $stmt = $connection->prepare($sql);
                $stmt->bindValue('configStatus', $picklistUuid);
                $stmt->bindValue('configMessage', $configMessage);
                $stmt->bindValue('uuid', $uuid);
                $stmt->executeQuery();
                $connection->commit();
                return;
            } catch (\Exception $e) {
                $connection->rollBack();
                $retryCount--;
                if ($retryCount <=0 ){
                    # Case when updating configStatus fails
                    throw new \Exception(sprintf('Failed to update configStatus in transaction',$e));
                }
                sleep(5);
            }
        }
    }
}
