<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Service\UserPreferenceService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\DependencyInjection\Loader\Configurator\serializer;

class UserPreferenceController extends AbstractController
{

    protected $userPreferenceService;

    public function __construct(
        UserPreferenceService $userPreferenceService,
        protected SerializerInterface $serializer
    ) {
        $this->userPreferenceService = $userPreferenceService;
        $this->serializer = $serializer;
    }

    public function getUserPreferenceAction()
    {
        $userPrefProvider = $this->userPrefProvider();
        /** @var UserPreference $userPref */
        $userPref = $userPrefProvider->getUserPref();
        $serializer = $this->serializer;
        $normalizedUserPref = $serializer->normalize($userPref, 'json');
        return new JsonResponse($normalizedUserPref);
    }

    /**
     * @return UserPreferenceProvider
     */
    private function userPrefProvider()
    {
        return $this->userPreferenceService;
    }

    public function createUserPreferenceAction(Request $request)
    {
        $userPrefProvider = $this->userPrefProvider();
        $reqBody = json_decode($request->getContent(), true);
        /** @var UserPreference $userPref */
        $userPref = $userPrefProvider->saveUserPref($reqBody);
        $serializer = $this->serializer;
        $normalizedUserPref = $serializer->normalize($userPref, 'json');
        return new JsonResponse($normalizedUserPref);
    }
}
