<?php
/* Copyright start
  Copyright (C) 2008 - 2025 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */

namespace App\Controller;

use App\Constants\AppConstants;
use App\Security\Voter\FsrVoter;
use Symfony\Component\HttpFoundation\Request;
use App\Providers\PermissionsDictionaryBuilder;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class LocaleController extends AbstractController
{

    public function __construct(
        protected FsrVoter $fsrVoter
    ) {
    }
    /**
     * @Route("/api/locale/1/{moduleType}/{lang}", name="fetch_module_locale", methods={"GET"})
     */
    public function getLocale(Request $request, string $moduleType, string $lang): JsonResponse
    {
        if (!$this->fsrVoter->isGranted(PermissionsDictionaryBuilder::PERM_CRUD_READ . '.application')) {
            throw new AccessDeniedException();
        }
        $pathComponents = [AppConstants::LOCALES_MMD_PATH, $moduleType, $lang];
        $localePath = implode('/', $pathComponents);
        $localeDataFile = file_exists($localePath) ? file_get_contents($localePath) : '{}' ;
        $localeDataFile = json_decode($localeDataFile);
        return new JsonResponse($localeDataFile);
    }
}